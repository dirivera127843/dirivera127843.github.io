// Declaring string variables
var firstName = "Daniel";
var lastName = "Rivera";
var sentence = "Pets come and go, but they can be remembered fondly.";
// Declaring a boolean variable
var theTruth = true;
// Declaring number variables
var ten = 10;
var fifteen = 15;
var twentyFive = 25;

// Various strings being displayed to the console. All of them concatenate to include the variables initialized above.
console.log(firstName + " " + lastName);
console.log("The length of my sentence is: " + sentence.length + " characters long.");
console.log("The sum of " + ten + " and " + fifteen + " is equal to " + twentyFive + ".");
console.log("The variable theTruth is storing the value " + theTruth + ". The data type of theTruth is " + typeof theTruth + ".");