// Defining variables for the contactUs.html form's various input elements
// Contact and info
var uName = document.getElementById("username");
var reasons = document.getElementById("reason");
var phone = document.getElementById("phone-num");
var uEmail = document.getElementById("email");
// Purchase an item?
var plush = document.getElementById("c-plush");
var poster = document.getElementById("d-poster");
var toy = document.getElementById("l-toy");
var pin = document.getElementById("m-pin");
var keychain = document.getElementById("s-keychain");
var sticker = document.getElementById("stickers");
var taxState = document.getElementById("tax-select");
// Message
var userMessage = document.getElementById("message");


// Defining functions
// First function runs other functions upon submission
function submission(event) {
    event.preventDefault();
    var valid = validate();
    if (valid === false) {
        return false;
    } else {
        var purchasing = document.querySelector("input[name=buy]:checked");
        console.log(uName.value, reasons.value, phone.value, uEmail.value,
            purchasing.value, plush.value, poster.value, toy.value, pin.value,
            keychain.value, sticker.value, taxState.value, userMessage.value);
        console.log(estimateCalc());
    }
}
// Second function validates if certain fields are filled out and highlights them if invalid
function validate() {
    if (uName.value === "" || (phone.value === "" && uEmail.value === "")) {
        alert("Missing name and/or phone number/email address.");
        if (uName.value === "") {
            uName.focus();
        } else if (phone.value === "") {
            phone.focus();
        } else {
            uEmail.focus();
        }
        return false;
    }
    if (document.querySelector("input[name=buy]:checked").value === "yes" && taxState.value === "") {
        alert("No state selected for purchased items");
        taxState.focus();
        return false;
    }
    return true;
}
// Third function calculates total cost of items purchased
function estimateCalc() {
    var plushCost = parseInt(plush.value);
    var posterCost = parseInt(poster.value);
    var toyCost = parseInt(toy.value);
    var pinCost = parseInt(pin.value);
    var keychainCost = parseInt(keychain.value);
    var stickerCost = parseInt(sticker.value);
    var taxCalc = 1;
    if (document.querySelector("input[name=buy]:checked").value === "yes") {
        if (plush.checked === false) {
            plushCost = 0;
        }
        if (poster.checked === false) {
            posterCost = 0;
        }
        if (toy.checked === false) {
            toyCost = 0;
        }
        if (pin.checked === false) {
            pinCost = 0;
        }
        if (keychain.checked === false) {
            keychainCost = 0;
        }
        if (sticker.checked === false) {
            stickerCost = 0;
        }

        switch (taxState.value) {
            case "TX":
                taxCalc = 1.065;
                break;
            case "OH":
                taxCalc = 1.055;
                break;
            default:
                taxCalc = 1;
                break;
        }
        
        var estTotal = "$" + ((plushCost + posterCost + toyCost + pinCost + keychainCost + stickerCost) * taxCalc).toFixed(2);
        return estTotal;
    } else {
        return "$0.00";
    }
}
// Fourth function disables and enables buttons and select box in the purchase section
function buyYN() {
    if (document.querySelector("input[name=buy]:checked").value === "no") {
        plush.disabled = true;
        poster.disabled = true;
        toy.disabled = true;
        pin.disabled = true;
        keychain.disabled = true;
        sticker.disabled = true;
        taxState.disabled = true;
    } else {
        plush.disabled = false;
        poster.disabled = false;
        toy.disabled = false;
        pin.disabled = false;
        keychain.disabled = false;
        sticker.disabled = false;
        taxState.disabled = false;
    }
}



plush.disabled = true;
poster.disabled = true;
toy.disabled = true;
pin.disabled = true;
keychain.disabled = true;
sticker.disabled = true;
taxState.disabled = true;
document.getElementById("contact-form").addEventListener("submit", submission);
document.getElementById("radio-change").addEventListener("change", buyYN);
