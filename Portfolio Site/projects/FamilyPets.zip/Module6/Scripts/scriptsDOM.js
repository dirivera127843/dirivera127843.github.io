// Styling the navigation section with JavaScript
document.querySelector("nav p").style.cssText = "text-align: center; font-weight: bold; margin: 3px;";
document.querySelector("nav ul").style.cssText = "margin: 6px auto; display: flex; justify-content: center; flex-wrap: wrap; list-style: none;";
// Variable and for loop required for styling each navigation button
var classStyle = document.querySelectorAll(".navlink");
for (var i = 0; i < classStyle.length; i++) {
    classStyle[i].style.cssText = "text-decoration: none; margin: 0px 15px; padding: 4px; background-color: white; border-radius: 3px; color: black; line-height: 40px;";
}

// changing the introductory paragraph
document.querySelector(".intro p").innerHTML = "It does not matter the circumstances, it does not matter how much pain I endure, life will always be a blessing. Attitude is what keeps me optimistic, but God is the reason I have faith in my struggles. In all my life, God has never put me in a place where I was meant to fail. I pray that everyone could see themselves as God sees them; loved, cheered on, and led to success. Here is where I find purpose in my career.";

// Defining variables assigned to elements. The Replace variables hold arrays, headingBG is used later for styling
var imageReplace = document.querySelectorAll(".reason img");
var headingReplace = document.querySelectorAll(".content-title");
var headingBG = document.querySelector(".headings");

// Replacing the images with new ones
imageReplace[0].setAttribute("src", "Images/GameDevPhoto.png");
imageReplace[1].setAttribute("src", "Images/DigitalArtPhoto.png");
imageReplace[2].setAttribute("src", "Images/DigitalMusicPhoto.png");

// Replacing the headings for each image's figcaption
headingReplace[0].innerHTML = "Making Memories";
headingReplace[1].innerHTML = "The Art of Creation";
headingReplace[2].innerHTML = "Listen and Enjoy";

// Replacing the small paragraph in each figcaption
document.querySelector("#firstText").innerHTML = "When playing alone, inspiration sparks. When playing together, bonds are formed. Through game development, I'll allow others the opportunity to smile.";
document.querySelector("#secondText").innerHTML = "The world is beautiful, and you have the power to make your own works of art. This applies to all forms of creation. Don't be afraid to share your work.";
document.querySelector("#thirdText").innerHTML = "Sometimes, music speaks to the soul with many meanings. Other times, it creates joy without meaning! Listen for the little moments in life that mean the most.";

// Three functions ready to change the color of the header section
function purpleColor() {
    headingBG.style.backgroundColor = "#5E00CC";
}
function greenColor() {
    headingBG.style.backgroundColor = "#00930A";
}
function blueColor() {
    headingBG.style.backgroundColor = "#0000FF";
}

// Event listeneners waiting for a specific button to be pressed
document.querySelector("#ColorChanging").addEventListener("click", purpleColor);
document.querySelector("#ColorChanged").addEventListener("click", greenColor);
document.querySelector("#ColorChange").addEventListener("click", blueColor);