// Variable definitions. Three different sentences will be utilized throughout the code
var oscarString = "Oscar has 5 kids and a beautiful wife named Stella. 4 of the children are identical twins and the other child is the oldest by 1 year.";
var familyString = "The family has 6 relatives living in the San Antonio area, and 2 more relatives who live within 100 miles of the area.";
var travelString = "This summer they plan on traveling to El Paso to visit as many family members as possible.";

// Storing the numbers in oscarString as string data according to index
var totalKids = oscarString.substr(10, 1);
var twinKids = oscarString.substr(52, 1);
var olderBy = oscarString.substr(127, 1);

// Storing the numbers in familyString as string data according to index
var sanAntFam = familyString.substr(15, 1);
var areaFam = familyString.substr(63, 1);
var miles = familyString.substr(96, 3);

// Splitting the "100" in miles into "10" and "0"
var tenSplit = miles.substr(0, 2);
var zeroSplit = miles.substr(2);

// All string numbers now parsed into integers
var totalKidsInt = parseInt(totalKids);
var twinKidsInt = parseInt(twinKids);
var olderByInt = parseInt(olderBy);
var sanAntFamInt = parseInt(sanAntFam);
var areaFamInt = parseInt(areaFam);
var milesInt = parseInt(miles);
var tenSplitInt = parseInt(tenSplit);
var zeroSplitInt = parseInt(zeroSplit);

// Adding most of the integers together and displaying the sum
var sumTotal = totalKidsInt + twinKidsInt + olderByInt + sanAntFamInt + areaFamInt + tenSplitInt;
console.log("The variable sumTotal is storing " + sumTotal);

// Taking "San Antonio" from familyString and using the new place variable to replace "El Paso" in travelString. Display travelString
var place = familyString.substr(41, 11);
travelString = travelString.replace("El Paso", place);
console.log(travelString);

// A while loop that displays a string with a value incrementing by 1 until said value is greater than 10
while(olderByInt <= tenSplitInt) {
    console.log("I saw " + olderByInt + " car(s) on my trip.");
    olderByInt++;
}