// Accepts user input for a number between 1 and 20. Rejects if input is outside of range or not a number
var firstNum = parseInt(window.prompt("Enter a number between 1 and 20"));
while (firstNum >= 21 || firstNum <= 0 || isNaN(firstNum)) {
    alert("Invalid input");
    firstNum = parseInt(window.prompt("Enter a number between 1 and 20"));
}

// Accepts user input for a number between 1 and 30. Rejects if input is outside of range or not a number
var secondNum = parseInt(window.prompt("Now enter a number between 1 and 30"));
while (secondNum >= 31 || secondNum <= 0 || isNaN(secondNum)) {
    alert("Invalid input");
    secondNum = parseInt(window.prompt("Enter a number between 1 and 30"));
}

// Multiplies both input numbers into a new value
var product = firstNum * secondNum;

// Tests if the product is an even or odd number
if (product % 2 == 0) {
    console.log("The value of " + firstNum + " multiplied by " + secondNum + " is even.");
} else {
    console.log("The value of " + firstNum + " multiplied by " + secondNum + " is odd.");
}