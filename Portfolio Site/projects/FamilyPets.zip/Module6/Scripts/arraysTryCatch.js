// Variable definitions. Two arrays and two values
var siteTopics = ["Pet Name", "Personality", "Items", "Intelligence", "Other Facts"];
var dayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
var firstName = "Daniel";
var yearBorn = 2001;

// Adding a value to the end of siteTopics array and displaying its length
siteTopics.push("Fond Memories");
console.log("The length of the siteTopics array is " + siteTopics.length);
// Then, the loop displays each value of siteTopics
var siteIndex = 0;
while (siteIndex < siteTopics.length) {
    console.log(siteTopics[siteIndex]);
    siteIndex++;
}

// Reversing the order of dayNames, displaying each value, then removing the first value in the array
dayNames.reverse();
for (dayIndex = 0; dayIndex < dayNames.length; dayIndex++) {
    console.log(dayNames[dayIndex]);
}
dayNames.shift();

// try tests if the Sunday value is at the start of dayNames
try {
    if (dayNames[0] === "Sunday") {
        throw "Error: Sunday should be missing!";
    }
}
// catch is thrown an error message if test finds Sunday
catch(messageThrown) {
    console.log(messageThrown);
}
// final message concatenating several values and strings
finally {
    console.log(firstName + " was born in the year " + yearBorn + ". I think the day was either a " + dayNames[1] + " or " + dayNames[3] + ".");
}