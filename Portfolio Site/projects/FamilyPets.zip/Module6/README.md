# 23FA-ITSE2302
<b>This repository stores all my submissions for assignments in the Intermediate Web Programming class.</b><br />
<b>Mastery Assessment 1:</b> A website about several pets my family have owned throughout the years. The first page is about a cat named Conny.<br />
<b>Mastery Assessment 2:</b> Using the previous website's console, practiced various JavaScript code. Shows concepts learned regarding strings, operators and loops.<br />
<b>Mastery Assessment 3:</b> More JavaScript code, including an `if else` statement and user input.<br />
<b>Mastery Assessment 4:</b> JavaScript code for arrays, array methods, and a try/catch/throw/finally test. <br />
<b>Mastery Assessment 5:</b> JavaScript giving functionality to an HTML document. This document adds a new page to the Family Pets website and features a "Contact Us" form.
