import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class GameObject {
    // image that represents the object's position on the board
    private BufferedImage image;
    // current position of the object on the board grid
    private Point pos;

    // Constructor for players, enemies and coins
    public GameObject(String imagePath, int x, int y) {
        // load the assets
        loadImage(imagePath);

        // initialize the state
        pos = new Point(x, y);
    }
    // Constructor for player and obstacles
    public GameObject(String imagePath) {
        // load the assets
        loadImage(imagePath);

        // initialize the state
        pos = new Point(0, 0);
    }

    // Load the image
    protected void loadImage(String path) {
        try {
            // you can use just the filename if the image file is in your
            // project folder, otherwise you need to provide the file path.
            image = ImageIO.read(new File(path));
        } catch (IOException exc) {
            System.out.println("Error opening image file: " + exc.getMessage());
        }
    }

    // Draw this object on the board
    public void draw(Graphics g, ImageObserver observer) {
        // with the Point class, note that pos.getX() returns a double, but 
        // pos.x reliably returns an int. https://stackoverflow.com/a/30220114/4655368
        // this is also where we translate board grid position into a canvas pixel
        // position by multiplying by the tile size.
        g.drawImage(
            image, 
            pos.x * Board.TILE_SIZE, 
            pos.y * Board.TILE_SIZE,
            observer
        );
    }

    // Get the Point class of this GameObject
    public Point getPos() {
        return pos;
    }
}
