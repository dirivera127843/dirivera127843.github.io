import java.awt.event.KeyEvent;

public class Player extends GameObject {
    // keep track of the player's score
    private int score;
    private int playerChar;
    // A small movement buffer to make the player more controllable
    private final int MOVE_BUFFER = 5;
    private int moveBuffer = MOVE_BUFFER;
    // Checks for keys being pressed
    boolean upPressed = false;
    boolean rightPressed = false;
    boolean downPressed = false;
    boolean leftPressed = false;
    // Variables for attacking objects
    boolean attack = true;
    int attackCooldown = 12;

    // Rework this constructor later to set imagePath before reading it in loadImage()
    public Player(String imageSet, int x, int y, int playerCh) {
        super(imageSet, x, y);
        playerChar = playerCh;
    }
    
    public void keyPressed(KeyEvent e) {
        // every keyboard get has a certain code. get the value of that code from the
        // keyboard event so that we can compare it to KeyEvent constants
        int key = e.getKeyCode();
        
        // Change the boolean of the pressed key to true
        if (playerChar == 2) {
            if (key == KeyEvent.VK_UP) {
                upPressed = true;
            }
            if (key == KeyEvent.VK_RIGHT) {
                rightPressed = true;
            }
            if (key == KeyEvent.VK_DOWN) {
                downPressed = true;
            }
            if (key == KeyEvent.VK_LEFT) {
                leftPressed = true;
            }
        } else {
            if (key == KeyEvent.VK_W) {
                upPressed = true;
            }
            if (key == KeyEvent.VK_D) {
                rightPressed = true;
            }
            if (key == KeyEvent.VK_S) {
                downPressed = true;
            }
            if (key == KeyEvent.VK_A) {
                leftPressed = true;
            }
        }
    }

    public void keyReleased(KeyEvent e) {
        // every keyboard get has a certain code. get the value of that code from the
        // keyboard event so that we can compare it to KeyEvent constants
        int key = e.getKeyCode();
        
        // Change the boolean of the released key to false
        if (playerChar == 2) {
            if (key == KeyEvent.VK_UP) {
                upPressed = false;
            }
            if (key == KeyEvent.VK_RIGHT) {
                rightPressed = false;
            }
            if (key == KeyEvent.VK_DOWN) {
                downPressed = false;
            }
            if (key == KeyEvent.VK_LEFT) {
                leftPressed = false;
            }
        } else {
            if (key == KeyEvent.VK_W) {
                upPressed = false;
            }
            if (key == KeyEvent.VK_D) {
                rightPressed = false;
            }
            if (key == KeyEvent.VK_S) {
                downPressed = false;
            }
            if (key == KeyEvent.VK_A) {
                leftPressed = false;
            }
        }
        if (!upPressed && !rightPressed && !downPressed && !leftPressed) {
            moveBuffer = MOVE_BUFFER;
        }
    }

    public void tick() {
        // this gets called once every tick, before the repainting process happens.
        // so we can do anything needed in here to update the state of the player.

        if (upPressed || rightPressed || downPressed || leftPressed) {
            moveBuffer--;
            if (moveBuffer <= 0) {
                moveBuffer = MOVE_BUFFER;
            }
        }
        
        // Move the player if any directional presses are true
        if (upPressed) {
            if (moveBuffer == MOVE_BUFFER - 1) {
                getPos().translate(0, -1);
            }
        }
        if (rightPressed) {
            if (moveBuffer == MOVE_BUFFER - 1) {
                getPos().translate(1, 0);
            }
        }
        if (downPressed) {
            if (moveBuffer == MOVE_BUFFER - 1) {
                getPos().translate(0, 1);
            }
        }
        if (leftPressed) {
            if (moveBuffer == MOVE_BUFFER - 1) {
                getPos().translate(-1, 0);
            }
        }

        // prevent the player from moving off the edge of the board sideways
        if (getPos().x < 0) {
            getPos().x = 0;
        } else if (getPos().x >= Board.COLUMNS) {
            getPos().x = Board.COLUMNS - 1;
        }
        // prevent the player from moving off the edge of the board vertically
        if (getPos().y < 0) {
            getPos().y = 0;
        } else if (getPos().y >= Board.ROWS) {
            getPos().y = Board.ROWS - 1;
        }
    }

    // // Method progresses attack cooldown
    // public void minusCooldown() {
    //     attackCooldown--;
    // }

    // // Method gets cooldown
    // public int getCooldown() {
    //     return attackCooldown;
    // }

    // // Method sets cooldown
    // public void setCooldown(int cool) {
    //     attackCooldown = cool;
    // }

    // // Method gets attack boolean
    // public boolean getAttack() {
    //     return attack;
    // }

    // // Method sets cooldown
    // public void setAttack(boolean att) {
    //     attack = att;
    // }

    // Method returns score for display
    public String getScore() {
        return String.valueOf(score);
    }

    // Method adds (or subtracts) score. Score cannot go below 0
    public void addScore(int amount) {
        score += amount;
        if (score < 0) {
            score = 0;
        }
    }

    // Method resets the score for the next run of the game
    public void resetScore() {
        score = 0;
    }
}
