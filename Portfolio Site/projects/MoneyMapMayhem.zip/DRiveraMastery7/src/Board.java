import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;

public class Board extends JPanel implements ActionListener, KeyListener {
    // controls the delay between each tick in ms
    private final int DELAY = 25;
    // A clock and its own "timer"
    public static int gameTime = 250, timeBuffer = 20;
    // Time it takes to spawn another obstacle and to attack it
    public static int spawnObstacleTime = 150;
    // public static int attackCooldown = 12;
    // public boolean attack = true;
    // Two color change timers to indicate points being gained/lost
    int coinGet = 0;
    int enemyLose = 0;
    // controls the size of the board
    public static final int TILE_SIZE = 60;
    public static final int ROWS = 10;
    public static final int COLUMNS = 16;
    public static final int BOARD_BOTTOM = 80;
    // The two colors of the board
    public static Color tileColor1 = new Color(123, 237, 163);
    public static Color tileColor2 = new Color(155, 242, 226);
    // controls how many coins, obstacles, and enemies appear on the board
    public static final int NUM_COINS = 6;
    public static final int NUM_OBS = 20;
    public static final int NUM_ENEMIES = 3;
    // suppress serialization warning
    private static final long serialVersionUID = 490905409104883233L;
    // All images to load
    public String playerImage = "images/player.png";
    public String player2Image = "images/player2.png";
    public String coinImage = "images/coin.png";
    public String specialCoinImage = "images/specialCoin.png";
    public String obstacleImage = "images/obstacleStrong.png";
    public String enemyImage = "images/enemy.png";
    // Random number generator
    public Random rand = new Random();
    public boolean special;
    int coinX;
    int coinY;
    int nextX;
    int nextY;
    boolean sameSpot;

    Point playerPosBack;
    Point player2PosBack;

    // String controlling game state: "Menu", "Instructions", "Game", and "End"
    public String gameState = "Menu";
    
    // keep a reference to the timer object that triggers actionPerformed() in
    // case we need access to it in another method
    private Timer timer;
    // objects that appear on the game board
    private Player player;
    private Player player2;
    private Enemy enemy1;
    private Enemy enemy2;
    private ArrayList<Enemy> enemies = new ArrayList<>();
    private ArrayList<Coin> coins;
    private ArrayList<Obstacle> obstacles;

    public Board() {
        // set the game board size
        setPreferredSize(new Dimension(TILE_SIZE * COLUMNS, TILE_SIZE * ROWS + BOARD_BOTTOM));
        // set the game board background color
        setBackground(tileColor1);

        // initialize the game state
        player = new Player(playerImage, 0, 0, 1);
        player2 = new Player(player2Image, 15, 0, 2);
        enemy1 = new Enemy(enemyImage, 0, 9);
        enemy2 = new Enemy(enemyImage, 15, 9);
        // Use an enemy list to simplify some code
        enemies.add(enemy1);
        enemies.add(enemy2);
        coins = populateCoins();
        obstacles = populateObstacles();

        // this timer will call the actionPerformed() method every DELAY ms
        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // this method is called by the timer every DELAY ms.
        // use this space to update the state of your game or animation
        // before the graphics are redrawn.

        if (gameState.equals("Game")) {
            // Get the player's position before movements occur
            playerPosBack = player.getPos().getLocation();

            // Allow player to move
            // prevent the player from disappearing off the board
            player.tick();

            // Enemies move. Cannot move off the side of the board
            // Determine the direction they move first
            enemyGo();
            for (Enemy enemy : enemies) {
                enemy.tick();
            }

            // Bump the player back to the stored position if they move to an obstacle
            attackObstacle();

            // give the player points for collecting coins
            collectCoins();
            // Or move a coin if an enemy grabs it first
            enemyCoin();
            // Player loses 500 points if an enemy touches them
            hitEnemy();

            // Game clock counts down to the end of the game
            timeBuffer--;
            if (timeBuffer <= 0) {
                gameTime--;
                timeBuffer = 20;
            }
            // Spawn an obstacle after obstacle time runs out
            spawnObstacleTime--;
            if (spawnObstacleTime <= 0) {
                spawnObstacle();
                spawnObstacleTime = 50 + rand.nextInt(120);
            }
            // Make obstacles last longer by adding a slight cooldown to damaging them
            player.attackCooldown--;
            if (player.attackCooldown <= 0) {
                player.attack = true;
            }
            coinGet--;
            enemyLose--;
            
            // Switch states to end the game when gameTime equals 0
            if (gameTime <= 0) {
                gameState = "End";
            }
        }

        if (gameState.equals("Game2")) {
            // Get the players' positions before movements occur
            playerPosBack = player.getPos().getLocation();
            player2PosBack = player2.getPos().getLocation();

            // Allow players to move
            // prevent the players from disappearing off the board
            player.tick();
            player2.tick();

            // Enemies move. Cannot move off the side of the board
            // Determine the direction they move first
            enemyGo2();
            for (Enemy enemy : enemies) {
                enemy.tick();
            }

            // Bump the player back to the stored position if they move to an obstacle
            attackObstacle();
            // Handle both players bumping into each other
            bumpPlayer();
            // give the player points for collecting coins
            collectCoins();
            // Or move a coin if an enemy grabs it first
            enemyCoin();
            // Player loses 500 points if an enemy touches them
            hitEnemy();

            // Game clock counts down to the end of the game
            timeBuffer--;
            if (timeBuffer <= 0) {
                gameTime--;
                timeBuffer = 20;
            }
            // Spawn an obstacle after obstacle time runs out
            spawnObstacleTime--;
            if (spawnObstacleTime <= 0) {
                spawnObstacle();
                spawnObstacleTime = 50 + rand.nextInt(120);
            }
            // Make obstacles last longer by adding a slight cooldown to damaging them
            player.attackCooldown--;
            if (player.attackCooldown <= 0) {
                player.attack = true;
            }
            player2.attackCooldown--;
            if (player2.attackCooldown <= 0) {
                player2.attack = true;
            }
            coinGet--;
            enemyLose--;
            
            // Switch states to end the game when gameTime equals 0
            if (gameTime <= 0) {
                gameState = "End2";
            }
        }

        // calling repaint() will trigger paintComponent() to run again,
        // which will refresh/redraw the graphics.
        repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        // when calling g.drawImage() we can use "this" for the ImageObserver 
        // because Component implements the ImageObserver interface, and JPanel 
        // extends from Component. So "this" Board instance, as a Component, can 
        // react to imageUpdate() events triggered by g.drawImage()

        if (gameState.equals("Menu") || gameState.equals("End") ||
            gameState.equals("End2") || gameState.equals("Select")) {
            drawText(g);
        }

        if (gameState.equals("Instructions")) {
            GameObject playerInst = new GameObject(playerImage, 1, 1);
            GameObject coinInst = new GameObject(coinImage, 1, 2);
            GameObject coinSpecialInst = new GameObject(specialCoinImage, 1, 3);
            GameObject obstacleInst = new GameObject(obstacleImage, 1, 5);
            GameObject enemyInst = new GameObject(enemyImage, 1, 7);
            drawText(g);
            playerInst.draw(g, this);
            coinInst.draw(g, this);
            coinSpecialInst.draw(g, this);
            obstacleInst.draw(g, this);
            enemyInst.draw(g, this);
        }

        if (gameState.equals("Game")) {
            // draw our graphics.
            drawBackground(g);
            drawText(g);
            for (Coin coin : coins) {
                coin.draw(g, this);
            }
            player.draw(g, this);
            for (Enemy enemy : enemies) {
                enemy.draw(g, this);
            }
            // Only draw obstacles if their visibility is true
            for (Obstacle obstacle : obstacles) {
                if (obstacle.isShowing())
                obstacle.draw(g, this);
            }
        }

        if (gameState.equals("Game2")) {
            // draw our graphics.
            drawBackground(g);
            drawText(g);
            for (Coin coin : coins) {
                coin.draw(g, this);
            }
            player.draw(g, this);
            player2.draw(g, this);
            for (Enemy enemy : enemies) {
                enemy.draw(g, this);
            }
            // Only draw obstacles if their visibility is true
            for (Obstacle obstacle : obstacles) {
                if (obstacle.isShowing())
                obstacle.draw(g, this);
            }
        }

        // this smooths out animations on some systems
        Toolkit.getDefaultToolkit().sync();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // this is not used but must be defined as part of the KeyListener interface
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // react to key down events
        int key = e.getKeyCode();
        if (gameState.equals("Menu")) {
            if (key == KeyEvent.VK_I) {
                gameState = "Instructions";
            }
            if (key == KeyEvent.VK_G) {
                gameState = "Select";
            }
        }
        if (gameState.equals("Instructions")) {
            if (key == KeyEvent.VK_M) {
                gameState = "Menu";
            }
            if (key == KeyEvent.VK_G) {
                gameState = "Select";
            }
        }
        if (gameState.equals("Select")) {
            if (key == KeyEvent.VK_O) {
                gameState = "Game";
            }
            if (key == KeyEvent.VK_T) {
                gameState = "Game2";
            }
        }
        if (gameState.equals("Game")) {
            player.keyPressed(e);
        }
        if (gameState.equals("Game2")) {
            player.keyPressed(e);
            player2.keyPressed(e);
        }
        if (gameState.equals("End")) {
            if (key == KeyEvent.VK_M) {
                resetGame();
                gameState = "Menu";
            }
            if (key == KeyEvent.VK_G) {
                resetGame();
                gameState = "Game";
            }
        }
        if (gameState.equals("End2")) {
            if (key == KeyEvent.VK_M) {
                resetGame();
                gameState = "Menu";
            }
            if (key == KeyEvent.VK_G) {
                resetGame();
                gameState = "Game2";
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // react to key up events
        if (gameState.equals("Game")) {
            player.keyReleased(e);
        }
        if (gameState.equals("Game2")) {
            player.keyReleased(e);
            player2.keyReleased(e);
        }
    }

    private void drawBackground(Graphics g) {
        // draw a checkered background
        g.setColor(tileColor2);
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                // only color every other tile
                if ((row + col) % 2 == 1) {
                    // draw a square tile at the current row/column position
                    g.fillRect(
                        col * TILE_SIZE, 
                        row * TILE_SIZE, 
                        TILE_SIZE, 
                        TILE_SIZE
                    );
                }
            }    
        }
    }

    private void drawText(Graphics g) {
        // we need to cast the Graphics to Graphics2D to draw nicer text
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(
            RenderingHints.KEY_TEXT_ANTIALIASING,
            RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setRenderingHint(
            RenderingHints.KEY_RENDERING,
            RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(
            RenderingHints.KEY_FRACTIONALMETRICS,
            RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        
        // set the text to be displayed
        if (gameState.equals("Menu")) {
            // set the text color and font
            g2d.setColor(new Color(80, 18, 105));
            g2d.setFont(new Font("Lato", Font.BOLD, 40));
            FontMetrics metrics = g2d.getFontMetrics(g2d.getFont());
            String text = "Money Map Mayhem\n\nPress I for instructions\nPress G to play the game";
            int lineHeight = metrics.getHeight();
            // the text will be contained within this rectangle.
            Rectangle rect = new Rectangle(TILE_SIZE * COLUMNS, TILE_SIZE * ROWS + BOARD_BOTTOM);
            // determine the y coordinate for the text
            int y = 160;
            // draw the strings
            String[] lines = text.split("\n");
            for (String line : lines) {
                // Determine X based on rectangle width
                int x = (rect.width / 2) - (metrics.stringWidth(line) / 2);
                g2d.drawString(line, x, y);
                y += lineHeight;
            }
        }
        if (gameState.equals("Instructions")) {
            // set the text color and font
            g2d.setColor(new Color(80, 18, 105));
            g2d.setFont(new Font("Lato", Font.BOLD, 26));
            FontMetrics metrics = g2d.getFontMetrics(g2d.getFont());
            String text = "Instructions\n" +
                "<-- This is you!\nGo for the coins!\nGold coins give $50\nColorful coins give $200\n" +
                "Obstacles block your movement!\nRun into them 3 times to destroy them\n" +
                "Avoid the enemies! They take away $500\nand can go through obstacles\n" +
                "Get as many points as you can before time reaches 0\n" +
                "Press M to return to menu\nPress G to play the game";
            int lineHeight = metrics.getHeight() + 20;
            // determine x and y
            int x = 150;
            int y = 40;
            // draw the strings
            String[] lines = text.split("\n");
            for (String line : lines) {
                g2d.drawString(line, x, y);
                y += lineHeight;
            }
        }
        if (gameState.equals("Select")) {
            // set the text color and font
            g2d.setColor(new Color(80, 18, 105));
            g2d.setFont(new Font("Lato", Font.BOLD, 40));
            FontMetrics metrics = g2d.getFontMetrics(g2d.getFont());
            String text = "Press O for 1 player\nPress T for 2 players\n\nPlayer 1 control with WASD\nPlayer 2 control with arrow keys";
            int lineHeight = metrics.getHeight();
            // the text will be contained within this rectangle.
            Rectangle rect = new Rectangle(TILE_SIZE * COLUMNS, TILE_SIZE * ROWS + BOARD_BOTTOM);
            // determine the y coordinate for the text
            int y = 160;
            // draw the strings
            String[] lines = text.split("\n");
            for (String line : lines) {
                // Determine X based on rectangle width
                int x = (rect.width / 2) - (metrics.stringWidth(line) / 2);
                g2d.drawString(line, x, y);
                y += lineHeight;
            }
        }
        if (gameState.equals("Game")) {
            // set the text color and font
            // Regular color
            g2d.setColor(new Color(80, 18, 105));
            // Magenta color for time running out
            if (gameTime <= 50) {
                g2d.setColor(new Color(196, 0, 154));
            }
            // Dark gold color for coin collection
            if (coinGet > 0) {
                g2d.setColor(new Color(153, 117, 0));
            }
            // Red color for enemy collision
            if (enemyLose > 0) {
                g2d.setColor(new Color(255, 23, 23));
            }
            g2d.setFont(new Font("Lato", Font.BOLD, 35));
            // draw the score and timer in the bottom center of the screen
            // https://stackoverflow.com/a/27740330/4655368
            FontMetrics metrics = g2d.getFontMetrics(g2d.getFont());
            String text = "Score: $" + player.getScore() + "       Time: " + gameTime;
            // the text will be contained within this rectangle placed below the entire board
            Rectangle rect = new Rectangle(0, TILE_SIZE * (ROWS - 1) + BOARD_BOTTOM, TILE_SIZE * COLUMNS, TILE_SIZE);
            // determine the x coordinate for the text
            int x = rect.x + (rect.width - metrics.stringWidth(text)) / 2;
            // determine the y coordinate for the text
            int y = rect.y + ((rect.height - metrics.getHeight()) / 2) + metrics.getAscent();
            // draw the string
            g2d.drawString(text, x, y);
        }
        if (gameState.equals("Game2")) {
            // set the text color and font
            // Regular color
            g2d.setColor(new Color(80, 18, 105));
            // Magenta color for time running out
            if (gameTime <= 50) {
                g2d.setColor(new Color(196, 0, 154));
            }
            // Dark gold color for coin collection
            if (coinGet > 0) {
                g2d.setColor(new Color(153, 117, 0));
            }
            // Red color for enemy collision
            if (enemyLose > 0) {
                g2d.setColor(new Color(255, 23, 23));
            }
            g2d.setFont(new Font("Lato", Font.BOLD, 35));
            // draw the score and timer in the bottom center of the screen
            // https://stackoverflow.com/a/27740330/4655368
            FontMetrics metrics = g2d.getFontMetrics(g2d.getFont());
            String text = "P1 score: $" + player.getScore() + "       Time: " + gameTime +
                "       P2 score: $" + player2.getScore();
            // the text will be contained within this rectangle placed below the entire board
            Rectangle rect = new Rectangle(0, TILE_SIZE * (ROWS - 1) + BOARD_BOTTOM, TILE_SIZE * COLUMNS, TILE_SIZE);
            // determine the x coordinate for the text
            int x = rect.x + (rect.width - metrics.stringWidth(text)) / 2;
            // determine the y coordinate for the text
            int y = rect.y + ((rect.height - metrics.getHeight()) / 2) + metrics.getAscent();
            // draw the string
            g2d.drawString(text, x, y);
        }
        if (gameState.equals("End")) {
            // set the text color and font
            g2d.setColor(new Color(80, 18, 105));
            g2d.setFont(new Font("Lato", Font.BOLD, 45));
            FontMetrics metrics = g2d.getFontMetrics(g2d.getFont());
            String text = "TIME'S UP!!\n\nYour final score is: $" + player.getScore() +
                "\n\nPress M to return to menu\nPress G to play again";
            int lineHeight = metrics.getHeight();
            // the text will be contained within this rectangle
            Rectangle rect = new Rectangle(TILE_SIZE * COLUMNS, TILE_SIZE * ROWS + BOARD_BOTTOM);
            // determine the y coordinate for the text
            int y = 160;
            // draw the strings
            String[] lines = text.split("\n");
            for (String line : lines) {
                // Determine X based on rectangle width
                int x = (rect.width / 2) - (metrics.stringWidth(line) / 2);
                g2d.drawString(line, x, y);
                y += lineHeight;
            }
        }
        if (gameState.equals("End2")) {
            // set the text color and font
            g2d.setColor(new Color(80, 18, 105));
            g2d.setFont(new Font("Lato", Font.BOLD, 45));
            FontMetrics metrics = g2d.getFontMetrics(g2d.getFont());
            String text = "TIME'S UP!!\n\nThe scores are:\n Player 1: $" + player.getScore() +
                "       P2 score: $" + player2.getScore();
            if (Integer.parseInt(player.getScore()) > Integer.parseInt(player2.getScore())) {
                text += "\nPlayer 1 wins!";
            } else if (Integer.parseInt(player.getScore()) < Integer.parseInt(player2.getScore())) {
                text += "\nPlayer 2 wins!";
            } else {
                text += "\nIt's a tie!?";
            }
            text += "\n\nPress M to return to menu\nPress G to play again";
            int lineHeight = metrics.getHeight();
            // the text will be contained within this rectangle
            Rectangle rect = new Rectangle(TILE_SIZE * COLUMNS, TILE_SIZE * ROWS + BOARD_BOTTOM);
            // determine the y coordinate for the text
            int y = 160;
            // draw the strings
            String[] lines = text.split("\n");
            for (String line : lines) {
                // Determine X based on rectangle width
                int x = (rect.width / 2) - (metrics.stringWidth(line) / 2);
                g2d.drawString(line, x, y);
                y += lineHeight;
            }
        }
    }

    // Method creates 6 coins
    private ArrayList<Coin> populateCoins() {
        ArrayList<Coin> coinList = new ArrayList<>();

        // create the given number of coins in random positions on the board.
        for (int i = 0; i < NUM_COINS; i++) {
            // A method for this code was created, but only prior to the coins list being
            // initialized. This loop uses coinList instead of coins
            do {
                sameSpot = false;
                coinX = rand.nextInt(COLUMNS);
                coinY = rand.nextInt(ROWS);
                // Check player position
                if (coinX == player.getPos().getX() && coinY == player.getPos().getY() ||
                    coinX == player2.getPos().getX() && coinY == player2.getPos().getY()) {
                    sameSpot = true;
                }
                // Check coin positions
                if (!sameSpot) {
                    for (Coin newCoin : coinList) {
                        // If the same spot is found, the do/while loop generates a new x, y
                        if (coinX == newCoin.getPos().getX() && coinY == newCoin.getPos().getY()) {
                            sameSpot = true;
                            break;
                        }
                    }
                }
            } while (sameSpot);
            
            // If it's the last coin, make it a special coin
            if (i == NUM_COINS - 1) {
                special = true;
                coinList.add(new Coin(specialCoinImage, coinX, coinY, 200));
            } else {
                coinList.add(new Coin(coinImage, coinX, coinY, 50));
            }
        }

        return coinList;
    }

    // Method creates 20 obstacles
    private ArrayList<Obstacle> populateObstacles() {
        ArrayList<Obstacle> obsList = new ArrayList<>();

        // create the given number of obstacles. Their positions will be set later
        for (int i = 0; i < NUM_OBS; i++) {
            obsList.add(new Obstacle(obstacleImage));
        }

        return obsList;
    }

    // Method weakens/destroys an obstacle when the player bumps into it
    private void attackObstacle() {
        for (Obstacle activeObs : obstacles) {
            if (activeObs.isShowing()) {
                if (player.getPos().equals(activeObs.getPos())) {
                    // Move player back to their last position
                    player.getPos().setLocation(playerPosBack);
                    // Damage the obstacle if cooldown is ready
                    if (player.attack) {
                        activeObs.damage();
                        player.attackCooldown = 12;
                        player.attack = false;
                    }
                }
                // Only check for player2 in the proper game state
                if (gameState.equals("Game2")) {
                    if (player2.getPos().equals(activeObs.getPos())) {
                        // Move player back to their last position
                        player2.getPos().setLocation(player2PosBack);
                        // Damage the obstacle if cooldown is ready
                        if (player2.attack) {
                            activeObs.damage();
                            player2.attackCooldown = 12;
                            player2.attack = false;
                        }
                    }
                }
            }
        }
    }

    // Method prevents both players from being on the same spot
    private void bumpPlayer() {
        if (player.getPos().equals(player2.getPos())) {
            // Move players back to their last position
            player.getPos().setLocation(playerPosBack);
            player2.getPos().setLocation(player2PosBack);
        }
    }

    // Method adds score when a player gets a coin
    private void collectCoins() {
        // allow player to pickup coins
        for (Coin coin : coins) {
            // if the player is on the same tile as a coin, collect it
            if (player.getPos().equals(coin.getPos())) {
                // give the player some points for picking this up
                player.addScore(coin.getPointValue());
                coinGet = 8;
                // If the collected coin was a special coin, change boolean and the coin's value and image
                if (coin.getPointValue() > 51) {
                    special = false;
                    coin.changeCoin(coinImage, 50);
                }
                // If there is not already a special coin...
                if (special == false) {
                    // Roll for a 1/6 chance to change this coin to a special one
                    int chance = rand.nextInt(6);
                    if (chance == 0) {
                        special = true;
                        coin.changeCoin(specialCoinImage, 200);
                    }
                }
                // Prevent the coin from spawning on top of another object
                testCoinPosition();
                // Apply new position to the coin
                coin.getPos().setLocation(coinX, coinY);
            }
            // Only check for player2 in the proper game state
            if (gameState.equals("Game2")) {
                // if the player is on the same tile as a coin, collect it
                if (player2.getPos().equals(coin.getPos())) {
                    // give the player some points for picking this up
                    player2.addScore(coin.getPointValue());
                    coinGet = 8;
                    // If the collected coin was a special coin, change boolean and the coin's value and image
                    if (coin.getPointValue() > 51) {
                        special = false;
                        coin.changeCoin(coinImage, 50);
                    }
                    // If there is not already a special coin...
                    if (special == false) {
                        // Roll for a 1/6 chance to change this coin to a special one
                        int chance = rand.nextInt(6);
                        if (chance == 0) {
                            special = true;
                            coin.changeCoin(specialCoinImage, 200);
                        }
                    }
                    // Prevent the coin from spawning on top of another object
                    testCoinPosition();
                    // Apply new position to the coin
                    coin.getPos().setLocation(coinX, coinY);
                }
            }
        }
    }

    // Method for when an enemy touches a coin
    private void enemyCoin() {
        for (Coin coin : coins) {
            for (Enemy enemy : enemies) {
                // If an enemy is on the same tile as a coin, move it
                // Special coins are not removed in this case
                if (enemy.getPos().equals(coin.getPos())) {
                    testCoinPosition();
                    coin.getPos().setLocation(coinX, coinY);
                    // If both enemies are targetting the same coin, make them both stop
                    if (enemy1.coinTarget < NUM_COINS && enemy2.coinTarget < NUM_COINS && enemy1.coinTarget == enemy2.coinTarget) {
                        enemy1.targetCoin(6);
                        enemy2.targetCoin(6);
                    } else {
                        // Stop targetting the coin
                        enemy.targetCoin(6);
                    }
                }
            }
        }
    }

    // Method for when an enemy touches the player
    private void hitEnemy() {
        for (Enemy enemy : enemies) {
            if (player.getPos().equals(enemy.getPos())) {
                // Lose 500 points
                player.addScore(-500);
                enemyLose = 8;
                // Move the enemy away from the player in the farthest corner of the map
                if (player.getPos().x < COLUMNS / 2) {
                    enemy.getPos().x = COLUMNS;
                } else {
                    enemy.getPos().x = 0;
                }
                if (player.getPos().y < ROWS / 2) {
                    enemy.getPos().y = ROWS;
                } else {
                    enemy.getPos().y = 0;
                }
                // Reset coin target
                enemy.targetCoin(6);
            }
            // Only check for player2 in the proper game state
            if (gameState.equals("Game2")) {
                if (player2.getPos().equals(enemy.getPos())) {
                    // Lose 500 points
                    player2.addScore(-500);
                    enemyLose = 8;
                    // Move the enemy away from the player in the farthest corner of the map
                    if (player2.getPos().x < COLUMNS / 2) {
                        enemy.getPos().x = COLUMNS;
                    } else {
                        enemy.getPos().x = 0;
                    }
                    if (player2.getPos().y < ROWS / 2) {
                        enemy.getPos().y = ROWS;
                    } else {
                        enemy.getPos().y = 0;
                    }
                    // Reset coin target
                    enemy.targetCoin(6);
                }
            }
        }
    }

    // Method for determining the enemy's movement AI
    private void enemyGo() {
        for (Enemy enemy : enemies) {
            // Enemies will target the player first
            if (player.getPos().getX() == enemy.getPos().getX()) {
                // Reset the enemy's target to not match any coin
                enemy.targetCoin(6);
                if (player.getPos().getY() < enemy.getPos().getY()) {
                    // Player is above enemy. Move up
                    enemy.direction(0);
                } else {
                    // Player is below enemy. Move down
                    enemy.direction(2);
                }
            } else if (player.getPos().getY() == enemy.getPos().getY()) {
                enemy.targetCoin(6);
                if (player.getPos().getX() < enemy.getPos().getX()) {
                    // Player is left of enemy. Move left
                    enemy.direction(3);
                } else {
                    // Player is right of enemy. Move right
                    enemy.direction(1);
                }
            } // Next, target coins.
            else if (enemy.coinLock) {
                if (coins.get(enemy.coinTarget).getPos().getX() == enemy.getPos().getX()) {
                    if (coins.get(enemy.coinTarget).getPos().getY() < enemy.getPos().getY()) {
                        // Coin is above enemy. Move up
                        enemy.direction(0);
                    } else {
                        // Coin is below enemy. Move down
                        enemy.direction(2);
                    }
                } else if (coins.get(enemy.coinTarget).getPos().getY() == enemy.getPos().getY()) {
                    if (coins.get(enemy.coinTarget).getPos().getX() < enemy.getPos().getX()) {
                        // Coin is left of enemy. Move left
                        enemy.direction(3);
                    } else {
                        // Coin is right of enemy. Move right
                        enemy.direction(1);
                    }
                } else {
                    // The enemy is no longer in line with the coin it saw. Reset the enemy's target to not match any coin
                        enemy.targetCoin(6);
                        enemy.direction(4);
                }
            } // If neither the player or the coins are targetted, move randomly
            else {
                enemy.direction(4);
                // If the enemy sees a coin, set a target through index
                for (int i = 0; i < coins.size(); i++) {
                    if (enemy.getPos().getX() == coins.get(i).getPos().getX() || enemy.getPos().getY() == coins.get(i).getPos().getY()) {
                        enemy.targetCoin(i);
                        break;
                    }
                }
            }
        }
    }

    // Method for determining the enemy's movement AI in a 2 player game
    private void enemyGo2() {
        for (Enemy enemy : enemies) {
            int p1x = player.getPos().x;
            int p1y = player.getPos().y;
            int p2x = player2.getPos().x;
            int p2y = player2.getPos().y;
            int enx = enemy.getPos().x;
            int eny = enemy.getPos().y;
            // Enemies will target players first. The closer player gets chased
            if ((p1x == enx || p1y == eny) && !(p2x == enx || p2y == eny)) {
                if (p1x == enx) {
                    // Reset the enemy's target to not match any coin
                    enemy.targetCoin(6);
                    if (p1y < eny) {
                        // Player is above enemy. Move up
                        enemy.direction(0);
                    } else {
                        // Player is below enemy. Move down
                        enemy.direction(2);
                    }
                } else if (p1y == eny) {
                    enemy.targetCoin(6);
                    if (p1x < enx) {
                        // Player is left of enemy. Move left
                        enemy.direction(3);
                    } else {
                        // Player is right of enemy. Move right
                        enemy.direction(1);
                    }
                }
            } else if ((p2x == enx || p2y == eny) && !(p1x == enx || p1y == eny)) {
                if (p2x == enx) {
                    // Reset the enemy's target to not match any coin
                    enemy.targetCoin(6);
                    if (p2y < eny) {
                        // Player is above enemy. Move up
                        enemy.direction(0);
                    } else {
                        // Player is below enemy. Move down
                        enemy.direction(2);
                    }
                } else if (p2y == eny) {
                    enemy.targetCoin(6);
                    if (p2x < enx) {
                        // Player is left of enemy. Move left
                        enemy.direction(3);
                    } else {
                        // Player is right of enemy. Move right
                        enemy.direction(1);
                    }
                }
            } else if ((p1x == enx || p1y == eny) && (p2x == enx || p2y == eny)) {
                // Both players are in sight. Determine which player to move towards
                int closer = enemy.closerPlayer(player.getPos(), player2.getPos());
                switch (closer) {
                    case 1:
                        // Player 1 is closer. Move to player 1
                        if (p1x == enx) {
                            // Reset the enemy's target to not match any coin
                            enemy.targetCoin(6);
                            if (p1y < eny) {
                                // Player is above enemy. Move up
                                enemy.direction(0);
                            } else {
                                // Player is below enemy. Move down
                                enemy.direction(2);
                            }
                        } else if (p1y == eny) {
                            enemy.targetCoin(6);
                            if (p1x < enx) {
                                // Player is left of enemy. Move left
                                enemy.direction(3);
                            } else {
                                // Player is right of enemy. Move right
                                enemy.direction(1);
                            }
                        }
                        break;
                    case 2:
                        // Player 2 is closer. Move to player 2
                        if (p2x == enx) {
                            // Reset the enemy's target to not match any coin
                            enemy.targetCoin(6);
                            if (p2y < eny) {
                                // Player is above enemy. Move up
                                enemy.direction(0);
                            } else {
                                // Player is below enemy. Move down
                                enemy.direction(2);
                            }
                        } else if (p2y == eny) {
                            enemy.targetCoin(6);
                            if (p2x < enx) {
                                // Player is left of enemy. Move left
                                enemy.direction(3);
                            } else {
                                // Player is right of enemy. Move right
                                enemy.direction(1);
                            }
                        }
                        break;
                    default:
                        // Both players are the same distance. Pick randomly who to target
                        Random randTarget = new Random();
                        if (randTarget.nextInt(2) == 0) {
                            if (p1x == enx) {
                                // Reset the enemy's target to not match any coin
                                enemy.targetCoin(6);
                                if (p1y < eny) {
                                    // Player is above enemy. Move up
                                    enemy.direction(0);
                                } else {
                                    // Player is below enemy. Move down
                                    enemy.direction(2);
                                }
                            } else if (p1y == eny) {
                                enemy.targetCoin(6);
                                if (p1x < enx) {
                                    // Player is left of enemy. Move left
                                    enemy.direction(3);
                                } else {
                                    // Player is right of enemy. Move right
                                    enemy.direction(1);
                                }
                            }
                        } else {
                            if (p2x == enx) {
                                // Reset the enemy's target to not match any coin
                                enemy.targetCoin(6);
                                if (p2y < eny) {
                                    // Player is above enemy. Move up
                                    enemy.direction(0);
                                } else {
                                    // Player is below enemy. Move down
                                    enemy.direction(2);
                                }
                            } else if (p2y == eny) {
                                enemy.targetCoin(6);
                                if (p2x < enx) {
                                    // Player is left of enemy. Move left
                                    enemy.direction(3);
                                } else {
                                    // Player is right of enemy. Move right
                                    enemy.direction(1);
                                }
                            }
                        }
                        break;
                }
            } // Next, target coins.
            else if (enemy.coinLock) {
                if (coins.get(enemy.coinTarget).getPos().getX() == enx) {
                    if (coins.get(enemy.coinTarget).getPos().getY() < eny) {
                        // Coin is above enemy. Move up
                        enemy.direction(0);
                    } else {
                        // Coin is below enemy. Move down
                        enemy.direction(2);
                    }
                } else if (coins.get(enemy.coinTarget).getPos().getY() == eny) {
                    if (coins.get(enemy.coinTarget).getPos().getX() < enx) {
                        // Coin is left of enemy. Move left
                        enemy.direction(3);
                    } else {
                        // Coin is right of enemy. Move right
                        enemy.direction(1);
                    }
                } else {
                    // The enemy is no longer in line with the coin it saw. Reset the enemy's target to not match any coin
                        enemy.targetCoin(6);
                        enemy.direction(4);
                }
            } // If neither a player or coin is targetted, move randomly
            else {
                enemy.direction(4);
                // If the enemy sees a coin, set a target through index
                for (int i = 0; i < coins.size(); i++) {
                    if (enx == coins.get(i).getPos().getX() || eny == coins.get(i).getPos().getY()) {
                        enemy.targetCoin(i);
                        break;
                    }
                }
            }
        }
    }

    // Method for spawning an obstacle
    public void spawnObstacle() {
        for (Obstacle obsTime : obstacles) {
            if (!obsTime.isShowing()) {
                testPosition();
                obsTime.spawn(nextX, nextY);
                break;
            }
        }
    }

    // Method prevents obstacles from spawning on top of player/enemies/coins
    public void testPosition() {
        // Check through each object to see if its position matches the newly generated position
        do {
            sameSpot = false;
            nextX = rand.nextInt(COLUMNS);
            nextY = rand.nextInt(ROWS);
            // Check player position
            if (nextX == player.getPos().getX() && nextY == player.getPos().getY()) {
                sameSpot = true;
            }
            // Check player 2 position (only in 2 player)
            if (gameState.equals("Game2")) {
                if (nextX == player2.getPos().getX() && nextY == player2.getPos().getY()) {
                sameSpot = true;
                }
            }
            // Check enemy positions
            if (!sameSpot) {
                for (Enemy enemy : enemies) {
                    // If the same spot is found, the do/while loop generates a new x, y
                    if (nextX == enemy.getPos().getX() && nextY == enemy.getPos().getY()) {
                        sameSpot = true;
                        break;
                    }
                }
            }
            // Check coin positions
            if (!sameSpot) {
                for (Coin newCoin : coins) {
                    // If the same spot is found, the do/while loop generates a new x, y
                    if (nextX == newCoin.getPos().getX() && nextY == newCoin.getPos().getY()) {
                        sameSpot = true;
                        break;
                    }
                }
            }
            // Check active obstacle positions
            if (!sameSpot) {
                for (Obstacle newObs : obstacles) {
                    // If the same spot is found, the do/while loop generates a new x, y
                    // Only test position for obstacles that are showing
                    if (newObs.isShowing()) {
                        if (nextX == newObs.getPos().getX() && nextY == newObs.getPos().getY()) {
                            sameSpot = true;
                            break;
                        }
                    }
                }
            }
        } while (sameSpot);
    }

    // Coins and obstacles are both random. A separate method and variables prevent
    // unintended positions if both objects spawn at a similar time
    public void testCoinPosition() {
        // Check through each object to see if its position matches the newly generated position
        do {
            sameSpot = false;
            coinX = rand.nextInt(COLUMNS);
            coinY = rand.nextInt(ROWS);
            // Check player position
            if (coinX == player.getPos().getX() && coinY == player.getPos().getY()) {
                sameSpot = true;
            }
            // Check player 2 position (only in 2 player)
            if (gameState.equals("Game2")) {
                if (nextX == player2.getPos().getX() && nextY == player2.getPos().getY()) {
                sameSpot = true;
                }
            }
            // Check enemy positions
            if (!sameSpot) {
                for (Enemy enemy : enemies) {
                    // If the same spot is found, the do/while loop generates a new x, y
                    if (coinX == enemy.getPos().getX() && coinY == enemy.getPos().getY()) {
                        sameSpot = true;
                        break;
                    }
                }
            }
            // Check coin positions
            if (!sameSpot) {
                for (Coin newCoin : coins) {
                    // If the same spot is found, the do/while loop generates a new x, y
                    if (coinX == newCoin.getPos().getX() && coinY == newCoin.getPos().getY()) {
                        sameSpot = true;
                        break;
                    }
                }
            }
            // Check active obstacle positions
            if (!sameSpot) {
                for (Obstacle newObs : obstacles) {
                    // If the same spot is found, the do/while loop generates a new x, y
                    // Only test position for obstacles that are showing
                    if (newObs.isShowing()) {
                        if (coinX == newObs.getPos().getX() && coinY == newObs.getPos().getY()) {
                            sameSpot = true;
                            break;
                        }
                    }
                }
            }
        } while (sameSpot);
    }

    // Method to reset the game
    private void resetGame() {
        // Hide all obstacles
        for (Obstacle obs : obstacles) {
            obs.resetShow();
        }
        // Reset locations
        player.getPos().setLocation(0, 0);
        player2.getPos().setLocation(15, 0);
        enemy1.getPos().setLocation(0, 9);
        enemy2.getPos().setLocation(15, 9);
        // Repopulate coins
        coins.clear();
        coins = populateCoins();
        // Reset score
        player.resetScore();
        // Reset game time
        gameTime = 250;
    }
}
