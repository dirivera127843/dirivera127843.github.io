public class Obstacle extends GameObject {
    // Boolean determining whether to show draw this obstacle or detect its collision and position
    private boolean showing = false;
    // Integer for the obstacle's "health"
    private int strength = 3;

    public Obstacle(String imageSet) {
        super(imageSet);
    }

    // Method resets all obstacles so the game can start fresh
    public void resetShow() {
        strength = 0;
        showing = false;
    }

    // Method returns showing
    public boolean isShowing() {
        return showing;
    }

    // Method decreases obstacle by 1, destroying it if strength hits 0
    public void damage() {
        strength--;
        if (strength <= 0) {
            showing = false;
        }
        changeLook();
    }

    // Method spawns in an obstacle at full strength
    public void spawn(int newX, int newY) {
        strength = 3;
        getPos().setLocation(newX, newY);
        changeLook();
        showing = true;
    }

    // Method changes the image of the obstacle to visually indicate its "health"
    private void changeLook() {
        if (strength == 3) {
            loadImage("images/obstacleStrong.png");
        }
        if (strength == 2) {
            loadImage("images/obstacleMid.png");
        }
        if (strength == 1) {
            loadImage("images/obstacleWeak.png");
        }
    }
}
