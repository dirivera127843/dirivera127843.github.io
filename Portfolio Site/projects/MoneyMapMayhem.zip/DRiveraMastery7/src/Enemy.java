import java.awt.Point;
import java.util.Random;

public class Enemy extends GameObject {
    // Variables
    private Random randMove = new Random();
    int moveDirection = 0;
    int moveTime = 25;
    boolean coinLock = false;
    int coinTarget = 6;

    public Enemy(String imageSet, int x, int y) {
        super(imageSet, x, y);
    }

    // Determine which player is closer
    public int closerPlayer(Point p1Pos, Point p2Pos) {
        if (this.getPos().distance(p1Pos) < this.getPos().distance(p2Pos)) {
            return 1;
        } else if (this.getPos().distance(p1Pos) > this.getPos().distance(p2Pos)) {
            return 2;
        } else {
            return 3;
        }
    }

    // Method changing the direction that the enemy will move
    public void direction(int direction) {
        if (direction >= 4) {
            moveDirection = randMove.nextInt(4);
        } else {
            moveDirection = direction;
        }
    }

    // Method making an enemy chase after a coin in its sights
    public void targetCoin(int coin) {
        if (coin > 5) {
            coinLock = false;
        } else {
            coinLock = true;
        }
        coinTarget = coin;
    }

    // Method moves the enemy according to the direction it is facing
    private void move(int move) {
        switch (move) {
            case 0:
                // Move up
                getPos().translate(0, -1);
                break;
            case 1:
                // Move right
                getPos().translate(1, 0);
                break;
            case 2:
                // Move down
                getPos().translate(0, 1);
                break;
            case 3:
                // Move left
                getPos().translate(-1, 0);
                break;
            default:
                // Move up
                getPos().translate(0, -1);
        }
        moveTime = 10 + randMove.nextInt(15);
    }

    // Method runs every tick
    public void tick() {
        // Decrease the movement time and move according to direction
        moveTime--;
        if (moveTime <= 0) {
            move(moveDirection);
        }

        // prevent the enemy from moving off the edge of the board sideways
        if (getPos().x < 0) {
            getPos().x = 0;
        } else if (getPos().x >= Board.COLUMNS) {
            getPos().x = Board.COLUMNS - 1;
        }
        // prevent the enemy from moving off the edge of the board vertically
        if (getPos().y < 0) {
            getPos().y = 0;
        } else if (getPos().y >= Board.ROWS) {
            getPos().y = Board.ROWS - 1;
        }
    }
}
