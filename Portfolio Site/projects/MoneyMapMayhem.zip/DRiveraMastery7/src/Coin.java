public class Coin extends GameObject {
    // Integer of the coin's worth
    private int pointValue;
    
    public Coin(String imageSet, int x, int y, int pValue) {
        super(imageSet, x, y);
        pointValue = pValue;
    }

    // Return this coin's point value
    public int getPointValue() {
        return pointValue;
    }

    // Method changes this coin between a regular coin and a special coin
    public void changeCoin(String path, int newValue) {
        loadImage(path);
        pointValue = newValue;
    }

    // Method moves the coin when the player or an enemy collects it
    public void changePosition(int newX, int newY) {
        getPos().setLocation(newX, newY);
    }
}
