package danielriveram6;

public class Customer extends Person {
    // Variable declarations
    double totalSpending, balanceOwed;
    
    // Default constructor
    public Customer()
    {
        totalSpending = 0.0;
        balanceOwed = 0.0;
    }
    // Constructor with definitions
    public Customer(String nam, String phoneNum, String logNam, String pWord,
            String addr, int idNum, double ttlSpend, double blncOwd)
    {
        super(nam, phoneNum, logNam, pWord, addr, idNum);
        this.totalSpending = ttlSpend;
        this.balanceOwed = blncOwd;
    }
    
    // New .toString() override
    public String toString()
    {
        String returnString = super.toString();
        returnString += "\nTotal spending: $" + String.format("%.2f", this.totalSpending)
                + "\nBalance owed: $" + String.format("%.2f", this.balanceOwed);
        return returnString;
    }
}
