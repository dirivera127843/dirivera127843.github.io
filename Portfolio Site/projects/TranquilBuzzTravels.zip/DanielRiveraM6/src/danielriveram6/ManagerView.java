package danielriveram6;

import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;

public class ManagerView extends State {
    // Definitions
    String inputNam, inputPhoneNum, inputLogNam, inputPWord, inputAddr;
    int largestID;
    String inputHDate;
    double inputSal;
    boolean inputIsMngr;
    static ArrayList<TravelAgencyEmployee> employees = new ArrayList();
    
    void enter()
    {
        System.out.println("\n1. Add Employee"
        + "\n2. Edit Employee"
        + "\n3. Remove Employee"
        + "\n4. List Employees"
        + "\n5. Make Employee A Manager"
        + "\n6. Manage Lodges"
        + "\n7. Log out"
        + "\n\nSelect from the menu:");
    }
    
    // Any time the file is read, repopulate the array list
    void load()
    {
        try {
            // Create FileReader
            FileReader empReader = new FileReader("employees.txt");
            BufferedReader empBuff = new BufferedReader(empReader);
            String currentLine;
            // Read the next 9 lines and put them in the ArrayList
            while ((currentLine = empBuff.readLine()) != null) {
                String readName = currentLine;
                currentLine = empBuff.readLine();
                String readPhone = currentLine;
                currentLine = empBuff.readLine();
                String readUser = currentLine;
                // The password needs to be decoded
                currentLine = empBuff.readLine();
                String readPass = currentLine;
                // Delete the last two characters
                StringBuilder passEdit = new StringBuilder(readPass);
                int length = passEdit.length();
                passEdit = passEdit.delete(length - 2, length);
                // Reverse the string
                passEdit = passEdit.reverse();
                String swapPass = passEdit.toString();
                String truePass = "";
                char c;
                int code;
                // Change each character by its ASCII code by -4
                for (int i = 0; i < swapPass.length(); i++) {
                    c = swapPass.charAt(i);
                    code = (int) c;
                    code -= 4;
                    c = (char) code;
                    truePass = truePass + c;
                }
                currentLine = empBuff.readLine();
                String readAddr = currentLine;
                currentLine = empBuff.readLine();
                int readID = Integer.parseInt(currentLine);
                // Store largest ID to give each new customer a unique ID
                largestID = readID;
                currentLine = empBuff.readLine();
                String readHire = currentLine;
                currentLine = empBuff.readLine();
                double readSalary = Double.parseDouble(currentLine);
                currentLine = empBuff.readLine();
                boolean readIsMan = Boolean.parseBoolean(currentLine);
                // Use values to create an employee
                TravelAgencyEmployee readEmployee = new TravelAgencyEmployee(readName, readPhone, readUser,
                        truePass, readAddr, readID, readHire, readSalary, readIsMan);
                employees.add(readEmployee);
            }
        } catch (IOException ex) {
            System.out.println("Error loading file.");
        }
    }
    
    // Any time the file is saved, clear the array list
    void save()
    {
        try {
            // Create Writers
            FileWriter empSave = new FileWriter("employees.txt");
            BufferedWriter buffSave = new BufferedWriter(empSave);
            // Print each customers' values to the file
            for (int i = 0; i < employees.size(); i++) {
                buffSave.append(employees.get(i).name + "\r\n");
                buffSave.append(employees.get(i).phoneNumber + "\r\n");
                buffSave.append(employees.get(i).loginName + "\r\n");
                // Encrypt the password before saving
                String truePass = employees.get(i).password;
                String swapPass = "";
                char c;
                int code = 33;
                // Change each character by its ASCII code by +4
                for (int j = 0; j < truePass.length(); j++) {
                    c = truePass.charAt(j);
                    code = (int) c;
                    code += 4;
                    c = (char) code;
                    swapPass = swapPass + c;
                }
                // Reverse the string
                StringBuilder passSwapper = new StringBuilder(swapPass);
                passSwapper = passSwapper.reverse();
                // Add two characters unrelated to the password
                code += 2;
                passSwapper = passSwapper.append((char) code);
                code += 2;
                passSwapper = passSwapper.append((char) code);
                // Save the encrypted password
                String savedPass = passSwapper.toString();
                buffSave.append(savedPass + "\r\n");
                buffSave.append(employees.get(i).address + "\r\n");
                buffSave.append(employees.get(i).idNumber + "\r\n");
                buffSave.append(employees.get(i).hireDate + "\r\n");
                buffSave.append(employees.get(i).salary + "\r\n");
                // If it's the final object on the list, don't move to the next line
                if (i < employees.size() - 1) {
                    buffSave.append(employees.get(i).isAManager + "\r\n");
                } else {
                    buffSave.append(employees.get(i).isAManager + "");
                }
            }
            // Save file
            buffSave.close();
        } catch (IOException ex) {
            System.out.println("Error saving file.");
        }
        // Even when failing, clear the list so the next load is not inaccurate
        employees.clear();
    }
    
    void update()
    {
        while (true)
        {
            Scanner s = new Scanner(System.in);
            String input = s.nextLine();
            
            // Switch statement determines necessary actions to take
            switch (input)
            {
                case "1":
                    // Add new Employee
                    // Input Strings: name, phoneNumber, loginName, password, address
                    System.out.println("Enter Employee name:");
                    inputNam = s.nextLine();
                    System.out.println("Enter Employee phone number:");
                    inputPhoneNum = s.nextLine();
                    System.out.println("Enter Employee username:");
                    inputLogNam = s.nextLine();
                    System.out.println("Enter Employee password:");
                    inputPWord = s.nextLine();
                    System.out.println("Enter Employee address:");
                    inputAddr = s.nextLine();
                    // idNumber must be generated by the code
                    // Input String: hireDate
                    System.out.println("Enter Employee hiring date (MM/DD/YYYY):");
                    inputHDate = s.nextLine();
                    // Input double: salary
                    System.out.println("Enter Employee monthly salary:");
                    inputSal = Double.parseDouble(s.nextLine());
                    // Manager must use option 4 to promote an employee to manager
                    inputIsMngr = false;
                    
                    // Create Employee with all the inputs above
                    load();
                    TravelAgencyEmployee newTAEmployee;
                    newTAEmployee = new TravelAgencyEmployee(inputNam, inputPhoneNum,
                    inputLogNam, inputPWord, inputAddr, largestID + 1, inputHDate,
                    inputSal, inputIsMngr);
                    employees.add(newTAEmployee);
                    save();
                    System.out.println("New Employee added to list.");
                    return;
                case "2":
                    // Edit Employee. Loop to print each employee to the console
                    load();
                    for (int i = 0; i < employees.size(); ++i)
                    {
                        System.out.println((i + 1) + ". " + employees.get(i).name);
                    }
                    System.out.println("\nSelect which employee to edit:");
                    int edit = Integer.parseInt(s.nextLine());
                    edit -= 1;
                    
                    // Check if input is in range
                    if ((edit < employees.size()) && edit >= 0)
                    {
                        // Only the name, username, and password of an employee can be changed.
                        System.out.println("\nEditing options:"
                                + "\n1. Name"
                                + "\n2. Username"
                                + "\n3. Password"
                                + "\n\nSelect information to edit:");
                        String editChoice = s.nextLine();
                        
                        // switch statement to change information
                        switch (editChoice)
                        {
                            case "1":
                                System.out.println("Enter new name for " + employees.get(edit).name + ":");
                                inputNam = s.nextLine();
                                employees.get(edit).name = inputNam;
                                System.out.println("Changed employee's name to " + employees.get(edit).name + ".");
                                save();
                                break;
                            case "2":
                                System.out.println("Enter new username for " + employees.get(edit).name + ":");
                                inputLogNam = s.nextLine();
                                employees.get(edit).loginName = inputLogNam;
                                System.out.println("Changed employee's username to " + employees.get(edit).loginName + ".");
                                save();
                                break;
                            case "3":
                                System.out.println("Enter new password for " + employees.get(edit).name + ":");
                                inputPWord = s.nextLine();
                                employees.get(edit).password = inputPWord;
                                System.out.println("Succesfully changed employee's password.");
                                save();
                                break;
                            default:
                                System.out.println("\n*** Invalid input. Edit canceled");
                                // No changes. Clear without saving
                                employees.clear();
                                break;
                        }
                    }
                    else
                    {
                        System.out.println("\n*** Invalid input. Edit canceled");
                        // No changes. Clear without saving
                        employees.clear();
                    }
                    return;
                case "3":
                    // Remove Employee. Loop to print each employee to the console
                    load();
                    for (int i = 0; i < employees.size(); ++i)
                    {
                        System.out.println((i + 1) + ". " + employees.get(i).name);
                    }
                    System.out.println("\nSelect which employee to remove:");
                    int remove = Integer.parseInt(s.nextLine());
                    
                    // Check if input is in range and remove according to index
                    if ((remove <= employees.size()) && remove > 0)
                    {
                        System.out.println("\n" + employees.get(remove - 1).name
                                    + " has been removed.");
                        employees.remove(remove - 1);
                        save();
                    }
                    else
                    {
                        System.out.println("\n*** Invalid input. Removal canceled");
                        // No changes. Clear without saving
                        employees.clear();
                    }
                    return;
                case "4":
                    // List Employees
                    load();
                    System.out.println("List of Employees:");
                    for (int i = 0; i < employees.size(); ++i)
                    {
                        System.out.println((i + 1) + ". " + employees.get(i).name);
                    }
                    employees.clear();
                    return;
                case "5":
                    // Make Employee A Manager
                    load();
                    for (int i = 0; i < employees.size(); ++i)
                    {
                        System.out.println((i + 1) + ". " + employees.get(i).name);
                    }
                    System.out.println("\nSelect an employee to promote:");
                    int promote = Integer.parseInt(s.nextLine());
                    
                    // Check if input is in range. Only promote if the employee is not a manager
                    if ((promote <= employees.size()) && promote > 0)
                    {
                        if (!employees.get(promote - 1).isAManager)
                        {
                            employees.get(promote - 1).isAManager = true;
                            System.out.println("\n" + employees.get(promote - 1).name
                                    + " has been promoted.");
                            save();
                        }
                        else
                        {
                            System.out.println("\n" + employees.get(promote - 1).name
                                    + " is already a manager. Promotion canceled.");
                            employees.clear();
                        }
                    }
                    else
                    {
                        System.out.println("\n*** Invalid input. Promotion canceled");
                        employees.clear();
                    }
                    return;
                case "6":
                    // Manage Lodges
                    previous = current;
                    current = employeeView;
                    return;
                case "7":
                    // Log out
                    previous = current;
                    current = login;
                    System.out.println("Logged out.");
                    return;
                default:
                    System.out.println("*** Invalid input.");
                    System.out.println("Select from the menu:");
            }
        }
    }
}
