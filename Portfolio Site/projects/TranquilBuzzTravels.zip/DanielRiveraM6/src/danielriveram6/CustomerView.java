package danielriveram6;

import static danielriveram6.EmployeeView.lodges;
import static danielriveram6.EmployeeView.lodgeImgStorage;
import java.awt.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import java.util.Scanner;
import java.sql.*;
import java.util.ArrayList;

public class CustomerView extends State {
    String orderLodgeName, startDetails, endDetails;
    double orderBasePPN, orderTotal;
    long orderNumOfNights;
    boolean validDate = false, validReport = false;
    boolean loginOrder = false;
    int startYIndex, endYIndex, selectID, selectIndex;
    final int imgPanelHeight = 108;
    float scalePercent;
    float oldImgWidth, oldImgHeight, newImgWidth;
    int intImgWidth;
    LocalDate sDateData, eDateData;
    ArrayList<String> lodgeNames = new ArrayList();
    ArrayList<Integer> lodgeIDs = new ArrayList();
    // Colors for most buttons changing status
    Color enabledBtn = new Color(190, 235, 159);
    Color disabledBtn = new Color(189, 208, 176);
    // Array for abbreviated months
    String[] monthChoices = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    // GregorianCalendars: Two for a minimum valid date and maximum valid date
    Calendar today = Calendar.getInstance();
    GregorianCalendar dateMin = new GregorianCalendar(today.get(Calendar.YEAR),
        today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
    GregorianCalendar dateMax = new GregorianCalendar(today.get(Calendar.YEAR),
        today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
    // Two for the Start and End dates input by the user
    GregorianCalendar startDate = new GregorianCalendar(today.get(Calendar.YEAR),
        today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
    GregorianCalendar endDate = new GregorianCalendar(today.get(Calendar.YEAR),
        today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
    
    // Components
    // List and Panels for organizing lodges, images, and buttons
    JListLodges lstLodges = new JListLodges();
    JPanelImages pnlImages = new JPanelImages();
    // Title
    JLabelTitle lblCustTitle = new JLabelTitle("Welcome!");
    // Labels for lodges, images, and information
    JLabelGen lblLodges = new JLabelGen("Where would you like to go?");
    JLabelGen lblImages = new JLabelGen("Images:");
    JLabelGen lblInfo = new JLabelGen("Lodge details:");
    // Information Label
    JLabelGen lblDetails = new JLabelGen("Please select a lodge to see its info.", 18);
    // Scrolling for Lodge List, Image Area, and Info Label
    JScrollPane scpLodges;
    JScrollPane scpImages;
    JScrollPane scpInfo;
    // A panel for laying out the ComboBoxes and Labels
    JPanel pnlCombos = new JPanel();
    // Labels for setting order date
    JLabelGen lblWhen = new JLabelGen("When would you like to stay?");
    JLabelGen lblStart = new JLabelGen("Starting Date:");
    JLabelGen lblEnd = new JLabelGen("Ending Date:");
    // 6 ComboBoxes: three for starting date, three for ending date
    JComboBoxOrder cbxStartM = new JComboBoxOrder();
    JComboBoxOrder cbxStartD = new JComboBoxOrder();
    JComboBoxOrder cbxStartY = new JComboBoxOrder();
    JComboBoxOrder cbxEndM = new JComboBoxOrder();
    JComboBoxOrder cbxEndD = new JComboBoxOrder();
    JComboBoxOrder cbxEndY = new JComboBoxOrder();
    // 3 JLabels for validation
    JLabelGen lblStartRange = new JLabelGen("Starting date must be after today.", 18);
    JLabelGen lblEndRange = new JLabelGen("Ending date cannot exceed three (3) years from today.", 18);
    JLabelGen lblBefore = new JLabelGen("Starting date must be before ending date.", 18);
    // Order Information Label with JScrollPane
    JLabelGen lblOrderDetails = new JLabelGen("Press 'View Order' when ready.", 20);
    JScrollPane scpOrderInfo;
    // Label informing of login necessary for reports
    JLabelGen lblReports = new JLabelGen("Text to replace", 18);
    // 5 buttons
    JButtonTravel btnCustLogOut = new JButtonTravel("Log Out", 140, 60, true);
    JButtonTravel btnView = new JButtonTravel("View Order", 170, 60, false);
    JButtonTravel btnConfirm = new JButtonTravel("Confirm Order", 200, 60, false);
    JButtonTravel btnRefresh = new JButtonTravel("Refresh", 140, 60, false);
    JButtonTravel btnReports = new JButtonTravel("Order Reports", 200, 60, false);
    // Label in case the connection is invalid
    JLabelGen lblCustCon = new JLabelGen("<html>Not connected.<br>Action cancelled.</html>", 20, true);
    // ------------------------------------
    
    
    // Constructor creates card for the CardLayout
    CustomerView() {
        // ------- CUSTOMER VIEW CARD -------
        mainPanel.setBackground(new Color(209, 229, 196));
        mainPanel.setLayout(null);
        // Set Title in place
        lblCustTitle.setLocation(tbtFrame.getWidth()/2 - lblCustTitle.getWidth()/2, 20);
        // Set Labels in place
        lblLodges.setLocation(30, 70);
        lblImages.setLocation(30, 300);
        lblInfo.setLocation(550, 70);
        lblWhen.setLocation(30, 490);
        // Settings for List, Panels, and Info Label
        lstLodges.setBounds(30, 100, 500, 180);
        pnlImages.setBounds(30, 330, 1300, 140);
        lblDetails.setBounds(550, 100, 780, 180);
        lblDetails.setVerticalAlignment(JLabel.TOP);
        pnlCombos.setBackground(new Color(209, 229, 196));
        pnlCombos.setBounds(30, 520, 370, 100);
        pnlCombos.setLayout(new FlowLayout(FlowLayout.RIGHT));
        // Set Valid Date labels in place
        lblStartRange.setLocation(410, 530);
        lblEndRange.setLocation(410, 555);
        lblBefore.setLocation(410, 580);
        // Settings for Order Info Label
        lblOrderDetails.setBounds(840, 490, 490, 130);
        lblOrderDetails.setVerticalAlignment(JLabel.TOP);
        // View and Confirm buttons disabled upon loading
        btnView.setEnabled(false);
        btnView.setBackground(disabledBtn);
        btnConfirm.setEnabled(false);
        btnConfirm.setBackground(disabledBtn);
        // Label for reports requiring login
        lblReports.setLocation(390, 650);
        // Label for failed connection
        lblCustCon.setLocation(280, 10);
        lblCustCon.setVisible(false);
        // All buttons placed separately
        btnCustLogOut.setLocation(30, 645);
        btnReports.setLocation(180, 645);
        btnRefresh.setLocation(645, 645);
        btnView.setLocation(840, 645);
        btnConfirm.setLocation(1130, 645);
        // Establish Scroll Panels
        scpLodges = new JScrollPane(lstLodges, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scpLodges.setBounds(30, 100, 500, 180);
        scpImages = new JScrollPane(pnlImages, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scpImages.setBounds(30, 330, 1300, 140);
        scpInfo = new JScrollPane(lblDetails, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scpInfo.setBounds(550, 100, 780, 180);
        scpOrderInfo = new JScrollPane(lblOrderDetails, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scpOrderInfo.setBounds(840, 490, 490, 130);
        
        // Add to each date
        dateMin.add(Calendar.DATE, 1);
        startDate.add(Calendar.DATE, 1);
        dateMax.add(Calendar.YEAR, 3);
        endDate.add(Calendar.YEAR, 3);
        // Give values to Start and End month
        for (String monthChoice : monthChoices) {
            cbxStartM.addItem(monthChoice);
            cbxEndM.addItem(monthChoice);
        }
        cbxStartM.setSelectedIndex(dateMin.get(Calendar.MONTH));
        cbxEndM.setSelectedIndex(dateMax.get(Calendar.MONTH));
        // Give values to Start and End days
        for (int i = 0; i < dateMin.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
            cbxStartD.addItem(i + 1);
        }
        // End gets its own loop in case of a leap year
        for (int i = 0; i < dateMax.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
            cbxEndD.addItem(i + 1);
        }
        cbxStartD.setSelectedIndex(dateMin.get(Calendar.DAY_OF_MONTH) - 1);
        cbxEndD.setSelectedIndex(dateMax.get(Calendar.DAY_OF_MONTH) - 1);
        // Store indexes for default selection. The ComboBoxes are able to go before
        //  today's date for reports, but the default starts at valid years for placing
        //  a new order
        int tempYIndex = 0;
        // Give values to Start and End years
        for (int i = 2022; i <= dateMax.get(Calendar.YEAR); i++) {
            cbxStartY.addItem(i);
            cbxEndY.addItem(i);
            if (i == dateMin.get(Calendar.YEAR)) {
                startYIndex = tempYIndex;
            }
            if (i == dateMax.get(Calendar.YEAR)) {
                endYIndex = tempYIndex;
            }
            tempYIndex++;
        }
        cbxStartY.setSelectedIndex(startYIndex);
        cbxEndY.setSelectedIndex(endYIndex);
        
        // Add items to ComboBox panel
        pnlCombos.add(lblStart);
        pnlCombos.add(cbxStartM);
        pnlCombos.add(cbxStartD);
        pnlCombos.add(cbxStartY);
        pnlCombos.add(lblEnd);
        pnlCombos.add(cbxEndM);
        pnlCombos.add(cbxEndD);
        pnlCombos.add(cbxEndY);
        
        // Add all items to customerCard
        mainPanel.add(lblCustTitle);
        mainPanel.add(lblLodges);
        mainPanel.add(scpLodges);
        mainPanel.add(lblImages);
        mainPanel.add(scpImages);
        mainPanel.add(lblInfo);
        mainPanel.add(scpInfo);
        mainPanel.add(lblWhen);
        mainPanel.add(pnlCombos);
        mainPanel.add(lblStartRange);
        mainPanel.add(lblEndRange);
        mainPanel.add(lblBefore);
        mainPanel.add(scpOrderInfo);
        mainPanel.add(btnCustLogOut);
        mainPanel.add(btnReports);
        mainPanel.add(btnRefresh);
        mainPanel.add(btnView);
        mainPanel.add(btnConfirm);
        mainPanel.add(lblReports);
        mainPanel.add(lblCustCon);
        // Add card to layout
        cardPanel.add(mainPanel, "customerCard");
        // -------------------------------------
        
        // ---- CUSTOMER VIEW FUNCTIONALITY ----
        // List Selection Listener
        lstLodges.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    if (lstLodges.getSelectedIndex() != -1) {
                        int selectedLodge = lstLodges.getSelectedIndex();
                        selectIndex = lstLodges.getSelectedIndex();
                        // Use index to get the ID
                        selectID = lodgeIDs.get(selectIndex);
                        lblDetails.setText(lodges.get(selectIndex).toJLabelString());
                        // Store two values for later
                        orderLodgeName = lodges.get(selectIndex).name;
                        orderBasePPN = lodges.get(selectIndex).basePricePerNight;
                        Thread tCustSelect = new Thread(() -> {
                            // Use a newly created index to avoid errors with multiple threads
                            int threadIndex = selectedLodge;
                            pnlImages.removeAll();
                            pnlImages.revalidate();
                            pnlImages.repaint();
                            if (lodges.get(threadIndex).lodgeImages.isEmpty() && lodges.get(threadIndex).imgsLoaded == false) {
                                try {
                                    if (con.isValid(4)) {
                                        // Query for the lodge's images
                                        String imagesQuery = "SELECT Image FROM Images"
                                                + " WHERE Lodge_ID = " + selectID;
                                        PreparedStatement imgPS = con.prepareStatement(imagesQuery);
                                        ResultSet imgRS = imgPS.executeQuery();
                                        Blob imgBlob = null;
                                        // Loop through results to fill ArrayList
                                        while (imgRS.next()) {
                                            imgBlob = imgRS.getBlob(1);
                                            byte[] b = imgBlob.getBytes(1, (int) imgBlob.length());
                                            ImageIcon img = new ImageIcon(b);
                                            lodges.get(threadIndex).lodgeImages.add(img);
                                        }
                                        lodges.get(threadIndex).imgsLoaded = true;
                                        firstImgLoad = true;
                                    } else {
                                        lblCustCon.setVisible(true);
                                    }
                                } catch (Exception ex) {
                                    System.out.println("Error: " + ex.toString());
                                    ex.printStackTrace();
                                }
                            }
                            // Loop has two checks to ensure only the selected lodge's images show
                            for (int i = 0; i < lodges.get(threadIndex).lodgeImages.size(); i++) {
                                if (threadIndex != selectIndex) {
                                    pnlImages.removeAll();
                                    pnlImages.revalidate();
                                    pnlImages.repaint();
                                    break;
                                }
                                Image scaledImg = lodges.get(threadIndex).lodgeImages.get(i).getImage();
                                oldImgWidth = lodges.get(selectIndex).lodgeImages.get(i).getIconWidth();
                                oldImgHeight = lodges.get(selectIndex).lodgeImages.get(i).getIconHeight();
                                scalePercent = imgPanelHeight / oldImgHeight;
                                newImgWidth = oldImgWidth * scalePercent;
                                intImgWidth = (int) newImgWidth;
                                ImageIcon scaledIcon = new ImageIcon(scaledImg.getScaledInstance(intImgWidth, imgPanelHeight, Image.SCALE_SMOOTH));
                                if (threadIndex == selectIndex) {
                                    JLabelImage label = new JLabelImage(scaledIcon, threadIndex, i);
                                    pnlImages.add(label);
                                    pnlImages.revalidate();
                                    pnlImages.repaint();
                                } else {
                                    break;
                                }
                            }
                        });
                        tCustSelect.start();
                    }
                    else {
                        pnlImages.removeAll();
                        pnlImages.revalidate();
                        pnlImages.repaint();
                        selectID = 0;
                        orderLodgeName = "";
                        orderBasePPN = 0.0;
                        lblDetails.setText("Please select a lodge to see its info.");
                        lblCustCon.setVisible(false);
                    }
                    // Always disable the Confirm button and run validation method
                    btnConfirm.setEnabled(false);
                    btnConfirm.setBackground(disabledBtn);
                    validateDates();
                }
            }
        });
        // ComboBox Action Listeners
        cbxStartM.addActionListener((e) -> {
            // Read each starting ComboBox and set its values to a temp calendar
            Calendar cTemp = Calendar.getInstance();
            int year = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
            int month = cbxStartM.getSelectedIndex();
            int day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            cTemp.set(year, month, 1);
            // Adjust the selected day if it is an invalid date
            if (day > cTemp.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                day = cTemp.getActualMaximum(Calendar.DAY_OF_MONTH);
            }
            // Clear Start Day ComboBox, repopulate and select
            cbxStartD.removeAllItems();
            for (int i = 0; i < cTemp.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                cbxStartD.addItem(i + 1);
            }
            cbxStartD.setSelectedIndex(day - 1);
            // Reread the day value for a complete Start Date
            day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            startDate.set(year, month, day);
            
            // Check for valid dates
            validateDates();
        });
        cbxStartD.addActionListener((e) -> {
            if (cbxStartD.getSelectedItem() != null) {
                // Read each starting ComboBox and set its values to the Gregorian Calendar
                int year = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
                int month = cbxStartM.getSelectedIndex();
                int day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
                startDate.set(year, month, day);
                // Check for valid dates
                validateDates();
            }
        });
        cbxStartY.addActionListener((e) -> {
            // Repeat Month code for Start Year ComboBox in case of a leap year
            Calendar cTemp = Calendar.getInstance();
            int year = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
            int month = cbxStartM.getSelectedIndex();
            int day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            cTemp.set(year, month, 1);
            if (day > cTemp.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                day = cTemp.getActualMaximum(Calendar.DAY_OF_MONTH);
            }
            cbxStartD.removeAllItems();
            for (int i = 0; i < cTemp.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                cbxStartD.addItem(i + 1);
            }
            cbxStartD.setSelectedIndex(day - 1);
            day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            startDate.set(year, month, day);
            
            // Check for valid dates
            validateDates();
        });
        cbxEndM.addActionListener((e) -> {
            // Read each ending ComboBox and set its values to a temp calendar
            Calendar cTemp = Calendar.getInstance();
            int year = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
            int month = cbxEndM.getSelectedIndex();
            int day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            cTemp.set(year, month, 1);
            // Adjust the selected day if it is an invalid date
            if (day > cTemp.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                day = cTemp.getActualMaximum(Calendar.DAY_OF_MONTH);
            }
            // Clear End Day ComboBox, repopulate and select
            cbxEndD.removeAllItems();
            for (int i = 0; i < cTemp.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                cbxEndD.addItem(i + 1);
            }
            cbxEndD.setSelectedIndex(day - 1);
            // Reread the day value for a complete End Date
            day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            endDate.set(year, month, day);
            
            // Check for valid dates
            validateDates();
        });
        cbxEndD.addActionListener((e) -> {
            if (cbxEndD.getSelectedItem() != null) {
                // Read each ending ComboBox and set its values to the calendar
                int year = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
                int month = cbxEndM.getSelectedIndex();
                int day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
                endDate.set(year, month, day);
                // Check for valid dates
                validateDates();
            }
        });
        cbxEndY.addActionListener((e) -> {
            // Repeat Month code for End Year ComboBox in case of a leap year
            Calendar cTemp = Calendar.getInstance();
            int year = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
            int month = cbxEndM.getSelectedIndex();
            int day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            cTemp.set(year, month, 1);
            if (day > cTemp.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                day = cTemp.getActualMaximum(Calendar.DAY_OF_MONTH);
            }
            cbxEndD.removeAllItems();
            for (int i = 0; i < cTemp.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                cbxEndD.addItem(i + 1);
            }
            cbxEndD.setSelectedIndex(day - 1);
            day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            endDate.set(year, month, day);
            
            // Check for valid dates
            validateDates();
        });
        // Button Action Listeners
        btnCustLogOut.addActionListener((e) -> {
            login.connectLabel();
            cardLayout.show(cardPanel, "loginCard");
            lblCustCon.setVisible(false);
            // Reset the ComboBoxes to the correct dates
            cbxStartM.setSelectedIndex(dateMin.get(Calendar.MONTH));
            cbxStartD.setSelectedIndex(dateMin.get(Calendar.DAY_OF_MONTH) - 1);
            cbxStartY.setSelectedIndex(startYIndex);
            cbxEndM.setSelectedIndex(dateMax.get(Calendar.MONTH));
            cbxEndD.setSelectedIndex(dateMax.get(Calendar.DAY_OF_MONTH) - 1);
            cbxEndY.setSelectedIndex(endYIndex);
            // Clear selection
            lstLodges.clearSelection();
        });
        btnReports.addActionListener((e) -> {
            // Disable button to prevent spam
            btnReports.setEnabled(false);
            btnReports.setBackground(disabledBtn);
            lblCustCon.setVisible(false);
            // Read the comboboxes for starting and ending dates
            int sYear = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
            int sMonth = cbxStartM.getSelectedIndex();
            int sDay = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            int eYear = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
            int eMonth = cbxEndM.getSelectedIndex();
            int eDay = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            LocalDate sDate = LocalDate.of(sYear, sMonth + 1, sDay);
            LocalDate eDate = LocalDate.of(eYear, eMonth + 1, eDay);
            Thread tCustReport = new Thread (() -> {
                // Try for connection
                try {
                    if (con.isValid(4)) {
                        // Create query for getting the customer's order information
                        String custReportQuery = "SELECT Lodge_Name, BasePPN,"
                                + " DATE_FORMAT(StartingDate, '%m/%d/%Y') AS Starting_Date,"
                                + " DATE_FORMAT(EndingDate, '%m/%d/%Y') AS Ending_Date,"
                                + " NightsStaying, Total"
                                + " FROM Orders o JOIN Lodgings l"
                                + " ON o.Lodge_ID = l.Lodge_ID"
                                + " WHERE Customer_ID = " + didLogin
                                + " AND (StartingDate BETWEEN '" + sDate + "' AND '" + eDate + "')";
                        PreparedStatement custRepPS = con.prepareStatement(custReportQuery);
                        ResultSet custRepRS = custRepPS.executeQuery();
                        // Create a report
                        Report custReport = new Report("Your Orders", custRepRS);
                    } else {
                        lblCustCon.setVisible(true);
                    }
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.toString());
                    ex.printStackTrace();
                }
                btnReports.setEnabled(true);
                btnReports.setBackground(enabledBtn);
            });
            tCustReport.start();
        });
        btnView.addActionListener((e) -> {
            lblCustCon.setVisible(false);
            // Calculate the number of days this order will last
            int sYear = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
            int sMonth = cbxStartM.getSelectedIndex();
            int sDay = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            int eYear = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
            int eMonth = cbxEndM.getSelectedIndex();
            int eDay = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            LocalDate sDate = LocalDate.of(sYear, sMonth + 1, sDay);
            LocalDate eDate = LocalDate.of(eYear, eMonth + 1, eDay);
            orderNumOfNights = ChronoUnit.DAYS.between(sDate, eDate);
            // Store dates for database and create strings for display
            sDateData = sDate;
            eDateData = eDate;
            DateTimeFormatter sDisplay = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            DateTimeFormatter eDisplay = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            startDetails = sDate.format(sDisplay);
            endDetails = eDate.format(eDisplay);
            // Calculate total
            orderTotal = orderBasePPN * orderNumOfNights;
            // Set text and enable the Confirm Order button
            lblOrderDetails.setText("<html>Lodge name: " + orderLodgeName
                + "<br/>Base price per night: $" + String.format("%.2f", orderBasePPN)
                + "<br/>Starting date: " + startDetails
                + "<br/>Ending date: " + endDetails
                + "<br/>Nights staying: " + orderNumOfNights
                + "<br/>Total: $" + String.format("%.2f", orderTotal)
                + "</html>");
            btnConfirm.setEnabled(true);
            btnConfirm.setBackground(enabledBtn);
        });
        btnConfirm.addActionListener((e) -> {
            btnConfirm.setEnabled(false);
            btnConfirm.setBackground(disabledBtn);
            lblCustCon.setVisible(false);
            loginOrder = false;
            // Only create an Orders row if a customer is logged in
            if (didLogin != 0) {
                loginOrder = true;
                Thread tOrder = new Thread(() -> {
                    try {
                        if (con.isValid(4)) {
                            // Convert variable before adding data
                            int intNumOfNights = (int) orderNumOfNights;
                            String strNumOfNights = Integer.toString(intNumOfNights);
                            // Create query to add an order
                            String placeOrderQuery = "INSERT INTO Orders VALUES (DEFAULT, ?, ?,"
                                    + " ?, ?, ?, ?)";
                            PreparedStatement newOrdPS = con.prepareStatement(placeOrderQuery);
                            // Fill in question marks
                            newOrdPS.setInt(1, didLogin);
                            newOrdPS.setInt(2, selectID);
                            newOrdPS.setString(3, "" + sDateData);
                            newOrdPS.setString(4, "" + eDateData);
                            newOrdPS.setString(5, strNumOfNights);
                            newOrdPS.setDouble(6, orderTotal);
                            // Log the affected row(s)
                            int updateCount = newOrdPS.executeUpdate();
                            System.out.println(updateCount + " row(s) in Orders affected");
                            lblOrderDetails.setText("Order confirmed. Thank you!");
                        } else {
                            lblCustCon.setVisible(true);
                            lblOrderDetails.setText("An error occurred. Order cancelled.");
                        }
                    } catch (Exception ex) {
                        System.out.println("Error: " + ex.toString());
                        ex.printStackTrace();
                        lblOrderDetails.setText("An error occurred. Order cancelled.");
                    }
                });
                tOrder.start();
            }
            
            // Reset the ComboBoxes to the correct dates
            cbxStartM.setSelectedIndex(dateMin.get(Calendar.MONTH));
            cbxStartD.setSelectedIndex(dateMin.get(Calendar.DAY_OF_MONTH) - 1);
            cbxStartY.setSelectedIndex(startYIndex);
            cbxEndM.setSelectedIndex(dateMax.get(Calendar.MONTH));
            cbxEndD.setSelectedIndex(dateMax.get(Calendar.DAY_OF_MONTH) - 1);
            cbxEndY.setSelectedIndex(endYIndex);
            // Clear selection
            lstLodges.clearSelection();
            // Set a "Thank You" message or notify of processing order
            if (loginOrder) {
                lblOrderDetails.setText("Processing order...");
            } else {
                lblOrderDetails.setText("Order confirmed. Thank you!");
            }
        });
        btnRefresh.addActionListener((e) -> {
            // Briefly disable the button so refreshes can't be spammed
            btnRefresh.setEnabled(false);
            btnRefresh.setBackground(disabledBtn);
            lblCustCon.setVisible(false);
            lstLodges.clearSelection();
            Thread tRefresh = new Thread(() -> {
                refresh();
                btnRefresh.setEnabled(true);
                btnRefresh.setBackground(enabledBtn);
            });
            tRefresh.start();
        });
    }
    
    // Custom method puts label onto the Customer card
    //  if coming from the Login card
    void connectLabel() {
        mainPanel.add(lblConnect);
    }
    
    // Custom method checks for a valid date and toggles the View button if valid
    public void validateDates() {
        lblOrderDetails.setText("Press 'View Order' when ready.");
        btnConfirm.setEnabled(false);
        btnConfirm.setBackground(disabledBtn);
        validDate = true;
        validReport = true;
        // Check each valid condition and change label colors if necessary
        if (startDate.compareTo(dateMin) == -1) {
            lblStartRange.setForeground(Color.red);
            validDate = false;
        } else {
            lblStartRange.setForeground(new Color(0, 163, 136));
        }
        if (startDate.compareTo(endDate) >= 0) {
            lblBefore.setForeground(Color.red);
            validDate = false;
            validReport = false;
        } else {
            lblBefore.setForeground(new Color(0, 163, 136));
        }
        if (endDate.compareTo(dateMax) == 1) {
            lblEndRange.setForeground(Color.red);
            validDate = false;
        } else {
            lblEndRange.setForeground(new Color(0, 163, 136));
        }
        
        // Enable or disable the View button
        if (validDate && lstLodges.getSelectedIndex() != -1) {
            btnView.setEnabled(true);
            btnView.setBackground(enabledBtn); 
        }
        else {
            btnView.setEnabled(false);
            btnView.setBackground(disabledBtn);
        }
        
        // Do a separate check for reports
        if (didLogin != 0) {
            if (validReport) {
                btnReports.setEnabled(true);
                btnReports.setBackground(enabledBtn);
                // Change label style
                lblReports.setForeground(new Color(0, 163, 136));
                lblReports.setText("<html>Order history shows orders<br>between selected dates</html>");
                lblReports.setSize(lblReports.getPreferredSize().width, lblReports.getPreferredSize().height);
            } else {
                btnReports.setEnabled(false);
                btnReports.setBackground(disabledBtn);
                // Change label style
                lblReports.setForeground(Color.red);
                lblReports.setText("<html>Starting date must<br>be before ending date</html>");
                lblReports.setSize(lblReports.getPreferredSize().width, lblReports.getPreferredSize().height);
            }
        }
    }
    
    // Method determining which Reports message to show and when to activate the button
    void checkLogin() {
        if (didLogin != 0) {
            btnReports.setEnabled(true);
            btnReports.setBackground(enabledBtn);
            // Label for reports requiring login styles
            lblReports.setForeground(new Color(0, 163, 136));
            lblReports.setText("<html>Order history shows orders<br>between selected dates</html>");
            lblReports.setSize(lblReports.getPreferredSize().width, lblReports.getPreferredSize().height);
        } else {
            btnReports.setEnabled(false);
            btnReports.setBackground(disabledBtn);
            // Label for reports requiring login styles
            lblReports.setForeground(Color.red);
            lblReports.setText("<html>Log in to access<br>order history</html>");
            lblReports.setSize(lblReports.getPreferredSize().width, lblReports.getPreferredSize().height);
        }
    }
    
    void refresh() {
        try {
            if (con.isValid(4)) {
                // Only store image lists after loading images and lodges
                if (lodges.isEmpty() == false && firstImgLoad) {
                    lodgeImgStorage.clear();
                    for (int i = 0; i < lodges.size(); i++) {
                        Lodging imgLodge = new Hotel();
                        lodgeImgStorage.add(imgLodge);
                        // Skip in case a lodge has no images
                        lodgeImgStorage.get(i).imgsLoaded = lodges.get(i).imgsLoaded;
                        if (lodges.get(i).lodgeImages.isEmpty() == false) {
                            lodgeImgStorage.get(i).lodgeImages = lodges.get(i).lodgeImages;
                        }
                    }
                }
                lodges.clear();
                lodgeIDs.clear();
                int indexToAdd = 0;
                // Query for the ID of all lodges for later use
                String allIDsQuery = "SELECT Lodge_ID FROM Lodgings";
                PreparedStatement idsPS = con.prepareStatement(allIDsQuery);
                ResultSet idsRS = idsPS.executeQuery();
                while(idsRS.next()) {
                    Lodging emptyLodge = new Hotel();
                    lodges.add(emptyLodge);
                    lodgeIDs.add(idsRS.getInt(1));
                }
                // Prepare a query for Hotel values
                String hotelQuery = "SELECT l.Lodge_ID, Lodge_Name, Lodge_Address, Lodge_Description, Lodge_PhoneNumber, NumOfBedrooms, MaxOccupants, BasePPN,"
                    + " Vacancies, ParkingFee, ValetParking, HasPool, HasWorkoutRoom, HasMiniKitchen, HasFreeBreakfast"
                    + " FROM Lodgings l JOIN Hotels h"
                    + " ON l.Lodge_ID = h.Lodge_ID"
                    + " WHERE Lodge_Type = 'Hotel'";
                PreparedStatement htlPS = con.prepareStatement(hotelQuery);
                ResultSet htlRS = htlPS.executeQuery();
                while (htlRS.next()) {
                    int indexID = htlRS.getInt(1);
                    String readName = htlRS.getString(2);
                    String readAddr = htlRS.getString(3);
                    String readDesc = htlRS.getString(4);
                    String readPhone = htlRS.getString(5);
                    int readNumBeds = Integer.parseInt(htlRS.getString(6));
                    int readMaxOcc = Integer.parseInt(htlRS.getString(7));
                    double readPPN = htlRS.getDouble(8);
                    // Hotel-specific variables
                    int readVacs = Integer.parseInt(htlRS.getString(9));
                    double readPark = Double.parseDouble(htlRS.getString(10));
                    double readValet = Double.parseDouble(htlRS.getString(11));
                    boolean readPool = Boolean.parseBoolean(htlRS.getString(12));
                    boolean readWorkout = Boolean.parseBoolean(htlRS.getString(13));
                    boolean readMKitch = Boolean.parseBoolean(htlRS.getString(14));
                    boolean readBrkfst = Boolean.parseBoolean(htlRS.getString(15));
                    // Use values to create a Hotel object
                    Lodging readHotel = new Hotel(readName, readAddr, readDesc, readPhone,
                            readNumBeds, readMaxOcc, readPPN, readVacs, readPark, readValet,
                            readPool, readWorkout, readMKitch, readBrkfst);
                    for (int i = 0; i < lodgeIDs.size(); i++) {
                        if (indexID == lodgeIDs.get(i)) {
                            indexToAdd = i;
                        }
                    }
                    // Fill list by replacing empty lodges in the correct order
                    lodges.set(indexToAdd, readHotel);
                }
                // Prepare another query for House values
                String houseQuery = "SELECT l.Lodge_ID, Lodge_Name, Lodge_Address, Lodge_Description, Lodge_PhoneNumber, NumOfBedrooms, MaxOccupants, BasePPN,"
                    + " House_Date, HasGarage, HasSecuritySystem, PetsAllowed"
                    + " FROM Lodgings l JOIN Houses h"
                    + " ON l.Lodge_ID = h.Lodge_ID"
                    + " WHERE Lodge_Type = 'House'";
                PreparedStatement husPS = con.prepareStatement(houseQuery);
                ResultSet husRS = husPS.executeQuery();
                while (husRS.next()) {
                    int indexID = husRS.getInt(1);
                    String readName = husRS.getString(2);
                    String readAddr = husRS.getString(3);
                    String readDesc = husRS.getString(4);
                    String readPhone = husRS.getString(5);
                    int readNumBeds = Integer.parseInt(husRS.getString(6));
                    int readMaxOcc = Integer.parseInt(husRS.getString(7));
                    double readPPN = husRS.getDouble(8);
                    // Hotel-specific variables
                    String readDate = husRS.getString(9);
                    boolean readGarage = Boolean.parseBoolean(husRS.getString(10));
                    boolean readSecure = Boolean.parseBoolean(husRS.getString(11));
                    boolean readPets = Boolean.parseBoolean(husRS.getString(12));
                    // Use values to create a House object
                    Lodging readHouse = new House(readName, readAddr, readDesc,
                            readPhone, readNumBeds, readMaxOcc, readPPN,
                            readDate, readGarage, readSecure, readPets);
                    for (int i = 0; i < lodgeIDs.size(); i++) {
                        if (indexID == lodgeIDs.get(i)) {
                            indexToAdd = i;
                        }
                    }
                    // Fill list by replacing empty lodges in the correct order
                    lodges.set(indexToAdd, readHouse);
                }
                // Only one lodge gets added prior to refreshing.
                //  Add one empty lodge to match if needed
                if (lodges.size() > lodgeImgStorage.size()) {
                    Lodging emptyLodge = new Hotel();
                    lodgeImgStorage.add(emptyLodge);
                }
                // Only refill lodge images after images have been loaded in once
                if (firstImgLoad) {
                    for (int i = 0; i < lodges.size(); i++) {
                        lodges.get(i).imgsLoaded = lodgeImgStorage.get(i).imgsLoaded;
                        // Skip in case a lodge has no images
                        if (lodgeImgStorage.get(i).lodgeImages.isEmpty() == false) {
                            lodges.get(i).lodgeImages = lodgeImgStorage.get(i).lodgeImages;
                        }
                    }
                }
                // Loop lodge list to fill lodgeNames array and JList
                for (int i = 0; i < lodges.size(); i++) {
                    lodgeNames.add(lodges.get(i).name);
                }
                lstLodges.setListData(lodgeNames.toArray());
                lodgeNames.clear();
            } else {
                lblCustCon.setVisible(true);
            }
        } catch (Exception ex) {
            System.out.println("Error: " + ex.toString());
            ex.printStackTrace();
            // In case of an error, load data from text files
            load();
            for (int i = 0; i < lodges.size(); i++) {
                lodgeNames.add(lodges.get(i).name);
            }
            lstLodges.setListData(lodgeNames.toArray());
            lodgeNames.clear();
        }
    }
    
    void load() {
//        for (int i = 0; i < lodges.size(); i++) {
//            lodgeNames.add(lodges.get(i).name);
//        }
//        lstLodges.setListData(lodgeNames.toArray());
//        lodgeNames.clear();
    }
            
    void enter()
    {
//        System.out.println("\n1. View Lodges with price per night"
//        + "\n2. View Order"
//        + "\n3. Return"
//        + "\n\nSelect from the menu:");
    }
    
    void update()
    {
//        while (true)
//        {
//            Scanner s = new Scanner(System.in);
//            String input = s.nextLine();
//            
//            // Switch statement determines necessary actions to take
//            switch (input)
//            {
//                case "1":
//                    // Listing lodges with base price per night
//                    employeeView.load();
//                    System.out.println("List of lodges:");
//                    for (int i = 0; i < lodges.size(); ++i)
//                    {
//                        System.out.println((i + 1) + ". " + lodges.get(i).name + ": $"
//                                + String.format("%.2f", lodges.get(i).basePricePerNight)
//                                + " per night");
//                    }
//                    // Get user input to continue
//                    System.out.println((lodges.size() + 1) + ". Return to previous menu"
//                            + "\n\nSelect from the menu:");
//                    int selection = Integer.parseInt(s.nextLine());
//                    
//                    if ((selection <= lodges.size()) && selection > 0)
//                    {
//                        // Set values: viewable in View Order
//                        newLodgeName = lodges.get(selection - 1).name;
//                        newBasePPN = lodges.get(selection - 1).basePricePerNight;
//                        
//                        // Enter number of nights and calculate for total
//                        System.out.println("Enter number of days:");
//                        newNumOfNights = Integer.parseInt(s.nextLine());
//                        newTotal = newBasePPN * newNumOfNights;
//                        
//                        System.out.println("Lodge added to order.");
//                    }
//                    else if (selection == (lodges.size() + 1))
//                    {
//                        // Return to previous menu
//                    }
//                    else
//                    {
//                        System.out.println("\n*** Invalid input. Order canceled");
//                    }
//                    lodges.clear();
//                    return;
//                case "2":
//                    // View Order
//                    System.out.println("Lodge name: " + newLodgeName
//                        + "\nBase price per night: $" + String.format("%.2f", newBasePPN)
//                        + "\nNights staying: " + newNumOfNights
//                        + "\nTotal: $" + String.format("%.2f", newTotal));
//                    // Show menu and get input
//                    System.out.println("\n1. Confirm Order"
//                        + "\n2. Cancel Order"
//                        + "\n3. Return"
//                        + "\n\nSelect from the menu:");
//                    String input2 = s.nextLine();
//                    
//                    switch (input2)
//                    {
//                        case "1":
//                            // Add new order to the list to confirm
//                            Order newOrder = new Order(newLodgeName, newBasePPN,
//                            newNumOfNights, newTotal);
//                            // Clear the order
//                            newLodgeName = "";
//                            newBasePPN = 0.0;
//                            newNumOfNights = 0;
//                            newTotal = 0.0;
//                            System.out.println("Order has been confirmed.");
//                            break;
//                        case "2":
//                            // Clear the order
//                            newLodgeName = "";
//                            newBasePPN = 0.0;
//                            newNumOfNights = 0;
//                            newTotal = 0.0;
//                            System.out.println("Order has been canceled.");
//                            break;
//                        case "3":
//                            // Return to previous menu
//                            break;
//                        default:
//                            System.out.println("\n*** Invalid input.");
//                            break;
//                    }
//                    return;
//                case "3":
//                    // Return to Login View
//                    previous = current;
//                    current = login;
//                    return;
//                default:
//                    System.out.println("*** Invalid input.");
//                    System.out.println("Select from the menu:");
//            }
//        }
    }
}
