package danielriveram6;

public class TravelAgencyEmployee extends Person {
    // Variable declarations
    String hireDate;
    double salary;
    boolean isAManager;
    
    // Default constructor
    public TravelAgencyEmployee()
    {
        hireDate = "";
        salary = 0.0;
        isAManager = false;
    }
    // Constructor with definitions
    public TravelAgencyEmployee(String nam, String phoneNum, String logNam,
            String pWord, String addr, int idNum, String hDate, double sal, boolean isMngr)
    {
        super(nam, phoneNum, logNam, pWord, addr, idNum);
        this.hireDate = hDate;
        this.salary = sal;
        this.isAManager = isMngr;
    }
    
    // New .toString() override
    public String toString()
    {
        String returnString = super.toString();
        returnString += "\nHire date: " + this.hireDate
                    + "\nMonthly salary: $" + String.format("%.2f", this.salary)
                    + "\nIs a manager: " + this.isAManager;
        return returnString;
    }
}
