package danielriveram6;

public class LodgingReview {
    // Variable declarations
    String name, description, date, comments;
    int rating;
    
    // Default constructor
    public LodgingReview()
    {
        name = "";
        description = "";
        date = "";
        comments = "";
        rating = 0;
    }
    // Constructor with definitions
    public LodgingReview(String nam, String desc, String dat,
            String comm, int rat)
    {
        this.name = nam;
        this.description = desc;
        this.date = dat;
        this.comments = comm;
        this.rating = rat;
    }
    
    // New .toString() override
    public String toString()
    {
        return "Name: " + this.name
                + "\nDescription: " + this.description
                + "\nDate: " + this.date
                + "\nComments: " + this.comments
                + "\nRating (1-5): " + this.rating;
    }
}
