package danielriveram6;

import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;

// JPanel extension for each lodge seen in Employee View and Customer View
public class JPanelImages extends JPanel {
    
    // Constructor gives panel a BoxLayout. Images come from lodge data
    public JPanelImages() {
        setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        setBorder(BorderFactory.createLineBorder(new Color(0, 109, 163), 2, false));
        setBackground(new Color(113, 154, 193));
    }
}
