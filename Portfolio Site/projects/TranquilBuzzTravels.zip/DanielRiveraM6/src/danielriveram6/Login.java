package danielriveram6;

import static danielriveram6.ManagerView.employees;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;
import java.util.Scanner;
import java.sql.*;
import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;

public class Login extends State {
    // Declarations
    String username, newPassword;
    boolean validPassword = false, validLength, uppercaseFound, specialCharFound;
    boolean loginSuccess = false;
    int largestID;
    static ArrayList<Customer> customers = new ArrayList();
    // Colors for most buttons changing status
    Color enabledBtn = new Color(190, 235, 159);
    Color disabledBtn = new Color(189, 208, 176);
    
    // Components for Login card ----------
    // Panels organize the input fields separately from the buttons
    JPanel pnlInputFields = new JPanel();
    JPanel pnlButtons = new JPanel();
    // Title
    JLabelTitle lblTitle = new JLabelTitle("Login");
    // Text and Password fields
    JLabelGen lblUsername = new JLabelGen("Username:");
    JTextFieldTravel tfdUsername = new JTextFieldTravel(28);
    JLabelGen lblPassword = new JLabelGen("Password:");
    JPasswordFieldLogin tfdPassword = new JPasswordFieldLogin(28);
    // Notify user when login attempt is invalid
    JLabelGen lblLogging = new JLabelGen("Logging in...");
    JLabelGen lblInvalid = new JLabelGen("Username or password is invalid.");
    // Notify user when Registry attempt succeeds/fails
    JLabelGen lblSuccess = new JLabelGen("New account successfully created.");
    // Buttons
    JButtonTravel btnLogin = new JButtonTravel("Login", false);
    JButtonTravel btnRegister = new JButtonTravel("Register", false);
    JButtonTravel btnGuest = new JButtonTravel("Continue as Guest", false);
    JButtonTravel btnExit = new JButtonTravel("Exit", true);
    // Label in case the connection is invalid
    JLabelGen lblLogCon = new JLabelGen("<html>Not connected.<br>Action cancelled.</html>", 20, true);
    // ------------------------------------
    
    // Components for Register card -------
    JPanel registerCard = new JPanel();
    // Panel for field Layout
    JPanel regInputFields = new JPanel();
    // Title
    JLabelTitle lblRegTitle = new JLabelTitle("Register");
    // Text and Password fields
    JLabelGen lblRegUName = new JLabelGen("Enter username:");
    JTextFieldTravel tfdRegUName = new JTextFieldTravel(25);
    JLabelGen lblRegPWord = new JLabelGen("Enter password:");
    JPasswordFieldLogin tfdRegPWord = new JPasswordFieldLogin(25);
    // Labels for password validation
    JLabelGen lblRequires = new JLabelGen("Password requires:");
    JLabelGen lblCharsMin = new JLabelGen("Eight (8) characters minimum");
    JLabelGen lblOneUpper = new JLabelGen("One (1) uppercase character");
    JLabelGen lblOneSpecial = new JLabelGen("One (1) special character");
    // Buttons
    JButtonTravel btnSubmit = new JButtonTravel("Submit", 140, 60, false);
    JButtonTravel btnCancel = new JButtonTravel("Cancel", 140, 60, true);
    // Label in case the connection is invalid
    JLabelGen lblRegCon = new JLabelGen("<html>Not connected.<br>Action cancelled.</html>", 20, true);
    // ------------------------------------
    
    
    // Constructor creates two cards for the CardLayout
    Login() {
        firstImgLoad = false;
        
        // ------- LOGIN CARD -------
        mainPanel.setBackground(new Color(209, 229, 196));
        mainPanel.setLayout(null);
        // Set Title in place
        lblTitle.setLocation(tbtFrame.getWidth()/2 - lblTitle.getWidth()/2, 20);
        // Set layouts and styles for panels separating fields and buttons
        pnlInputFields.setBackground(new Color(209, 229, 196));
        pnlInputFields.setSize(660, 90);
        pnlInputFields.setLocation(tbtFrame.getWidth()/2 - pnlInputFields.getWidth()/2, 70);
        pnlInputFields.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pnlButtons.setBackground(new Color(209, 229, 196));
        pnlButtons.setSize(600, 100);
        pnlButtons.setLocation(tbtFrame.getWidth()/2 - pnlButtons.getWidth()/2, 200);
        pnlButtons.setLayout(new GridLayout(2, 2));
        // Start form with Login button disabled
        btnLogin.setEnabled(false);
        btnLogin.setBackground(disabledBtn);
        // Validation and logging labels styles. Hidden until needed
        lblInvalid.setLocation(tbtFrame.getWidth()/2 - lblInvalid.getWidth()/2, 160);
        lblInvalid.setForeground(Color.red);
        lblInvalid.setVisible(false);
        lblLogging.setLocation(tbtFrame.getWidth()/2 - lblLogging.getWidth()/2, 160);
        lblLogging.setVisible(false);
        // Success/failure Registry label hidden until a new account is created
        lblSuccess.setLocation(tbtFrame.getWidth()/2 - lblSuccess.getWidth()/2, 160);
        lblSuccess.setVisible(false);
        // Label for failed connection
        lblLogCon.setLocation(280, 10);
        lblLogCon.setVisible(false);
        // Label for connection status
        lblConnect.setLocation(10, 10);
        // Add items to input panel
        pnlInputFields.add(lblUsername);
        pnlInputFields.add(tfdUsername);
        pnlInputFields.add(lblPassword);
        pnlInputFields.add(tfdPassword);
        // Add items to button panel
        pnlButtons.add(btnLogin);
        pnlButtons.add(btnRegister);
        pnlButtons.add(btnExit);
        pnlButtons.add(btnGuest);
        
        // Add components to the card
        mainPanel.add(lblTitle);
        mainPanel.add(pnlInputFields);
        mainPanel.add(lblLogging);
        mainPanel.add(lblInvalid);
        mainPanel.add(lblSuccess);
        mainPanel.add(pnlButtons);
        mainPanel.add(lblLogCon);
        // The connection status label starts on this card
        mainPanel.add(lblConnect);
        // Add card to layout
        cardPanel.add(mainPanel, "loginCard");
        // -------------------------------------
        
        // ------- REGISTER CARD -------
        registerCard.setBackground(new Color(209, 229, 196));
        registerCard.setLayout(null);
        // Set Title in place
        lblRegTitle.setLocation(tbtFrame.getWidth()/2 - lblRegTitle.getWidth()/2, 20);
        // Set layouts and styles for Fields panel
        regInputFields.setBackground(new Color(209, 229, 196));
        regInputFields.setSize(660, 90);
        regInputFields.setLocation(tbtFrame.getWidth()/2 - regInputFields.getWidth()/2, 70);
        regInputFields.setLayout(new FlowLayout(FlowLayout.RIGHT));
        // Add Fields to panel
        regInputFields.add(lblRegUName);
        regInputFields.add(tfdRegUName);
        regInputFields.add(lblRegPWord);
        regInputFields.add(tfdRegPWord);
        // Four labels for validation
        lblRequires.setLocation(410, 170);
        lblRequires.setForeground(Color.red);
        lblCharsMin.setLocation(649, 170);
        lblCharsMin.setForeground(Color.red);
        lblOneUpper.setLocation(660, 200);
        lblOneUpper.setForeground(Color.red);
        lblOneSpecial.setLocation(693, 230);
        lblOneSpecial.setForeground(Color.red);
        // Buttons
        btnSubmit.setLocation(845, 270);
        btnCancel.setLocation(385, 270);
        // Start form with Submit button disabled
        btnSubmit.setEnabled(false);
        btnSubmit.setBackground(disabledBtn);
        
        // Add all items to registerCard
        registerCard.add(lblRegTitle);
        registerCard.add(regInputFields);
        registerCard.add(lblRequires);
        registerCard.add(lblCharsMin);
        registerCard.add(lblOneUpper);
        registerCard.add(lblOneSpecial);
        registerCard.add(btnSubmit);
        registerCard.add(btnCancel);
        // Add card to layout
        cardPanel.add(registerCard, "registerCard");
        // ---------------------------------------------
        
        // ---------- LOGIN PAGE FUNCTIONALITY ----------
        // Field Key Listeners
        tfdUsername.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                lblSuccess.setVisible(false);
                if (tfdUsername.getText().length() < 1 ||
                        tfdPassword.getPassword().length < 1) {
                    btnLogin.setEnabled(false);
                    btnLogin.setBackground(disabledBtn);
                }
                else {
                    btnLogin.setEnabled(true);
                    btnLogin.setBackground(enabledBtn);
                }
            }
        });
        tfdPassword.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                lblSuccess.setVisible(false);
                if (tfdUsername.getText().length() < 1 ||
                        tfdPassword.getPassword().length < 1) {
                    btnLogin.setEnabled(false);
                    btnLogin.setBackground(disabledBtn);
                }
                else {
                    btnLogin.setEnabled(true);
                    btnLogin.setBackground(enabledBtn);
                }
            }
        });
        // Button Action Listeners
        btnLogin.addActionListener((e) -> {
            lblLogCon.setVisible(false);
            loginSuccess = false;
            // Set values equal to JTextField and JPasswordField
            username = tfdUsername.getText();
            newPassword = new String(tfdPassword.getPassword());
            // Try/Catch for connection to database
            Thread tLogin = new Thread(() -> {
                try {
                    if (con.isValid(4)) {
                        // Get queries to read usernames and passwords
                        String custQuery = "SELECT Customer_Username, Customer_Password, Customer_ID FROM Customers";
                        String empQuery = "SELECT Employee_Username, Employee_Password FROM Employees";
                        PreparedStatement custPS = con.prepareStatement(custQuery);
                        ResultSet custRS = custPS.executeQuery();
                        PreparedStatement empPS = con.prepareStatement(empQuery);
                        ResultSet empRS = empPS.executeQuery();
                        // Loop through results to check for a matching username and password
                        while (custRS.next()) {
                            if (username.equals(custRS.getString(1)) &&
                                    newPassword.equals(decodePassword(custRS.getString(2))))
                            {
                                loginSuccess = true;
                                didLogin = custRS.getInt(3);
                                customerView.checkLogin();
                                customerView.refresh();
                                customerView.connectLabel();
                                cardLayout.show(cardPanel, "customerCard");
                                lblLogging.setVisible(false);
                                lblInvalid.setVisible(false);
                                tfdUsername.setText("");
                                tfdPassword.setText("");
                                btnLogin.setEnabled(false);
                                btnLogin.setBackground(disabledBtn);
                                break;
                            }
                        }
                        while (empRS.next()) {
                            if (username.equals(empRS.getString(1)) &&
                                    newPassword.equals(decodePassword(empRS.getString(2))))
                            {
                                loginSuccess = true;
                                employeeView.refresh();
                                employeeView.connectLabel();
                                cardLayout.show(cardPanel, "employeeCard");
                                lblLogging.setVisible(false);
                                lblInvalid.setVisible(false);
                                tfdUsername.setText("");
                                tfdPassword.setText("");
                                btnLogin.setEnabled(false);
                                btnLogin.setBackground(disabledBtn);
                                break;
                            }
                        }
                        // Login as customer or employee, or notify of invalid attempt
                        if (loginSuccess == false)
                        {
                            lblLogging.setVisible(false);
                            lblInvalid.setVisible(true);
                        }
                    } else {
                        lblLogCon.setVisible(true);
                        lblLogging.setVisible(false);
                    }
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.toString());
                    ex.printStackTrace();
                }
            });
            tLogin.start();
            lblInvalid.setVisible(false);
            lblLogging.setVisible(true);
        });
        btnRegister.addActionListener((e) -> {
            registerCard.add(lblConnect);
            cardLayout.show(cardPanel, "registerCard");
            lblLogging.setVisible(false);
            lblInvalid.setVisible(false);
            lblSuccess.setVisible(false);
            lblLogCon.setVisible(false);
            tfdUsername.setText("");
            tfdPassword.setText("");
            btnLogin.setEnabled(false);
            btnLogin.setBackground(disabledBtn);
        });
        btnGuest.addActionListener((e) -> {
            didLogin = 0;
            customerView.checkLogin();
            customerView.refresh();
            customerView.connectLabel();
            cardLayout.show(cardPanel, "customerCard");
            lblLogging.setVisible(false);
            lblInvalid.setVisible(false);
            lblSuccess.setVisible(false);
            lblLogCon.setVisible(false);
            tfdUsername.setText("");
            tfdPassword.setText("");
            btnLogin.setEnabled(false);
            btnLogin.setBackground(disabledBtn);
        });
        btnExit.addActionListener((e) -> {
            System.exit(0);
        });
        // -------------------------------------------
        
        // ------- REGISTER PAGE FUNCTIONALITY -------
        // Key Listeners
        tfdRegUName.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                if (tfdRegUName.getText().length() < 1 ||
                        tfdRegPWord.getPassword().length < 1) {
                    btnSubmit.setEnabled(false);
                    btnSubmit.setBackground(disabledBtn);
                }
                else if (validPassword) {
                    btnSubmit.setEnabled(true);
                    btnSubmit.setBackground(enabledBtn);
                }
                else {
                    btnSubmit.setEnabled(false);
                    btnSubmit.setBackground(disabledBtn);
                }
            }
        });
        tfdRegPWord.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                if (tfdRegUName.getText().length() < 1 ||
                        tfdRegPWord.getPassword().length < 1) {
                    btnSubmit.setEnabled(false);
                    btnSubmit.setBackground(disabledBtn);
                }
                else {
                    // Reset all values for validation
                    validPassword = false;
                    validLength = false;
                    uppercaseFound = false;
                    specialCharFound = false;
                    // Get input
                    username = tfdRegUName.getText();
                    newPassword = new String(tfdRegPWord.getPassword());
                    // Check length of password
                    if (newPassword.length() >= 8)
                    {
                        validLength = true;
                    }
                    // Loop to check for capital letters and special characters
                    for (int c = 0; c < newPassword.length() && (!uppercaseFound || !specialCharFound); ++c)
                    {
                        if (Character.isLetterOrDigit(newPassword.charAt(c)))
                        {
                            if (Character.isUpperCase(newPassword.charAt(c)))
                            {
                                uppercaseFound = true;
                            }
                        }
                        else
                        {
                            specialCharFound = true;
                        }
                    }

                    // Check each condition to change the color of each label
                    if (validLength) {
                        lblCharsMin.setForeground(new Color(0, 163, 136));
                    } else {
                        lblCharsMin.setForeground(Color.red);
                    }
                    if (uppercaseFound) {
                        lblOneUpper.setForeground(new Color(0, 163, 136));
                    } else {
                        lblOneUpper.setForeground(Color.red);
                    }
                    if (specialCharFound) {
                        lblOneSpecial.setForeground(new Color(0, 163, 136));
                    } else {
                        lblOneSpecial.setForeground(Color.red);
                    }

                    // Check all conditions to validate the password
                    if (validLength && uppercaseFound && specialCharFound) {
                        validPassword = true;
                        lblRequires.setForeground(new Color(0, 163, 136));
                        btnSubmit.setEnabled(true);
                        btnSubmit.setBackground(enabledBtn);
                    } else {
                        lblRequires.setForeground(Color.red);
                        btnSubmit.setEnabled(false);
                        btnSubmit.setBackground(disabledBtn);
                    }
                }
            }
        });
        // Button Action Listeners
        btnCancel.addActionListener((e) -> {
            mainPanel.add(lblConnect);
            cardLayout.show(cardPanel, "loginCard");
            tfdRegUName.setText("");
            tfdRegPWord.setText("");
            lblRequires.setForeground(Color.red);
            lblCharsMin.setForeground(Color.red);
            lblOneUpper.setForeground(Color.red);
            lblOneSpecial.setForeground(Color.red);
            btnSubmit.setEnabled(false);
            btnSubmit.setBackground(disabledBtn);
        });
        btnSubmit.addActionListener((e) -> {
            Thread tReg = new Thread(() -> {
                lblSuccess.setForeground(new Color(0, 163, 136));
                lblSuccess.setText("Creating account...");
                lblSuccess.setVisible(true);
                // Try for connection operations
                try {
                    if (con.isValid(4)) {
                        // Encrypt the password before putting it into the database
                        String encryptedPass = encryptPassword(newPassword);
                        // Get query to add a new customer
                        String newCustQuery = "INSERT INTO Customers VALUES (DEFAULT, DEFAULT, DEFAULT,"
                                + " ?, ?, DEFAULT, DEFAULT, DEFAULT)";
                        PreparedStatement newCustPS = con.prepareStatement(newCustQuery);
                        // Fill in question marks
                        newCustPS.setString(1, username);
                        newCustPS.setString(2, encryptedPass);
                        // Log the affected row(s)
                        int updateCount = newCustPS.executeUpdate();
                        System.out.println(updateCount + " row(s) in Customers affected");
                        lblSuccess.setText("New account successfully created.");
                    } else {
                        lblSuccess.setText("Failed to add account.");
                        lblSuccess.setForeground(Color.red);
                        lblLogCon.setVisible(true);
                    }
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.toString());
                    ex.printStackTrace();
                    lblSuccess.setText("Failed to add account.");
                    lblSuccess.setForeground(Color.red);
                }
            });
            tReg.start();
            
            // Swap card and reset values
            mainPanel.add(lblConnect);
            cardLayout.show(cardPanel, "loginCard");
            tfdRegUName.setText("");
            tfdRegPWord.setText("");
            lblRequires.setForeground(Color.red);
            lblCharsMin.setForeground(Color.red);
            lblOneUpper.setForeground(Color.red);
            lblOneSpecial.setForeground(Color.red);
            btnSubmit.setEnabled(false);
            btnSubmit.setBackground(disabledBtn);
        });
        // -------------------------------------------
        
        tbtFrame.add(cardPanel);
        tbtFrame.setDefaultCloseOperation(tbtFrame.EXIT_ON_CLOSE);
        tbtFrame.setVisible(true);
        cardLayout.show(cardPanel, "loginCard");
    }
    
    // Custom method puts label onto the Login card
    //  if coming from Employee card or Customer card
    void connectLabel() {
        mainPanel.add(lblConnect);
    }
    
    // Custom method decodes passwords read in from the database
    public String decodePassword(String codePass) {
        // Delete the last two characters
        StringBuilder passEdit = new StringBuilder(codePass);
        int length = passEdit.length();
        passEdit = passEdit.delete(length - 2, length);
        // Reverse the string
        passEdit = passEdit.reverse();
        String swapPass = passEdit.toString();
        String truePass = "";
        char c;
        int code;
        // Change each character by its ASCII code by -4
        for (int i = 0; i < swapPass.length(); i++) {
            c = swapPass.charAt(i);
            code = (int) c;
            code -= 4;
            c = (char) code;
            truePass = truePass + c;
        }
        return truePass;
    }
    
    // Custom method encrypts passwords put into the database
    public String encryptPassword(String truePass) {
        String swapPass = "";
        char c;
        int code = 33;
        // Change each character by its ASCII code by +4
        for (int j = 0; j < truePass.length(); j++) {
            c = truePass.charAt(j);
            code = (int) c;
            code += 4;
            c = (char) code;
            swapPass = swapPass + c;
        }
        // Reverse the string
        StringBuilder passSwapper = new StringBuilder(swapPass);
        passSwapper = passSwapper.reverse();
        // Add two characters unrelated to the password
        code += 2;
        passSwapper = passSwapper.append((char) code);
        code += 2;
        passSwapper = passSwapper.append((char) code);
        // Return the encrypted password
        String savedPass = passSwapper.toString();
        return savedPass;
    }
    
    void enter()
    {
//        System.out.println("\n1. Login"
//        + "\n2. Register"
//        + "\n3. Continue as Guest"
//        + "\n4. Exit"
//        + "\n\nSelect from the menu:");
    }
    
    // Any time the file is read, repopulate the array list
    void load()
    {
        try {
            // Create FileReader
            FileReader custLogins = new FileReader("customers.txt");
            BufferedReader custBuff = new BufferedReader(custLogins);
            String currentLine;
            // Read the next 8 lines and put them in the ArrayList
            while ((currentLine = custBuff.readLine()) != null) {
                String readName = currentLine;
                currentLine = custBuff.readLine();
                String readPhone = currentLine;
                currentLine = custBuff.readLine();
                String readUser = currentLine;
                // The password needs to be decoded
                currentLine = custBuff.readLine();
                String readPass = currentLine;
                // Delete the last two characters
                StringBuilder passEdit = new StringBuilder(readPass);
                int length = passEdit.length();
                passEdit = passEdit.delete(length - 2, length);
                // Reverse the string
                passEdit = passEdit.reverse();
                String swapPass = passEdit.toString();
                String truePass = "";
                char c;
                int code;
                // Change each character by its ASCII code by -4
                for (int i = 0; i < swapPass.length(); i++) {
                    c = swapPass.charAt(i);
                    code = (int) c;
                    code -= 4;
                    c = (char) code;
                    truePass = truePass + c;
                }
                currentLine = custBuff.readLine();
                String readAddr = currentLine;
                currentLine = custBuff.readLine();
                int readID = Integer.parseInt(currentLine);
                // Store largest ID to give each new user a unique ID
                largestID = readID;
                currentLine = custBuff.readLine();
                double readSpend = Double.parseDouble(currentLine);
                currentLine = custBuff.readLine();
                double readOwed = Double.parseDouble(currentLine);
                // Use values to create a Customer
                Customer readCustomer = new Customer(readName, readPhone, readUser,
                        truePass, readAddr, readID, readSpend, readOwed);
                customers.add(readCustomer);
            }
        } catch (IOException ex) {
            System.out.println("Error loading file.");
        }
    }
    
    // Any time the file is saved, clear the array list
    void save()
    {
        try {
            // Create Writers
            FileWriter custSave = new FileWriter("customers.txt");
            BufferedWriter buffSave = new BufferedWriter(custSave);
            // Print each customers' values to the file
            for (int i = 0; i < customers.size(); i++) {
                buffSave.append(customers.get(i).name + "\r\n");
                buffSave.append(customers.get(i).phoneNumber + "\r\n");
                buffSave.append(customers.get(i).loginName + "\r\n");
                // Encrypt the password before saving
                String truePass = customers.get(i).password;
                String swapPass = "";
                char c;
                int code = 33;
                // Change each character by its ASCII code by +4
                for (int j = 0; j < truePass.length(); j++) {
                    c = truePass.charAt(j);
                    code = (int) c;
                    code += 4;
                    c = (char) code;
                    swapPass = swapPass + c;
                }
                // Reverse the string
                StringBuilder passSwapper = new StringBuilder(swapPass);
                passSwapper = passSwapper.reverse();
                // Add two characters unrelated to the password
                code += 2;
                passSwapper = passSwapper.append((char) code);
                code += 2;
                passSwapper = passSwapper.append((char) code);
                // Save the encrypted password
                String savedPass = passSwapper.toString();
                buffSave.append(savedPass + "\r\n");
                buffSave.append(customers.get(i).address + "\r\n");
                buffSave.append(customers.get(i).idNumber + "\r\n");
                buffSave.append(customers.get(i).totalSpending + "\r\n");
                // If it's the final object on the list, don't move to the next line
                if (i < customers.size() - 1) {
                    buffSave.append(customers.get(i).balanceOwed + "\r\n");
                } else {
                    buffSave.append(customers.get(i).balanceOwed + "");
                }
            }
            // Save file
            buffSave.close();
        } catch (IOException ex) {
            System.out.println("Error saving file.");
        }
        // Even when failing, clear the list so the next load is not inaccurate
        customers.clear();
    }
    
    void update()
    {
//        // Booleans check for certain conditions being met to validate new passwords
//        validPassword = false;
//        uppercaseFound = false;
//        specialCharFound = false;
//        while (true)
//        {
//            Scanner s = new Scanner(System.in);
//            String input = s.nextLine();
//            
//            // Switch statement determines necessary actions to take
//            switch (input)
//            {
//                case "1":
//                    // Login. Take a username and password from the user
//                    load();
//                    managerView.load();
//                    loginSuccess = false;
//                    System.out.println("Enter username:");
//                    username = s.nextLine();
//                    System.out.println("Enter password:");
//                    newPassword = s.nextLine();
//                    
//                    // The loop will check lists for any customers that have
//                    //   a matching username and password
//                    for (int i = 0; i < customers.size(); ++i)
//                    {
//                        if (username.equals(customers.get(i).loginName) &&
//                                newPassword.equals(customers.get(i).password))
//                        {
//                            loginSuccess = true;
//                            System.out.println("Logged in as a customer.");
//                            previous = current;
//                            current = customerView;
//                        }
//                    }
//                    //  Check for an employee
//                    for (int i = 0; i < employees.size(); ++i)
//                    {
//                        if (username.equals(employees.get(i).loginName) &&
//                                newPassword.equals(employees.get(i).password))
//                        {
//                            // Then check for manager
//                            if (employees.get(i).isAManager == false)
//                            {
//                                loginSuccess = true;
//                                System.out.println("Logged in as an employee.");
//                                previous = current;
//                                current = employeeView;
//                            }
//                            else
//                            {
//                                loginSuccess = true;
//                                System.out.println("Logged in as a manager.");
//                                previous = current;
//                                current = managerView;
//                            }
//                        }
//                    }
//                    
//                    // Notify of invalid login attempt
//                    if (!loginSuccess)
//                    {
//                            System.out.println("Invalid username or password.");
//                    }
//                    // No changes were made. Clear the array list without saving
//                    customers.clear();
//                    employees.clear();
//                    return;
//                case "2":
//                    // Register. Take a new name and password to create a customer account
//                    System.out.println("Enter new username:");
//                    username = s.nextLine();
//                    System.out.println("Enter new password: "
//                            + "\n(8 characters minimum, at least 1 capital letter,"
//                            + "\nand at least 1 special character)");
//                    newPassword = s.nextLine();
//                    
//                    // Check for validation
//                    while (!validPassword)
//                    {
//                        uppercaseFound = false;
//                        specialCharFound = false;
//                        if (newPassword.length() >= 8)
//                        {
//                            // Loop to check for capital letters and special characters
//                            for (int c = 0; c < newPassword.length() && (!uppercaseFound || !specialCharFound); ++c)
//                            {
//                                if (Character.isLetterOrDigit(newPassword.charAt(c)))
//                                {
//                                    if (Character.isUpperCase(newPassword.charAt(c)))
//                                    {
//                                        uppercaseFound = true;
//                                    }
//                                }
//                                else
//                                {
//                                    specialCharFound = true;
//                                }
//                            }
//                            
//                            // After checking, check both conditions
//                            if (uppercaseFound && specialCharFound)
//                            {
//                                validPassword = true;
//                            }
//                        }
//                        
//                        // Either prompt for password again or create an account
//                        if (!validPassword)
//                        {
//                            System.out.println("Password invalid. Enter new password: "
//                                + "\n(8 characters minimum, at least 1 capital letter,"
//                                + "\nand at least 1 special character)");
//                            newPassword = s.nextLine();
//                        }
//                        else
//                        {
//                            // Load in all customers from the customer.txt file
//                            load();
//                            Customer newCustomer = new Customer("Anonymous", "###-###-####",
//                                    username, newPassword, "Hidden", largestID + 1, 0.0, 0.0);
//                            customers.add(newCustomer);
//                            // Save the file with the newly added customer
//                            save();
//                            System.out.println("New account created.");
//                        }   
//                    }
//                    return;
//                case "3":
//                    // Continue as Guest. Go straight to Customer View
//                    System.out.println("Continued as a guest.");
//                    previous = current;
//                    current = customerView;
//                    return;
//                case "4":
//                    current = exit;
//                    return;
//                default:
//                    System.out.println("*** Invalid input.");
//                    System.out.println("Select from the menu:");
//            }
//        }
    }
}
