package danielriveram6;

import java.awt.*;
import javax.swing.*;

// JLabel extension for the title of each form
public class JLabelTitle extends JLabel {
    public JLabelTitle(String text) {
        setForeground(new Color(0, 163, 136));
        setFont(new Font("Calibri", Font.BOLD, 40));
        setText(text);
        setSize(getPreferredSize().width, getPreferredSize().height);
    }
}
