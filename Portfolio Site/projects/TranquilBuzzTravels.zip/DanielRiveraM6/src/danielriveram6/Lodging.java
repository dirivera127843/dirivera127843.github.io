package danielriveram6;

import java.util.ArrayList;
import java.awt.*;
import javax.swing.*;

public abstract class Lodging {
    // Variable declarations
    String name, address, description, phoneNumber;
    int numberOfBedrooms, maxOccupants;
    double basePricePerNight;
    ArrayList<ImageIcon> lodgeImages = new ArrayList();
    boolean imgsLoaded = false;
    
    // Default constructor
    public Lodging()
    {
        name = "";
        address = "";
        description = "";
        phoneNumber = "";
        numberOfBedrooms = 0;
        maxOccupants = 0;
        basePricePerNight = 0.0;
    }
    // Constructor with definitions
    public Lodging(String nam, String addr, String desc, String phoneNum,
            int numOfBeds, int maxOcc, double basePPN)
    {
        this.name = nam;
        this.address = addr;
        this.description = desc;
        this.phoneNumber = phoneNum;
        this.numberOfBedrooms = numOfBeds;
        this.maxOccupants = maxOcc;
        this.basePricePerNight = basePPN;
    }
    
    // New .toString() override
    public String toString()
    {
        return "Lodging name: " + this.name
                + "\nAddress: " + this.address
                + "\nDescription: " + this.description
                + "\nPhone number: " + this.phoneNumber
                + "\nNumber of bedrooms: " + this.numberOfBedrooms
                + "\nMax occupants: " + this.maxOccupants
                + "\nBase price per night: $" + String.format("%.2f", this.basePricePerNight);
    }
    
    // Custom method adds proper values to a JLabel
    public String toJLabelString()
    {
        return "<html>Lodging name: " + this.name
                + "<br/>Address: " + this.address
                + "<br/>Description: " + this.description
                + "<br/>Phone number: " + this.phoneNumber
                + "<br/>Number of bedrooms: " + this.numberOfBedrooms
                + "<br/>Max occupants: " + this.maxOccupants
                + "<br/>Base price per night: $" + String.format("%.2f", this.basePricePerNight);
    }
    
    // Abstract methods used to append proper values to a file
    public abstract String returnType();
    
    public abstract String returnSubVars();
}
