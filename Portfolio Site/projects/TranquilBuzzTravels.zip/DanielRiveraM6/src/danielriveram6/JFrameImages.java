package danielriveram6;

import static danielriveram6.EmployeeView.lodges;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

// This frame is a popup window for viewing lodge images
public class JFrameImages extends JFrame {
    JPanel background = new JPanel();
    JLabel bigImage = new JLabel();
    JButtonTravel btnNext = new JButtonTravel("Next", 140, 60, false);
    JButtonTravel btnPrevious = new JButtonTravel("Previous", 140, 60, false);
    JButtonTravel btnBack = new JButtonTravel("Back", 120, 60, true);
    ArrayList<ImageIcon> lodgePhotos = new ArrayList();
    int currentImage;
    final int imgViewHeight = 540;
    float scalePercent;
    float oldImgWidth, oldImgHeight, newImgWidth;
    int intImgWidth;
    
    // Constructor
    public JFrameImages(int lodge, int currentImg) {
        currentImage = currentImg;
        for (int i = 0; i < lodges.get(lodge).lodgeImages.size(); i++) {
            Image scaledImg = lodges.get(lodge).lodgeImages.get(i).getImage();
            oldImgWidth = lodges.get(lodge).lodgeImages.get(i).getIconWidth();
            oldImgHeight = lodges.get(lodge).lodgeImages.get(i).getIconHeight();
            scalePercent = imgViewHeight / oldImgHeight;
            newImgWidth = oldImgWidth * scalePercent;
            intImgWidth = (int) newImgWidth;
            ImageIcon scaledIcon = new ImageIcon(scaledImg.getScaledInstance(intImgWidth, imgViewHeight, Image.SCALE_SMOOTH));
            lodgePhotos.add(scaledIcon);
        }
        setTitle("Lodge Image Viewer");
        setLayout(null);
        setSize(1280, 720);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        background.setBackground(new Color(209, 229, 196));
        background.setLayout(null);
        background.setBounds(0, 0, 1280, 720);
        bigImage.setSize(960, 540);
        bigImage.setLocation(getWidth()/2 - bigImage.getWidth()/2, 30);
        bigImage.setIcon(lodgePhotos.get(currentImg));
        btnNext.setLocation(740, 600);
        btnPrevious.setLocation(400, 600);
        btnBack.setLocation(20, 600);
        
        background.add(bigImage);
        background.add(btnNext);
        background.add(btnPrevious);
        background.add(btnBack);
        add(background);
        
        btnNext.addActionListener((e) -> {
            currentImage++;
            if (currentImage > lodgePhotos.size() - 1) {
                currentImage = 0;
            }
            bigImage.setIcon(lodgePhotos.get(currentImage));
        });
        btnPrevious.addActionListener((e) -> {
            currentImage--;
            if (currentImage < 0) {
                currentImage = lodgePhotos.size() - 1;
            }
            bigImage.setIcon(lodgePhotos.get(currentImage));
        });
        btnBack.addActionListener((e) -> {
            dispose();
        });
    }
}
