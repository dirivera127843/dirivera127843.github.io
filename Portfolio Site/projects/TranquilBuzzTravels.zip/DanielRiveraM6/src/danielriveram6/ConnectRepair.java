package danielriveram6;

import static danielriveram6.State.con;
import static danielriveram6.State.mySQLURL;
import static danielriveram6.State.sqlConPass;
import static danielriveram6.State.sqlConUser;
import java.awt.Color;
import java.sql.*;

public class ConnectRepair implements Runnable {
    public void run() {
        // Start by connecting to the database
        try {
            con = DriverManager.getConnection(mySQLURL, sqlConUser, sqlConPass);
        } catch (Exception ex) {
            System.out.println("Error: " + ex.toString());
            ex.printStackTrace();
        }
        while (true) {
            try {
                if (con.isValid(8)) {
                    State.lblConnect.setForeground(new Color(0, 163, 136));
                    State.lblConnect.setText("Database: connected");
                    State.lblConnect.setSize(State.lblConnect.getPreferredSize().width, State.lblConnect.getPreferredSize().height);
                } else {
                    State.lblConnect.setForeground(Color.red);
                    State.lblConnect.setText("Database: disconnected");
                    State.lblConnect.setSize(State.lblConnect.getPreferredSize().width, State.lblConnect.getPreferredSize().height);
                    try {
                        con.close();
                        con = DriverManager.getConnection(mySQLURL, sqlConUser, sqlConPass);
                    } catch (Exception reEx) {
                        System.out.println("Failed to reconnect. Trying again...");
                    }
                }
            } catch (Exception ex) {
                System.out.println("Error: " + ex.toString());
            }

            try {
                Thread.sleep(4000);
            } catch (InterruptedException e) {
                System.out.println("Error: " + e.toString());
            }
        }
    }
}
