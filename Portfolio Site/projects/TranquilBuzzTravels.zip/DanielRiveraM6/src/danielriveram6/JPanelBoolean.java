package danielriveram6;

import java.awt.*;
import javax.swing.*;

// JPanel extension for Hotel/House boolean choices
public class JPanelBoolean extends JPanel {
    // Text, buttons, and button group
    JLabel question;
    JRadioButton radYes = new JRadioButton("Yes");
    JRadioButton radNo = new JRadioButton("No");
    ButtonGroup choice = new ButtonGroup();
    // Boolean swaps depending on radio button selection
    boolean yesOrNo = false;
    
    // Constructor takes a string for the label's question
    public JPanelBoolean(String text) {
        question = new JLabel(text);
        question.setFont(new Font("Calibri", Font.PLAIN, 24));
        question.setForeground(new Color(0, 100, 83));
        question.setAlignmentX(Component.CENTER_ALIGNMENT);
        radYes.setBackground(new Color(121, 189, 143));
        radYes.setForeground(new Color(0, 100, 83));
        radYes.setFont(new Font("Calibri", Font.PLAIN, 18));
        radNo.setBackground(new Color(121, 189, 143));
        radNo.setForeground(new Color(0, 100, 83));
        radNo.setFont(new Font("Calibri", Font.PLAIN, 18));
        setBackground(new Color(121, 189, 143));
        setBorder(BorderFactory.createLineBorder(new Color(0, 163, 136), 1, false));
        choice.add(radYes);
        choice.add(radNo);
        radNo.setSelected(true);
        
        radYes.addActionListener((e) -> {
            yesOrNo = true;
        });
        radNo.addActionListener((e) -> {
            yesOrNo = false;
        });
        
        add(question);
        add(radYes);
        add(radNo);
    }
}
