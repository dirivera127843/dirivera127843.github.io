package danielriveram6;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.Calendar;
import java.util.Locale;
import javax.swing.filechooser.FileSystemView;
import java.awt.Desktop;

public class Report {
    ResultSet rs;
    ResultSetMetaData md;
    String baseIntro = "<!doctype html><html><body>";
    String title = "";
    String baseBody = "";
    String baseClose = "</table></body></html>";
    String header = "";
    String style = "";
 
    
    Report(String title, ResultSet rs) throws Exception {
        this.title = title;
        this.rs = rs;
        md = rs.getMetaData();
        setStyle();
        setHeader();
        fillTable();
        buildReport();
    }

    void setStyle() {

        style = "\n<style> body{ background-color: #d1e5c4;}"
                + "table{"
                + "border-collapse: collapse;"
                + "border: 1px solid #00a388;"
                + "margin-left: auto;"
                + "margin-right: auto;}"
                + "th{  background-color: #79bd8f;"
                + "padding: 10px;"
                + "border: 1px solid #00a388}"
                + "td { padding: 6px;"
                + "border: 1px solid #00a388}"
                + "tr:nth-child(odd){background-color: #beeb9f;}"
                + "tr:nth-child(even){background-color: #bdd0b0;}"
                + ".TableTitle{"
                + "text-align: center;"
                + "font-weight: bold;"
                + "font-size: 20px;"
                + "}"
                + "</style>\n";
    }

    void setHeader() throws Exception {
        header = "<div class = TableTitle>" + title + "</div><table><tr>\n";
        for (int i = 0; i < md.getColumnCount(); i++) {
            header += "<th>" + md.getColumnName(i + 1).toUpperCase() + "</th>";
        }
        header += "</tr>\n";
    }

    // adds rows of table data
    void fillTable() throws Exception {
        while (rs.next()) {
            baseBody += "<tr>";
            for (int i = 1; i < md.getColumnCount() + 1; i++) {
                baseBody += "<td>" + rs.getString(i) + "</td>";
            }
            baseBody += "</tr>\n";
        }
    }

    void buildReport() throws Exception {
        String time = Calendar.getInstance(Locale.getDefault()).getTime().toString();
        time = time.substring(3, 19);
        time = time.replace(" ", "");
        time = time.replace(":", "_");
        System.out.println("Time: " + time);
        String fileName = time + "report.html";
        String filePath = FileSystemView.getFileSystemView().getDefaultDirectory().getPath();
        filePath = filePath + "/Reports/" + fileName;
        BufferedWriter bw = new BufferedWriter(new FileWriter(filePath));
        String finalReport = baseIntro + style + header + baseBody + baseClose;
        bw.write(finalReport);
        bw.close();
        // Open the file in browser
        try {
            File htmlReport = new File(filePath);
            if (htmlReport.exists()) {
                Desktop.getDesktop().browse(htmlReport.toURI());
            } else {
                System.out.println("Failed to find file: " + htmlReport.getAbsolutePath());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Report saved ");
    }
}
