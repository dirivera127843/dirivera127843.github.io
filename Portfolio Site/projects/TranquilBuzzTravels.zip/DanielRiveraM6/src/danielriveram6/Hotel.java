package danielriveram6;

public class Hotel extends Lodging {
    // Variable declarations
    int vacancies;
    double parkingFee, valetParking;
    boolean hasAPool, hasWorkoutRoom, hasMiniKitchen, hasFreeBreakfast;
    
    // Default constructor
    public Hotel()
    {
        vacancies = 0;
        parkingFee = 0.0;
        valetParking = 0.0;
        hasAPool = false;
        hasWorkoutRoom = false;
        hasMiniKitchen = false;
        hasFreeBreakfast = false;
    }
    // Constructor with definitions
    public Hotel(String nam, String addr, String desc, String phoneNum,
            int numOfBeds, int maxOcc, double basePPN,  int vacanc,
            double parkFee, double vPark, boolean hasPool, boolean hasWrktRm,
            boolean hasMKitch, boolean hasFrBrkfst)
    {
        super(nam, addr, desc, phoneNum, numOfBeds, maxOcc, basePPN);
        this.vacancies = vacanc;
        this.parkingFee = parkFee;
        this.valetParking = vPark;
        this.hasAPool = hasPool;
        this.hasWorkoutRoom = hasWrktRm;
        this.hasMiniKitchen = hasMKitch;
        this.hasFreeBreakfast = hasFrBrkfst;
    }
    
    // New .toString() override
    public String toString()
    {
        String returnString = super.toString();
        returnString += "\nVacancies: " + this.vacancies
                    + "\nParking fee: $" + String.format("%.2f", this.parkingFee)
                    + "\nValet parking fee: $" + String.format("%.2f", this.valetParking)
                    + "\nHas a pool: " + this.hasAPool
                    + "\nHas a workout room: " + this.hasWorkoutRoom
                    + "\nHas a mini kitchen: " + this.hasMiniKitchen
                    + "\nHas free breakfast: " + this.hasFreeBreakfast;
        return returnString;
    }
    
    // Custom method adds proper values to a JLabel
    public String toJLabelString() {
        String returnString = super.toJLabelString();
        returnString += "<br/>Vacancies: " + this.vacancies
                    + "<br/>Parking fee: $" + String.format("%.2f", this.parkingFee)
                    + "<br/>Valet parking fee: $" + String.format("%.2f", this.valetParking)
                    + "<br/>Has a pool: " + this.hasAPool
                    + "<br/>Has a workout room: " + this.hasWorkoutRoom
                    + "<br/>Has a mini kitchen: " + this.hasMiniKitchen
                    + "<br/>Has free breakfast: " + this.hasFreeBreakfast
                    + "</html>";
        return returnString;
    }
    
    public String returnType() {
        return "Hotel";
    }
    
    public String returnSubVars() {
        return vacancies + "\r\n"
                + parkingFee + "\r\n"
                + valetParking + "\r\n"
                + hasAPool + "\r\n"
                + hasWorkoutRoom + "\r\n"
                + hasMiniKitchen + "\r\n"
                + hasFreeBreakfast;
    }
}
