package danielriveram6;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.time.LocalDate;
import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.filechooser.*;
import java.io.*;
import java.nio.file.Files;

public class EmployeeView extends State {
    // Definitions
    String inputNam;
    int endYIndex, selectID = 0, selectIndex = 0;
    final int imgPanelHeight = 108;
    float scalePercent;
    float oldImgWidth, oldImgHeight, newImgWidth;
    int intImgWidth;
    double inputBasePPN;
    boolean keepDisabled = false;
    // For Hotel
    String strHasPool, strHasWrktRm, strHasMKitch, strHasFrBrkfst;
    // For House
    String strHasGrg, strHasSecSys, strPetsAlwd;
    // ArrayList
    static ArrayList<Lodging> lodges = new ArrayList();
    ArrayList<String> lodgeNames = new ArrayList();
    ArrayList<Integer> lodgeIDs = new ArrayList();
    ArrayList<File> imageFiles = new ArrayList();
    ArrayList<String> imageNames = new ArrayList();
    ArrayList<byte[]> bytesList = new ArrayList();
    static ArrayList<Lodging> lodgeImgStorage = new ArrayList();
    // Colors for most buttons changing status
    Color enabledBtn = new Color(190, 235, 159);
    Color disabledBtn = new Color(189, 208, 176);
    // Colors for Remove Lodge button changing status
    Color enabledRemove = new Color(255, 255, 157);
    Color disabledRemove = new Color(227, 228, 179);
    // Array for abbreviated months
    String[] monthChoices = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    // Calendar and GregorianCalendars
    Calendar today = Calendar.getInstance();
    // Two for the Start and End dates input by the user
    GregorianCalendar startDate = new GregorianCalendar(today.get(Calendar.YEAR),
        today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
    GregorianCalendar endDate = new GregorianCalendar(today.get(Calendar.YEAR),
        today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
    
    // Components for Employee View -------
    // List and Panels for organizing images and buttons
    JListLodges lstLodges = new JListLodges();
    JPanelImages pnlImages = new JPanelImages();
    JPanel pnlButtons = new JPanel();
    // Title
    JLabelTitle lblEmpTitle = new JLabelTitle("Employee View");
    // Labels for lodges, images, and information
    JLabelGen lblLodges = new JLabelGen("Lodges:");
    JLabelGen lblImages = new JLabelGen("Images:");
    JLabelGen lblInfo = new JLabelGen("Lodge details:");
    // Information Label
    JLabelGen lblDetails = new JLabelGen("Select a lodge.");
    // Scrolling for Lodge List, Image Area, and Info Label
    JScrollPane scpLodges;
    JScrollPane scpImages;
    JScrollPane scpInfo;
    // A panel for laying out the ComboBoxes and Labels
    JPanel pnlCombos = new JPanel();
    // Labels for setting order date
    JLabelGen lblWhen = new JLabelGen("Select a date range for reports:");
    JLabelGen lblStart = new JLabelGen("Starting Date:");
    JLabelGen lblEnd = new JLabelGen("Ending Date:");
    // 6 ComboBoxes: three for starting date, three for ending date
    JComboBoxOrder cbxStartM = new JComboBoxOrder();
    JComboBoxOrder cbxStartD = new JComboBoxOrder();
    JComboBoxOrder cbxStartY = new JComboBoxOrder();
    JComboBoxOrder cbxEndM = new JComboBoxOrder();
    JComboBoxOrder cbxEndD = new JComboBoxOrder();
    JComboBoxOrder cbxEndY = new JComboBoxOrder();
    // 8 buttons
    JButtonTravel btnHotel = new JButtonTravel("Add Hotel", false);
    JButtonTravel btnHouse = new JButtonTravel("Add House", false);
    JButtonTravel btnImage = new JButtonTravel("Add Image", false);
    JButtonTravel btnEdit = new JButtonTravel("Edit Lodge", false);
    JButtonTravel btnLogOut = new JButtonTravel("Log Out", 140, 60, true);
    JButtonTravel btnRefresh = new JButtonTravel("Refresh", false);
    JButtonTravel btnRemove = new JButtonTravel("Remove Lodge", true);
    JButtonTravel btnReports = new JButtonTravel("Order Reports", 200, 60, false);
    // Label for showing date validation
    JLabelGen lblReports = new JLabelGen("<html>Report shows total spending<br>between selected dates</html>", 18);
    // JFileChooser for adding images to a lodge
    JFileChooser jfcImages = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
    FileNameExtensionFilter imgOnly = new FileNameExtensionFilter("Only PNG and JPG", "png", "jpg");
    // Labels for actions performed in real time
    JLabelGen lblAddEdit = new JLabelGen("Lodge has been removed.");
    JLabelGen lblError = new JLabelGen("Failed to create report.");
    JLabelGen lblImgProgress = new JLabelGen("x/n images uploaded.");
    // Label in case the connection is invalid
    JLabelGen lblEmpCon = new JLabelGen("<html>Not connected.<br>Action cancelled.</html>", 20, true);
    // ------------------------------------
    
    // Components for Add Hotel -----------
    JPanel hotelCard = new JPanel();
    // Panels for left and right side
    JPanel pnlHtlLeft = new JPanel();
    JPanel pnlHtlRight = new JPanel();
    // Panel for all boolean questions
    JPanel pnlHtlBooleans = new JPanel();
    // Title
    JLabelTitle lblHtlTitle = new JLabelTitle("Add Hotel");
    // First three fields on the left
    JLabelGen lblHtlName = new JLabelGen("Hotel name:");
    JTextFieldTravel tfdHtlName = new JTextFieldTravel(37);
    JLabelGen lblHtlAddr = new JLabelGen("Address:");
    JTextFieldTravel tfdHtlAddr = new JTextFieldTravel(37);
    JLabelGen lblHtlDesc = new JLabelGen("Description:");
    JTextAreaAdd txaHtlDesc = new JTextAreaAdd(5, 37);
    // Seven fields on the right
    JLabelGen lblHtlPhone = new JLabelGen("Phone number:");
    JTextFieldTravel tfdHtlPhone = new JTextFieldTravel(8);
    JLabelGen lblHtlBeds = new JLabelGen("Total bedrooms:");
    JTextFieldTravel tfdHtlBeds = new JTextFieldTravel(6);
    JLabelGen lblHtlMax = new JLabelGen("Max occupants:");
    JTextFieldTravel tfdHtlMax = new JTextFieldTravel(6);
    JLabelGen lblHtlVacs = new JLabelGen("Vacancies:");
    JTextFieldTravel tfdHtlVacs = new JTextFieldTravel(6);
    JLabelGen lblHtlBasePPN = new JLabelGen("Price per night:");
    JTextFieldTravel tfdHtlBasePPN = new JTextFieldTravel(6);
    JLabelGen lblHtlPark = new JLabelGen("Parking fee:");
    JTextFieldTravel tfdHtlPark = new JTextFieldTravel(6);
    JLabelGen lblHtlValet = new JLabelGen("Valet parking fee:");
    JTextFieldTravel tfdHtlValet = new JTextFieldTravel(6);
    // Boolean panels
    JPanelBoolean pool = new JPanelBoolean("Does the hotel have a pool?");
    JPanelBoolean workout = new JPanelBoolean("Does the hotel have a workout room?");
    JPanelBoolean kitchen = new JPanelBoolean("Does the hotel have mini kitchens?");
    JPanelBoolean breakfast = new JPanelBoolean("Does the hotel offer free breakfast?");
    // Buttons
    JButtonTravel btnHtlCancel = new JButtonTravel("Cancel", 140, 60, true);
    JButtonTravel btnHtlSubmit = new JButtonTravel("Submit", 140, 60, false);
    // ------------------------------------
    
    // Components for Add House -----------
    JPanel houseCard = new JPanel();
    // Panels for left and right side
    JPanel pnlHusLeft = new JPanel();
    JPanel pnlHusRight = new JPanel();
    // Panel for all boolean questions
    JPanel pnlHusBooleans = new JPanel();
    // Title
    JLabelTitle lblHusTitle = new JLabelTitle("Add House");
    // First three fields on the left
    JLabelGen lblHusName = new JLabelGen("House name:");
    JTextFieldTravel tfdHusName = new JTextFieldTravel(37);
    JLabelGen lblHusAddr = new JLabelGen("Address:");
    JTextFieldTravel tfdHusAddr = new JTextFieldTravel(37);
    JLabelGen lblHusDesc = new JLabelGen("Description:");
    JTextAreaAdd txaHusDesc = new JTextAreaAdd(5, 37);
    // Five fields on the right
    JLabelGen lblHusPhone = new JLabelGen("Phone number:");
    JTextFieldTravel tfdHusPhone = new JTextFieldTravel(8);
    JLabelGen lblHusDate = new JLabelGen("Date opened:");
    JTextFieldTravel tfdHusDate = new JTextFieldTravel(8);
    JLabelGen lblHusBeds = new JLabelGen("Total bedrooms:");
    JTextFieldTravel tfdHusBeds = new JTextFieldTravel(6);
    JLabelGen lblHusMax = new JLabelGen("Max occupants:");
    JTextFieldTravel tfdHusMax = new JTextFieldTravel(6);
    JLabelGen lblHusBasePPN = new JLabelGen("Price per night:");
    JTextFieldTravel tfdHusBasePPN = new JTextFieldTravel(6);
    // Boolean panels
    JPanelBoolean garage = new JPanelBoolean("Does the house have a garage?");
    JPanelBoolean security = new JPanelBoolean("Does the house have a security system?");
    JPanelBoolean pets = new JPanelBoolean("Are pets allowed in this house?");
    // Buttons
    JButtonTravel btnHusCancel = new JButtonTravel("Cancel", 140, 60, true);
    JButtonTravel btnHusSubmit = new JButtonTravel("Submit", 140, 60, false);
    // ------------------------------------
    
    // Components for Edit Lodge ----------
    JPanel editCard = new JPanel();
    // Panel organizes the input fields
    JPanel pnlEditFields = new JPanel();
    // Title
    JLabelTitle lblEditTitle = new JLabelTitle("Edit Lodge");
    // Text fields
    JLabelGen lblEditName = new JLabelGen("Edit lodging name:");
    JTextFieldTravel tfdEditName = new JTextFieldTravel(34);
    JLabelGen lblEditPPN = new JLabelGen("Edit price per night:");
    JTextFieldTravel tfdEditPPN = new JTextFieldTravel(6);
    // Buttons
    JButtonTravel btnEditCancel = new JButtonTravel("Cancel", 140, 60, true);
    JButtonTravel btnEditSubmit = new JButtonTravel("Submit", 140, 60, false);
    // ------------------------------------
    
    
    // Constructor creates four cards for the CardLayout
    EmployeeView() {
        // Set Frame size
        tbtFrame.setSize(1360, 765);
        
        
        // ------- EMPLOYEE VIEW CARD -------
        mainPanel.setBackground(new Color(209, 229, 196));
        mainPanel.setLayout(null);
        // Set Title in place
        lblEmpTitle.setLocation(tbtFrame.getWidth()/2 - lblEmpTitle.getWidth()/2, 20);
        // Set Labels in place
        lblLodges.setLocation(30, 70);
        lblImages.setLocation(30, 300);
        lblInfo.setLocation(550, 70);
        lblWhen.setLocation(30, 490);
        // Settings for List, Panels, and Info Label
        lstLodges.setBounds(30, 100, 500, 180);
        pnlImages.setBounds(30, 330, 1300, 140);
        lblDetails.setFont(new Font("Calibri", Font.PLAIN, 18));
        lblDetails.setBounds(550, 100, 780, 180);
        lblDetails.setVerticalAlignment(JLabel.TOP);
        pnlButtons.setBackground(new Color(209, 229, 196));
        pnlButtons.setBounds(930, 500, 400, 200);
        pnlButtons.setLayout(new GridLayout(3, 2));
        pnlCombos.setBackground(new Color(209, 229, 196));
        pnlCombos.setBounds(30, 520, 370, 100);
        pnlCombos.setLayout(new FlowLayout(FlowLayout.RIGHT));
        // Image, Edit, and Remove buttons disabled upon loading
        btnImage.setEnabled(false);
        btnImage.setBackground(disabledBtn);
        btnEdit.setEnabled(false);
        btnEdit.setBackground(disabledBtn);
        btnRemove.setEnabled(false);
        btnRemove.setBackground(disabledRemove);
        // Label settings for reports validation and add/edit results
        lblReports.setLocation(390, 650);
        lblAddEdit.setVisible(false);
        lblAddEdit.setBounds(620, 490, 270, lblAddEdit.getPreferredSize().height);
        lblError.setVisible(false);
        lblError.setForeground(Color.red);
        lblError.setBounds(620, 520, 270, lblError.getPreferredSize().height);
        // Label for failed connection
        lblEmpCon.setLocation(280, 10);
        lblEmpCon.setVisible(false);
        // LogOut and Reports buttons placed separately
        btnLogOut.setLocation(30, 645);
        btnReports.setLocation(180, 645);
        // Establish Scroll Panels
        scpLodges = new JScrollPane(lstLodges, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scpLodges.setBounds(30, 100, 500, 180);
        scpImages = new JScrollPane(pnlImages, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scpImages.setBounds(30, 330, 1300, 140);
        scpInfo = new JScrollPane(lblDetails, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scpInfo.setBounds(550, 100, 780, 180);
        // Settings for JFileChooser
        jfcImages.setMultiSelectionEnabled(true);
        jfcImages.setAcceptAllFileFilterUsed(false);
        jfcImages.setDialogTitle("Select an image");
        jfcImages.addChoosableFileFilter(imgOnly);
        // Settings for progress text
        lblImgProgress.setBounds(630, 665, 270, lblImgProgress.getPreferredSize().height);
        lblImgProgress.setVisible(false);
        
        // Add to End date. Reports only reach three years after today
        endDate.add(Calendar.YEAR, 3);
        // Give values to Start and End month
        for (String monthChoice : monthChoices) {
            cbxStartM.addItem(monthChoice);
            cbxEndM.addItem(monthChoice);
        }
        cbxStartM.setSelectedIndex(startDate.get(Calendar.MONTH));
        cbxEndM.setSelectedIndex(endDate.get(Calendar.MONTH));
        // Give values to Start and End days
        for (int i = 0; i < startDate.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
            cbxStartD.addItem(i + 1);
        }
        // End gets its own loop in case of a leap year
        for (int i = 0; i < endDate.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
            cbxEndD.addItem(i + 1);
        }
        cbxStartD.setSelectedIndex(startDate.get(Calendar.DAY_OF_MONTH) - 1);
        cbxEndD.setSelectedIndex(endDate.get(Calendar.DAY_OF_MONTH) - 1);
        // Store the index to reset the end date's year
        int tempEndYear = 0;
        // Give values to Start and End years
        for (int i = 2022; i <= endDate.get(Calendar.YEAR); i++) {
            cbxStartY.addItem(i);
            cbxEndY.addItem(i);
            if (i == endDate.get(Calendar.YEAR)) {
                endYIndex = tempEndYear;
            }
            tempEndYear++;
        }
        cbxStartY.setSelectedIndex(0);
        cbxEndY.setSelectedIndex(endYIndex);
        
        // Add items to ComboBox panel
        pnlCombos.add(lblStart);
        pnlCombos.add(cbxStartM);
        pnlCombos.add(cbxStartD);
        pnlCombos.add(cbxStartY);
        pnlCombos.add(lblEnd);
        pnlCombos.add(cbxEndM);
        pnlCombos.add(cbxEndD);
        pnlCombos.add(cbxEndY);
        
        // Add items to button panel
        pnlButtons.add(btnRefresh);
        pnlButtons.add(btnImage);
        pnlButtons.add(btnHotel);
        pnlButtons.add(btnEdit);
        pnlButtons.add(btnHouse);
        pnlButtons.add(btnRemove);
        
        // Add all items to employeeCard
        mainPanel.add(lblEmpTitle);
        mainPanel.add(lblLodges);
        mainPanel.add(scpLodges);
        mainPanel.add(lblImages);
        mainPanel.add(scpImages);
        mainPanel.add(lblInfo);
        mainPanel.add(scpInfo);
        mainPanel.add(lblWhen);
        mainPanel.add(pnlCombos);
        mainPanel.add(pnlButtons);
        mainPanel.add(btnLogOut);
        mainPanel.add(btnReports);
        mainPanel.add(lblReports);
        mainPanel.add(lblImgProgress);
        mainPanel.add(lblAddEdit);
        mainPanel.add(lblError);
        mainPanel.add(lblEmpCon);
        mainPanel.add(jfcImages);
        // Add card to layout
        cardPanel.add(mainPanel, "employeeCard");
        // -------------------------------------
        
        // ------- ADD HOTEL CARD -------
        hotelCard.setBackground(new Color(209, 229, 196));
        hotelCard.setLayout(null);
        // Set Title in place
        lblHtlTitle.setLocation(tbtFrame.getWidth()/2 - lblHtlTitle.getWidth()/2, 20);
        // Set layouts and styles for panels
        pnlHtlLeft.setBackground(new Color(209, 229, 196));
        pnlHtlLeft.setSize(870, 250);
        pnlHtlLeft.setLocation(tbtFrame.getWidth()/2 - pnlHtlLeft.getWidth()/2, 70);
        pnlHtlLeft.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pnlHtlRight.setBackground(new Color(209, 229, 196));
        pnlHtlRight.setBounds(795, 330, 320, 280);
        pnlHtlRight.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pnlHtlBooleans.setBackground(new Color(209, 229, 196));
        pnlHtlBooleans.setBounds(195, 370, 600, 195);
        pnlHtlBooleans.setLayout(new FlowLayout());
        // Buttons placed separately
        btnHtlCancel.setLocation(245, 630);
        btnHtlSubmit.setLocation(975, 630);
        // Start form with Submit button disabled
        btnHtlSubmit.setEnabled(false);
        btnHtlSubmit.setBackground(disabledBtn);
        // Add items to left panel
        pnlHtlLeft.add(lblHtlName);
        pnlHtlLeft.add(tfdHtlName);
        pnlHtlLeft.add(lblHtlAddr);
        pnlHtlLeft.add(tfdHtlAddr);
        pnlHtlLeft.add(lblHtlDesc);
        pnlHtlLeft.add(txaHtlDesc);
        // Add items to right panel
        pnlHtlRight.add(lblHtlPhone);
        pnlHtlRight.add(tfdHtlPhone);
        pnlHtlRight.add(lblHtlBeds);
        pnlHtlRight.add(tfdHtlBeds);
        pnlHtlRight.add(lblHtlMax);
        pnlHtlRight.add(tfdHtlMax);
        pnlHtlRight.add(lblHtlVacs);
        pnlHtlRight.add(tfdHtlVacs);
        pnlHtlRight.add(lblHtlBasePPN);
        pnlHtlRight.add(tfdHtlBasePPN);
        pnlHtlRight.add(lblHtlPark);
        pnlHtlRight.add(tfdHtlPark);
        pnlHtlRight.add(lblHtlValet);
        pnlHtlRight.add(tfdHtlValet);
        // Add items to boolean panel
        pnlHtlBooleans.add(pool);
        pnlHtlBooleans.add(workout);
        pnlHtlBooleans.add(kitchen);
        pnlHtlBooleans.add(breakfast);
        
        // Add all items to hotelCard
        hotelCard.add(lblHtlTitle);
        hotelCard.add(pnlHtlLeft);
        hotelCard.add(pnlHtlRight);
        hotelCard.add(pnlHtlBooleans);
        hotelCard.add(btnHtlCancel);
        hotelCard.add(btnHtlSubmit);
        // Add card to layout
        cardPanel.add(hotelCard, "hotelCard");
        // -------------------------------------
        
        // ------- ADD HOUSE CARD -------
        houseCard.setBackground(new Color(209, 229, 196));
        houseCard.setLayout(null);
        // Set Title in place
        lblHusTitle.setLocation(tbtFrame.getWidth()/2 - lblHusTitle.getWidth()/2, 20);
        // Set layouts and styles for panels
        pnlHusLeft.setBackground(new Color(209, 229, 196));
        pnlHusLeft.setSize(870, 250);
        pnlHusLeft.setLocation(tbtFrame.getWidth()/2 - pnlHusLeft.getWidth()/2, 70);
        pnlHusLeft.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pnlHusRight.setBackground(new Color(209, 229, 196));
        pnlHusRight.setBounds(795, 330, 320, 205);
        pnlHusRight.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pnlHusBooleans.setBackground(new Color(209, 229, 196));
        pnlHusBooleans.setBounds(200, 355, 600, 150);
        pnlHusBooleans.setLayout(new FlowLayout());
        // Buttons placed separately
        btnHusCancel.setLocation(245, 550);
        btnHusSubmit.setLocation(975, 550);
        // Start form with Submit button disabled
        btnHusSubmit.setEnabled(false);
        btnHusSubmit.setBackground(disabledBtn);
        // Add items to left panel
        pnlHusLeft.add(lblHusName);
        pnlHusLeft.add(tfdHusName);
        pnlHusLeft.add(lblHusAddr);
        pnlHusLeft.add(tfdHusAddr);
        pnlHusLeft.add(lblHusDesc);
        pnlHusLeft.add(txaHusDesc);
        // Add items to right panel
        pnlHusRight.add(lblHusPhone);
        pnlHusRight.add(tfdHusPhone);
        pnlHusRight.add(lblHusDate);
        pnlHusRight.add(tfdHusDate);
        pnlHusRight.add(lblHusBeds);
        pnlHusRight.add(tfdHusBeds);
        pnlHusRight.add(lblHusMax);
        pnlHusRight.add(tfdHusMax);
        pnlHusRight.add(lblHusBasePPN);
        pnlHusRight.add(tfdHusBasePPN);
        // Add items to boolean panel
        pnlHusBooleans.add(garage);
        pnlHusBooleans.add(security);
        pnlHusBooleans.add(pets);
        
        // Add all items to houseCard
        houseCard.add(lblHusTitle);
        houseCard.add(pnlHusLeft);
        houseCard.add(pnlHusRight);
        houseCard.add(pnlHusBooleans);
        houseCard.add(btnHusCancel);
        houseCard.add(btnHusSubmit);
        // Add card to layout
        cardPanel.add(houseCard, "houseCard");
        // -------------------------------------
        
        // ------- EDIT LODGE CARD -------
        editCard.setBackground(new Color(209, 229, 196));
        editCard.setLayout(null);
        // Set Title in place
        lblEditTitle.setLocation(tbtFrame.getWidth()/2 - lblEditTitle.getWidth()/2, 20);
        // Set layouts and styles for panels separating fields and buttons
        pnlEditFields.setBackground(new Color(209, 229, 196));
        pnlEditFields.setBounds(30, 70, 660, 85);
        pnlEditFields.setSize(870, 85);
        pnlEditFields.setLocation(tbtFrame.getWidth()/2 - pnlEditFields.getWidth()/2, 70);
        pnlEditFields.setLayout(new FlowLayout());
        // Buttons placed separately
        btnEditCancel.setLocation(280, 200);
        btnEditSubmit.setLocation(940, 200);
        // Add items to input panel
        pnlEditFields.add(lblEditName);
        pnlEditFields.add(tfdEditName);
        pnlEditFields.add(lblEditPPN);
        pnlEditFields.add(tfdEditPPN);
        
        // Add all items to editCard
        editCard.add(lblEditTitle);
        editCard.add(pnlEditFields);
        editCard.add(btnEditCancel);
        editCard.add(btnEditSubmit);
        // Add card to layout
        cardPanel.add(editCard, "editCard");
        // -------------------------------------
        
        // ---- EMPLOYEE VIEW FUNCTIONALITY ----
        // List Selection Listener
        lstLodges.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    if (lstLodges.getSelectedIndex() != -1) {
                        int selectedIndex = lstLodges.getSelectedIndex();
                        selectIndex = lstLodges.getSelectedIndex();
                        // Use index to get the ID
                        selectID = lodgeIDs.get(selectIndex);
                        lblDetails.setText(lodges.get(selectIndex).toJLabelString());
                        tfdEditName.setText(lodges.get(selectIndex).name);
                        tfdEditPPN.setText(String.format("%.2f", lodges.get(selectIndex).basePricePerNight));
                        Thread tSelect = new Thread(() -> {
                            // Use a newly created index to avoid errors with multiple threads
                            int threadIndex = selectedIndex;
                            pnlImages.removeAll();
                            pnlImages.revalidate();
                            pnlImages.repaint();
                            if (lodges.get(threadIndex).lodgeImages.isEmpty() && lodges.get(threadIndex).imgsLoaded == false) {
                                try {
                                    if (con.isValid(4)) {
                                        // Query for the lodge's images
                                        String imagesQuery = "SELECT Image FROM Images"
                                                + " WHERE Lodge_ID = " + selectID;
                                        PreparedStatement imgPS = con.prepareStatement(imagesQuery);
                                        ResultSet imgRS = imgPS.executeQuery();
                                        Blob imgBlob = null;
                                        // Loop through results to fill ArrayList
                                        while (imgRS.next()) {
                                            imgBlob = imgRS.getBlob(1);
                                            byte[] b = imgBlob.getBytes(1, (int) imgBlob.length());
                                            ImageIcon img = new ImageIcon(b);
                                            lodges.get(threadIndex).lodgeImages.add(img);
                                        }
                                        lodges.get(threadIndex).imgsLoaded = true;
                                        firstImgLoad = true;
                                    } else {
                                        lblEmpCon.setVisible(true);
                                    }
                                } catch (Exception ex) {
                                    System.out.println("Error: " + ex.toString());
                                    ex.printStackTrace();
                                }
                            }
                            // Loop has two checks to ensure only the selected lodge's images show
                            for (int i = 0; i < lodges.get(threadIndex).lodgeImages.size(); i++) {
                                if (threadIndex != selectIndex) {
                                    pnlImages.removeAll();
                                    pnlImages.revalidate();
                                    pnlImages.repaint();
                                    break;
                                }
                                Image scaledImg = lodges.get(threadIndex).lodgeImages.get(i).getImage();
                                oldImgWidth = lodges.get(selectIndex).lodgeImages.get(i).getIconWidth();
                                oldImgHeight = lodges.get(selectIndex).lodgeImages.get(i).getIconHeight();
                                scalePercent = imgPanelHeight / oldImgHeight;
                                newImgWidth = oldImgWidth * scalePercent;
                                intImgWidth = (int) newImgWidth;
                                ImageIcon scaledIcon = new ImageIcon(scaledImg.getScaledInstance(intImgWidth, imgPanelHeight, Image.SCALE_SMOOTH));
                                if (threadIndex == selectIndex) {
                                    JLabelImage label = new JLabelImage(scaledIcon, threadIndex, i);
                                    pnlImages.add(label);
                                    pnlImages.revalidate();
                                    pnlImages.repaint();
                                } else {
                                    break;
                                }
                            }
                        });
                        tSelect.start();
                        btnImage.setEnabled(true);
                        btnImage.setBackground(enabledBtn);
                        btnEdit.setEnabled(true);
                        btnEdit.setBackground(enabledBtn);
                        if (keepDisabled == false) {
                            btnRemove.setEnabled(true);
                            btnRemove.setBackground(enabledRemove);
                        }
                    }
                    else {
                        pnlImages.removeAll();
                        pnlImages.revalidate();
                        pnlImages.repaint();
                        selectID = 0;
                        lblDetails.setText("Select a lodge.");
                        btnImage.setEnabled(false);
                        btnImage.setBackground(disabledBtn);
                        btnEdit.setEnabled(false);
                        btnEdit.setBackground(disabledBtn);
                        btnRemove.setEnabled(false);
                        btnRemove.setBackground(disabledRemove);
                        tfdEditName.setText("");
                        tfdEditPPN.setText("");
                    }
                    lblAddEdit.setVisible(false);
                    lblError.setVisible(false);
                    if (keepDisabled == false) {
                        lblImgProgress.setVisible(false);
                    }
                }
            }
        });
        // ComboBox Action Listeners
        cbxStartM.addActionListener((e) -> {
            // Read each starting ComboBox and set its values to a temp calendar
            Calendar cTemp = Calendar.getInstance();
            int year = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
            int month = cbxStartM.getSelectedIndex();
            int day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            cTemp.set(year, month, 1);
            // Adjust the selected day if it is an invalid date
            if (day > cTemp.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                day = cTemp.getActualMaximum(Calendar.DAY_OF_MONTH);
            }
            // Clear Start Day ComboBox, repopulate and select
            cbxStartD.removeAllItems();
            for (int i = 0; i < cTemp.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                cbxStartD.addItem(i + 1);
            }
            cbxStartD.setSelectedIndex(day - 1);
            // Reread the day value for a complete Start Date
            day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            startDate.set(year, month, day);
            
            // Check for valid dates
            validateDates();
        });
        cbxStartD.addActionListener((e) -> {
            if (cbxStartD.getSelectedItem() != null) {
                // Read each starting ComboBox and set its values to the Gregorian Calendar
                int year = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
                int month = cbxStartM.getSelectedIndex();
                int day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
                startDate.set(year, month, day);
                // Check for valid dates
                validateDates();
                lblAddEdit.setVisible(false);
            }
        });
        cbxStartY.addActionListener((e) -> {
            // Repeat Month code for Start Year ComboBox in case of a leap year
            Calendar cTemp = Calendar.getInstance();
            int year = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
            int month = cbxStartM.getSelectedIndex();
            int day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            cTemp.set(year, month, 1);
            if (day > cTemp.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                day = cTemp.getActualMaximum(Calendar.DAY_OF_MONTH);
            }
            cbxStartD.removeAllItems();
            for (int i = 0; i < cTemp.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                cbxStartD.addItem(i + 1);
            }
            cbxStartD.setSelectedIndex(day - 1);
            day = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            startDate.set(year, month, day);
            
            // Check for valid dates
            validateDates();
        });
        cbxEndM.addActionListener((e) -> {
            // Read each ending ComboBox and set its values to a temp calendar
            Calendar cTemp = Calendar.getInstance();
            int year = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
            int month = cbxEndM.getSelectedIndex();
            int day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            cTemp.set(year, month, 1);
            // Adjust the selected day if it is an invalid date
            if (day > cTemp.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                day = cTemp.getActualMaximum(Calendar.DAY_OF_MONTH);
            }
            // Clear End Day ComboBox, repopulate and select
            cbxEndD.removeAllItems();
            for (int i = 0; i < cTemp.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                cbxEndD.addItem(i + 1);
            }
            cbxEndD.setSelectedIndex(day - 1);
            // Reread the day value for a complete End Date
            day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            endDate.set(year, month, day);
            
            // Check for valid dates
            validateDates();
        });
        cbxEndD.addActionListener((e) -> {
            if (cbxEndD.getSelectedItem() != null) {
                // Read each ending ComboBox and set its values to the calendar
                int year = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
                int month = cbxEndM.getSelectedIndex();
                int day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
                endDate.set(year, month, day);
                // Check for valid dates
                validateDates();
                lblAddEdit.setVisible(false);
            }
        });
        cbxEndY.addActionListener((e) -> {
            // Repeat Month code for End Year ComboBox in case of a leap year
            Calendar cTemp = Calendar.getInstance();
            int year = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
            int month = cbxEndM.getSelectedIndex();
            int day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            cTemp.set(year, month, 1);
            if (day > cTemp.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                day = cTemp.getActualMaximum(Calendar.DAY_OF_MONTH);
            }
            cbxEndD.removeAllItems();
            for (int i = 0; i < cTemp.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                cbxEndD.addItem(i + 1);
            }
            cbxEndD.setSelectedIndex(day - 1);
            day = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            endDate.set(year, month, day);
            
            // Check for valid dates
            validateDates();
        });
        // Button Action Listeners
        btnLogOut.addActionListener((e) -> {
            login.connectLabel();
            cardLayout.show(cardPanel, "loginCard");
            lblEmpCon.setVisible(false);
            lstLodges.clearSelection();
        });
        btnReports.addActionListener((e) -> {
            // Disable button to prevent spam
            btnReports.setEnabled(false);
            btnReports.setBackground(disabledBtn);
            // Read the comboboxes for starting and ending dates
            int sYear = Integer.parseInt((String) cbxStartY.getSelectedItem().toString());
            int sMonth = cbxStartM.getSelectedIndex();
            int sDay = Integer.parseInt((String) cbxStartD.getSelectedItem().toString());
            int eYear = Integer.parseInt((String) cbxEndY.getSelectedItem().toString());
            int eMonth = cbxEndM.getSelectedIndex();
            int eDay = Integer.parseInt((String) cbxEndD.getSelectedItem().toString());
            LocalDate sDate = LocalDate.of(sYear, sMonth + 1, sDay);
            LocalDate eDate = LocalDate.of(eYear, eMonth + 1, eDay);
            Thread tReport = new Thread(() -> {
                // Try for connection
                try {
                    if (con.isValid(4)) {
                        // Create query for getting all customers' total spending
                        String empReportQuery = "SELECT Customer_Username, SUM(Total) AS Total_Spending"
                                + " FROM Customers c JOIN Orders o"
                                + " ON c.Customer_ID = o.Customer_ID"
                                + " WHERE StartingDate BETWEEN '" + sDate + "' AND '" + eDate + "'"
                                + " GROUP BY Customer_Username";
                        PreparedStatement empRepPS = con.prepareStatement(empReportQuery);
                        ResultSet empRepRS = empRepPS.executeQuery();
                        // Create a report
                        Report empReport = new Report("Total Spending of All Customers", empRepRS);
                        lblAddEdit.setText("Report has been created.");
                    } else {
                        lblAddEdit.setVisible(false);
                        lblError.setText("Failed to create report.");
                        lblError.setVisible(true);
                        lblEmpCon.setVisible(true);
                    }
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.toString());
                    ex.printStackTrace();
                    lblAddEdit.setVisible(false);
                    lblError.setText("Failed to create report.");
                    lblError.setVisible(true);
                }
                btnReports.setEnabled(true);
                btnReports.setBackground(enabledBtn);
            });
            tReport.start();
            lblEmpCon.setVisible(false);
            lblError.setVisible(false);
            lblAddEdit.setText("Creating report...");
            lblAddEdit.setVisible(true);
        });
        btnRemove.addActionListener((e) -> {
            btnRemove.setEnabled(false);
            btnRemove.setBackground(disabledRemove);
            lblEmpCon.setVisible(false);
            lblError.setVisible(false);
            Thread tRemove = new Thread(() -> {
                try {
                    if (con.isValid(4)) {
                        // Use the ID obtained from list selection
                        // Delete from Lodgings. All foreign keys are ON DELETE CASCADE, so
                        //  the Images, Orders, Houses, and Hotels table will delete their
                        //  connected rows automatically
                        String lodgeDeleteQuery = "DELETE FROM Lodgings"
                                + " WHERE Lodge_ID = " + selectID;
                        PreparedStatement lodDelPS = con.prepareStatement(lodgeDeleteQuery);
                        // Log the affected row(s)
                        int updateCount = lodDelPS.executeUpdate(lodgeDeleteQuery);
                        System.out.println(updateCount + " row(s) affected");
                        // Also remove the lodge in the ArrayList
                        lodges.remove(selectIndex);
                        // Refresh after deleting to prevent selection errors
                        lstLodges.clearSelection();
                        refresh();
                        lblAddEdit.setVisible(true);
                        lblAddEdit.setText("Lodge has been removed.");
                    } else {
                        lblAddEdit.setVisible(false);
                        lblError.setText("Failed to remove lodge.");
                        lblError.setVisible(true);
                        lblEmpCon.setVisible(true);
                    }
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.toString());
                    ex.printStackTrace();
                    lblAddEdit.setVisible(false);
                    lblError.setText("Failed to remove lodge.");
                    lblError.setVisible(true);
                }
            });
            tRemove.start();
            lblAddEdit.setText("Removing lodge...");
            lblAddEdit.setVisible(true);
        });
        btnRefresh.addActionListener((e) -> {
            // Briefly disable the button so refreshes can't be spammed
            btnRefresh.setEnabled(false);
            btnRefresh.setBackground(disabledBtn);
            lblEmpCon.setVisible(false);
            lblError.setVisible(false);
            lstLodges.clearSelection();
            Thread tRefresh = new Thread(() -> {
                refresh();
                btnRefresh.setEnabled(true);
                btnRefresh.setBackground(enabledBtn);
                lblAddEdit.setText("Lodge data refreshed.");
            });
            tRefresh.start();
            lblAddEdit.setText("Refreshing...");
            lblAddEdit.setVisible(true);
        });
        btnHotel.addActionListener((e) -> {
            hotelCard.add(lblConnect);
            cardLayout.show(cardPanel, "hotelCard");
            lblAddEdit.setVisible(false);
            lblError.setVisible(false);
            lblEmpCon.setVisible(false);
        });
        btnHouse.addActionListener((e) -> {
            houseCard.add(lblConnect);
            cardLayout.show(cardPanel, "houseCard");
            lblAddEdit.setVisible(false);
            lblError.setVisible(false);
            lblEmpCon.setVisible(false);
        });
        btnImage.addActionListener((e) -> {
            lblAddEdit.setVisible(false);
            lblError.setVisible(false);
            lblEmpCon.setVisible(false);
            int photo = jfcImages.showOpenDialog(null);
            
            if (photo == JFileChooser.APPROVE_OPTION) {
                lblImgProgress.setVisible(true);
                // Disable Refresh and Remove until all images are added
                btnRefresh.setEnabled(false);
                btnRefresh.setBackground(disabledBtn);
                btnRemove.setEnabled(false);
                btnRemove.setBackground(disabledRemove);
                // Boolean prevents Remove button from enabling early by selecting a lodge
                keepDisabled = true;
                Thread tAddImages = new Thread (() -> {
                    try {
                        // Use new int to prevent incorrect writing
                        int threadIndex = selectIndex;
                        // Reset lists
                        imageFiles.clear();
                        imageNames.clear();
                        bytesList.clear();
                        File[] files = jfcImages.getSelectedFiles();
                        int imgsToAdd = files.length;
                        int imgsAdded = 0;
                        lblImgProgress.setText(imgsAdded + "/" + imgsToAdd + " images uploaded.");
                        String addImgQuery = "INSERT INTO Images VALUES";
                        // Fill lists and change the query
                        for (int i = 0; i < files.length; i++) {
                            imageFiles.add(files[i]);
                            
                            imageNames.add(files[i].getName());
                            byte[] img = Files.readAllBytes(files[i].toPath());
                            bytesList.add(img);

                            if (i != files.length - 1) {
                                addImgQuery += " (?, ?, ?),";
                            } else {
                                addImgQuery += " (?, ?, ?)";
                            }   
                        }
                        // Also add to the ArrayList so new pictures can display
                        Blob imgBlob = null;
                        int imageCount = lodges.get(threadIndex).lodgeImages.size();

                        try {
                            if (con.isValid(4)) {
                                // Use the constructed query from the above loop
                                PreparedStatement addImgPS = con.prepareStatement(addImgQuery);
                                // Fill in question marks
                                int v = 1;
                                for (int i = 0; i < imageFiles.size(); i++) {
                                    addImgPS.setInt(v, selectID);
                                    v++;
                                    addImgPS.setString(v, imageNames.get(i));
                                    v++;
                                    addImgPS.setBinaryStream(v, new ByteArrayInputStream(bytesList.get(i), 0, bytesList.get(i).length));
                                    v++;
                                    // Also add the image to the ArrayList so new pictures can display
                                    byte[] b = bytesList.get(i);
                                    ImageIcon img = new ImageIcon(b);
                                    lodges.get(threadIndex).lodgeImages.add(img);
                                    Image scaledImg = img.getImage();
                                    // !!!! Later, use calculations to scale images !!!!
                                    ImageIcon scaledIcon = new ImageIcon(scaledImg.getScaledInstance(192, 108, Image.SCALE_SMOOTH));
                                    JLabelImage label = new JLabelImage(scaledIcon, threadIndex, imageCount);
                                    imageCount++;
                                    pnlImages.add(label);
                                    pnlImages.revalidate();
                                    pnlImages.repaint();
                                    // Lastly, update the progress label
                                    imgsAdded++;
                                    lblImgProgress.setText(imgsAdded + "/" + imgsToAdd + " images uploaded.");
                                }
                                // Log the affected row(s)
                                int updateCount = addImgPS.executeUpdate();
                                System.out.println(updateCount + " row(s) in Images affected");
                                lblAddEdit.setText("Uploaded all images.");
                                lblAddEdit.setVisible(true);
                            } else {
                                lblEmpCon.setVisible(true);
                                lblError.setVisible(true);
                                lblError.setText("Failed to add image.");
                            }
                        } catch (Exception ex) {
                            System.out.println("Error: " + ex.toString());
                            ex.printStackTrace();
                            lblError.setVisible(true);
                            lblError.setText("Failed to add image.");
                        }
                    } catch (IOException exIO) {
                        System.out.println("Error: " + exIO.toString());
                        exIO.printStackTrace();
                        lblError.setVisible(true);
                        lblError.setText("Failed to add image.");
                    }
                    btnRefresh.setEnabled(true);
                    btnRefresh.setBackground(enabledBtn);
                    btnRemove.setEnabled(true);
                    btnRemove.setBackground(enabledRemove);
                    keepDisabled = false;
                });
                tAddImages.start();
            } else {
                System.out.println("Image addition cancelled");
            }
        });
        btnEdit.addActionListener((e) -> {
            editCard.add(lblConnect);
            cardLayout.show(cardPanel, "editCard");
            lblAddEdit.setVisible(false);
            lblError.setVisible(false);
            lblEmpCon.setVisible(false);
        });
        // -------------------------------------
        
        // ------ ADD HOTEL FUNCTIONALITY ------
        // KeyListeners
        tfdHtlName.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        tfdHtlAddr.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        txaHtlDesc.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        tfdHtlPhone.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers and dashes can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE ||
                        e.getKeyChar() == KeyEvent.VK_MINUS) {
                   tfdHtlPhone.setEditable(true);
                } else {
                   tfdHtlPhone.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        tfdHtlBeds.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE) {
                   tfdHtlBeds.setEditable(true);
                } else {
                   tfdHtlBeds.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        tfdHtlMax.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE) {
                   tfdHtlMax.setEditable(true);
                } else {
                   tfdHtlMax.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        tfdHtlVacs.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE) {
                   tfdHtlVacs.setEditable(true);
                } else {
                   tfdHtlVacs.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        tfdHtlBasePPN.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers and decimal places can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE ||
                        e.getKeyChar() == KeyEvent.VK_PERIOD) {
                   tfdHtlBasePPN.setEditable(true);
                } else {
                   tfdHtlBasePPN.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        tfdHtlPark.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers and decimal places can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE ||
                        e.getKeyChar() == KeyEvent.VK_PERIOD) {
                   tfdHtlPark.setEditable(true);
                } else {
                   tfdHtlPark.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        tfdHtlValet.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers and decimal places can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE ||
                        e.getKeyChar() == KeyEvent.VK_PERIOD) {
                   tfdHtlValet.setEditable(true);
                } else {
                   tfdHtlValet.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHotel();
            }
        });
        // Buttons
        btnHtlCancel.addActionListener((e) -> {
            mainPanel.add(lblConnect);
            cardLayout.show(cardPanel, "employeeCard");
            resetHotel();
        });
        btnHtlSubmit.addActionListener((e) -> {
            // Clear selection and disable refresh
            btnRefresh.setEnabled(false);
            btnRefresh.setBackground(disabledBtn);
            lstLodges.clearSelection();
            Thread tHtlSubmit = new Thread(() -> {
                try {
                    if (con.isValid(4)) {
                        // Some values need to be parsed/converted
                        inputBasePPN = Double.parseDouble(tfdHtlBasePPN.getText());
                        strHasPool = Boolean.toString(pool.yesOrNo);
                        strHasWrktRm = Boolean.toString(workout.yesOrNo);
                        strHasMKitch = Boolean.toString(kitchen.yesOrNo);
                        strHasFrBrkfst = Boolean.toString(breakfast.yesOrNo);
                        // Get query to add a new Lodge
                        String newLodQuery = "INSERT INTO Lodgings VALUES (DEFAULT, 'Hotel',"
                                + " ?, ?, ?, ?, ?, ?, ?)";
                        PreparedStatement newLodPS = con.prepareStatement(newLodQuery);
                        // Fill in question marks
                        newLodPS.setString(1, tfdHtlName.getText());
                        newLodPS.setString(2, tfdHtlAddr.getText());
                        newLodPS.setString(3, txaHtlDesc.getText());
                        newLodPS.setString(4, tfdHtlPhone.getText());
                        newLodPS.setString(5, tfdHtlBeds.getText());
                        newLodPS.setString(6, tfdHtlMax.getText());
                        newLodPS.setDouble(7, inputBasePPN);
                        // Log the affected row(s)
                        int updateCount = newLodPS.executeUpdate();
                        System.out.println(updateCount + " row(s) in Lodgings affected");
                        // Query for the new Lodge's ID
                        String newIdQuery = "SELECT MAX(Lodge_ID) AS HighestID FROM Lodgings";
                        PreparedStatement newIdPS = con.prepareStatement(newIdQuery);
                        ResultSet newIdRS = newIdPS.executeQuery();
                        int newId = 99;
                        if (newIdRS.next()) {
                            newId = newIdRS.getInt(1);
                        }
                        // Create a query adding a new Hotel
                        String newHtlQuery = "INSERT INTO Hotels VALUES (DEFAULT, ?,"
                                + " ?, ?, ?, ?, ?, ?, ?)";
                        PreparedStatement newHtlPS = con.prepareStatement(newHtlQuery);
                        // Fill in question marks
                        newHtlPS.setInt(1, newId);
                        newHtlPS.setString(2, tfdHtlVacs.getText());
                        newHtlPS.setString(3, tfdHtlPark.getText());
                        newHtlPS.setString(4, tfdHtlValet.getText());
                        newHtlPS.setString(5, strHasPool);
                        newHtlPS.setString(6, strHasWrktRm);
                        newHtlPS.setString(7, strHasMKitch);
                        newHtlPS.setString(8, strHasFrBrkfst);
                        // Log the affected row(s)
                        updateCount = newHtlPS.executeUpdate();
                        System.out.println(updateCount + " row(s) in Hotels affected");
                        // Refresh to fill in the list with the newly added Hotel
                        lstLodges.clearSelection();
                        refresh();
                        lblAddEdit.setVisible(true);
                        lblAddEdit.setText("New hotel added.");
                        resetHotel();
                    } else {
                        lblAddEdit.setVisible(false);
                        lblError.setText("Failed to add hotel.");
                        lblError.setVisible(true);
                        lblEmpCon.setVisible(true);
                        resetHotel();
                    }
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.toString());
                    ex.printStackTrace();
                    lblAddEdit.setVisible(false);
                    lblError.setText("Failed to add hotel.");
                    lblError.setVisible(true);
                    resetHotel();
                }
                btnRefresh.setEnabled(true);
                btnRefresh.setBackground(enabledBtn);
            });
            tHtlSubmit.start();
            lblError.setVisible(false);
            lblEmpCon.setVisible(false);
            lblAddEdit.setVisible(true);
            lblAddEdit.setText("Adding new hotel...");
            mainPanel.add(lblConnect);
            cardLayout.show(cardPanel, "employeeCard");
        });
        // -------------------------------------
        
        // ------ ADD HOUSE FUNCTIONALITY ------
        // KeyListeners
        tfdHusName.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHouse();
            }
        });
        tfdHusAddr.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHouse();
            }
        });
        txaHusDesc.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHouse();
            }
        });
        tfdHusPhone.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers and dashes can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE ||
                        e.getKeyChar() == KeyEvent.VK_MINUS) {
                   tfdHusPhone.setEditable(true);
                } else {
                   tfdHusPhone.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHouse();
            }
        });
        tfdHusDate.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers and slashes can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_SLASH ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE) {
                   tfdHusDate.setEditable(true);
                } else {
                   tfdHusDate.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHouse();
            }
        });
        tfdHusBeds.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE) {
                   tfdHusBeds.setEditable(true);
                } else {
                   tfdHusBeds.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHouse();
            }
        });
        tfdHusMax.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE) {
                   tfdHusMax.setEditable(true);
                } else {
                   tfdHusMax.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHouse();
            }
        });
        tfdHusBasePPN.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers and decimal places can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE ||
                        e.getKeyChar() == KeyEvent.VK_PERIOD) {
                   tfdHusBeds.setEditable(true);
                } else {
                   tfdHusBeds.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                allFilledHouse();
            }
        });
        // Buttons
        btnHusCancel.addActionListener((e) -> {
            mainPanel.add(lblConnect);
            cardLayout.show(cardPanel, "employeeCard");
            resetHouse();
        });
        btnHusSubmit.addActionListener((e) -> {
            // Clear selection and disable refresh
            btnRefresh.setEnabled(false);
            btnRefresh.setBackground(disabledBtn);
            lstLodges.clearSelection();
            Thread tHusSubmit = new Thread(() -> {
                try {
                    if (con.isValid(4)) {
                        // Some values need to be parsed/converted
                        inputBasePPN = Double.parseDouble(tfdHusBasePPN.getText());
                        strHasGrg = Boolean.toString(garage.yesOrNo);
                        strHasSecSys = Boolean.toString(security.yesOrNo);
                        strPetsAlwd = Boolean.toString(pets.yesOrNo);
                        // Get query to add a new Lodge
                        String newLodQuery = "INSERT INTO Lodgings VALUES (DEFAULT, 'House',"
                                + " ?, ?, ?, ?, ?, ?, ?)";
                        PreparedStatement newLodPS = con.prepareStatement(newLodQuery);
                        // Fill in question marks
                        newLodPS.setString(1, tfdHusName.getText());
                        newLodPS.setString(2, tfdHusAddr.getText());
                        newLodPS.setString(3, txaHusDesc.getText());
                        newLodPS.setString(4, tfdHusPhone.getText());
                        newLodPS.setString(5, tfdHusBeds.getText());
                        newLodPS.setString(6, tfdHusMax.getText());
                        newLodPS.setDouble(7, inputBasePPN);
                        // Log the affected row(s)
                        int updateCount = newLodPS.executeUpdate();
                        System.out.println(updateCount + " row(s) in Lodgings affected");
                        // Query for the new Lodge's ID
                        String newIdQuery = "SELECT MAX(Lodge_ID) AS HighestID FROM Lodgings";
                        PreparedStatement newIdPS = con.prepareStatement(newIdQuery);
                        ResultSet newIdRS = newIdPS.executeQuery();
                        int newId = 99;
                        if (newIdRS.next()) {
                            newId = newIdRS.getInt(1);
                        }
                        // Create a query adding a new House
                        String newHtlQuery = "INSERT INTO Houses VALUES (DEFAULT, ?,"
                                + " ?, ?, ?, ?)";
                        PreparedStatement newHtlPS = con.prepareStatement(newHtlQuery);
                        // Fill in question marks
                        newHtlPS.setInt(1, newId);
                        newHtlPS.setString(2, tfdHusDate.getText());
                        newHtlPS.setString(3, strHasGrg);
                        newHtlPS.setString(4, strHasSecSys);
                        newHtlPS.setString(5, strPetsAlwd);
                        // Log the affected row(s)
                        updateCount = newHtlPS.executeUpdate();
                        System.out.println(updateCount + " row(s) in Houses affected");
                        // Refresh to fill in the list with the newly added Hotel
                        lstLodges.clearSelection();
                        refresh();
                        lblAddEdit.setVisible(true);
                        lblAddEdit.setText("New house added.");
                        resetHouse();
                    } else {
                        lblEmpCon.setVisible(true);
                        lblAddEdit.setVisible(false);
                        lblError.setText("Failed to add house.");
                        lblError.setVisible(true);
                        resetHouse();
                    }
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.toString());
                    ex.printStackTrace();
                    lblAddEdit.setVisible(false);
                    lblError.setText("Failed to add house.");
                    lblError.setVisible(true);
                    resetHouse();
                }
                btnRefresh.setEnabled(true);
                btnRefresh.setBackground(enabledBtn);
            });
            tHusSubmit.start();
            lblError.setVisible(false);
            lblEmpCon.setVisible(false);
            lblAddEdit.setVisible(true);
            lblAddEdit.setText("Adding new house...");
            mainPanel.add(lblConnect);
            cardLayout.show(cardPanel, "employeeCard");
        });
        // -------------------------------------
        
        // ------ EDIT LODGE FUNCTIONALITY -----
        // Key Listeners
        tfdEditName.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {}
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                if (tfdEditName.getText().length() < 1 ||
                        tfdEditPPN.getText().length() < 1) {
                    btnEditSubmit.setEnabled(false);
                    btnEditSubmit.setBackground(disabledBtn);
                }
                else {
                    btnEditSubmit.setEnabled(true);
                    btnEditSubmit.setBackground(enabledBtn);
                }
            }
        });
        tfdEditPPN.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // Only numbers and decimal places can be entered
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' ||
                        e.getKeyChar() == KeyEvent.VK_BACK_SPACE ||
                        e.getKeyChar() == KeyEvent.VK_DELETE ||
                        e.getKeyChar() == KeyEvent.VK_PERIOD) {
                   tfdEditPPN.setEditable(true);
                } else {
                   tfdEditPPN.setEditable(false);
                }
            }
            public void keyTyped(KeyEvent e) {}
            public void keyReleased(KeyEvent e) {
                if (tfdEditName.getText().length() < 1 ||
                        tfdEditPPN.getText().length() < 1) {
                    btnEditSubmit.setEnabled(false);
                    btnEditSubmit.setBackground(disabledBtn);
                }
                else {
                    btnEditSubmit.setEnabled(true);
                    btnEditSubmit.setBackground(enabledBtn);
                }
            }
        });
        // Buttons
        btnEditCancel.addActionListener((e) -> {
            mainPanel.add(lblConnect);
            cardLayout.show(cardPanel, "employeeCard");
            tfdEditName.setText(lodges.get(selectIndex).name);
            tfdEditPPN.setText(String.format("%.2f", lodges.get(selectIndex).basePricePerNight));
        });
        btnEditSubmit.addActionListener((e) -> {
            // Disable Refresh and Remove
            btnRefresh.setEnabled(false);
            btnRefresh.setBackground(disabledBtn);
            btnRefresh.setEnabled(false);
            btnRefresh.setBackground(disabledRemove);
            Thread tEdit = new Thread(() -> {
                try {
                    if (con.isValid(4)) {
                        // Use new index to avoid incorrect writes
                        int threadIndex = selectIndex;
                        // Store index and set variables
                        inputNam = tfdEditName.getText();
                        inputBasePPN = Double.parseDouble(tfdEditPPN.getText());
                        // If the new inputs still match the lodge's data, don't do anything
                        if (inputNam.equals(lodges.get(threadIndex).name) &&
                                lodges.get(threadIndex).basePricePerNight == inputBasePPN) {
                            lblAddEdit.setVisible(false);
                        } else {
                            // Use ID obtained from list selection
                            // Query for editing the selected lodge
                            String editQuery = "UPDATE Lodgings SET Lodge_Name = \"" + inputNam + "\","
                                    + " BasePPN = " + inputBasePPN
                                    + " WHERE Lodge_ID = " + selectID;
                            PreparedStatement editPS = con.prepareStatement(editQuery);
                            // Log the affected row(s)
                            int updateCount = editPS.executeUpdate(editQuery);
                            System.out.println(updateCount + " row(s) in Lodgings affected");
                            // Refresh to fix the names in the JList
                            lstLodges.clearSelection();
                            refresh();
                            lstLodges.setSelectedIndex(threadIndex);
                            lblAddEdit.setVisible(true);
                            lblAddEdit.setText("Lodge has been edited.");
                        }
                    } else {
                        lblAddEdit.setVisible(false);
                        lblError.setText("Failed to edit lodge.");
                        lblError.setVisible(true);
                        tfdEditName.setText(lodges.get(selectIndex).name);
                        tfdEditPPN.setText(String.format("%.2f", lodges.get(selectIndex).basePricePerNight));
                        lblEmpCon.setVisible(true);
                    }
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.toString());
                    ex.printStackTrace();
                    lblAddEdit.setVisible(false);
                    lblError.setText("Failed to edit lodge.");
                    lblError.setVisible(true);
                    tfdEditName.setText(lodges.get(selectIndex).name);
                    tfdEditPPN.setText(String.format("%.2f", lodges.get(selectIndex).basePricePerNight));
                }
                btnRefresh.setEnabled(true);
                btnRefresh.setBackground(enabledBtn);
                btnRemove.setEnabled(true);
                btnRemove.setBackground(enabledRemove);
            });
            tEdit.start();
            lblError.setVisible(false);
            lblEmpCon.setVisible(false);
            lblAddEdit.setVisible(true);
            lblAddEdit.setText("Editing lodge data...");
            mainPanel.add(lblConnect);
            cardLayout.show(cardPanel, "employeeCard");
        });
        // -------------------------------------
    }
    
    // Custom method puts label onto the Employee card
    //  if coming from the Login card
    void connectLabel() {
        mainPanel.add(lblConnect);
    }
    
    // Method checking for all Hotel items filled in
    public void allFilledHotel() {
        if (tfdHtlName.getText().length() < 1 ||
                tfdHtlAddr.getText().length() < 1 ||
                txaHtlDesc.getText().length() < 1 ||
                tfdHtlPhone.getText().length() < 1 ||
                tfdHtlBeds.getText().length() < 1 ||
                tfdHtlMax.getText().length() < 1 ||
                tfdHtlVacs.getText().length() < 1 ||
                tfdHtlBasePPN.getText().length() < 1 ||
                tfdHtlPark.getText().length() < 1 ||
                tfdHtlValet.getText().length() < 1) {
            btnHtlSubmit.setEnabled(false);
            btnHtlSubmit.setBackground(disabledBtn);
        }
        else {
            btnHtlSubmit.setEnabled(true);
            btnHtlSubmit.setBackground(enabledBtn);
        }
    }
    
    // Method resetting Hotel values
    public void resetHotel() {
        btnHtlSubmit.setEnabled(false);
        btnHtlSubmit.setBackground(disabledBtn);
        tfdHtlName.setText("");
        tfdHtlAddr.setText("");
        txaHtlDesc.setText("");
        tfdHtlPhone.setText("");
        tfdHtlBeds.setText("");
        tfdHtlMax.setText("");
        tfdHtlVacs.setText("");
        tfdHtlBasePPN.setText("");
        tfdHtlPark.setText("");
        tfdHtlValet.setText("");
        pool.radNo.setSelected(true);
        pool.yesOrNo = false;
        workout.radNo.setSelected(true);
        workout.yesOrNo = false;
        kitchen.radNo.setSelected(true);
        kitchen.yesOrNo = false;
        breakfast.radNo.setSelected(true);
        breakfast.yesOrNo = false;
    }
    
    // Method checking for all House items filled in
    public void allFilledHouse() {
        if (tfdHusName.getText().length() < 1 ||
                tfdHusAddr.getText().length() < 1 ||
                txaHusDesc.getText().length() < 1 ||
                tfdHusPhone.getText().length() < 1 ||
                tfdHusDate.getText().length() < 1 ||
                tfdHusBeds.getText().length() < 1 ||
                tfdHusMax.getText().length() < 1 ||
                tfdHusBasePPN.getText().length() < 1) {
            btnHusSubmit.setEnabled(false);
            btnHusSubmit.setBackground(disabledBtn);
        }
        else {
            btnHusSubmit.setEnabled(true);
            btnHusSubmit.setBackground(enabledBtn);
        }
    }
    
    // Method resetting House values
    public void resetHouse() {
        btnHusSubmit.setEnabled(false);
        btnHusSubmit.setBackground(disabledBtn);
        tfdHusName.setText("");
        tfdHusAddr.setText("");
        txaHusDesc.setText("");
        tfdHusPhone.setText("");
        tfdHusDate.setText("");
        tfdHusBeds.setText("");
        tfdHusMax.setText("");
        tfdHusBasePPN.setText("");
        garage.radNo.setSelected(true);
        garage.yesOrNo = false;
        security.radNo.setSelected(true);
        security.yesOrNo = false;
        pets.radNo.setSelected(true);
        pets.yesOrNo = false;
    }
    
    // Custom method checks for a valid date and toggles the Reports button if valid
    public void validateDates() {
        // Check the valid condition, then change button and label if necessary
        if (startDate.compareTo(endDate) >= 0) {
            btnReports.setEnabled(false);
            btnReports.setBackground(disabledBtn);
            // Change label style
            lblReports.setForeground(Color.red);
            lblReports.setText("<html>Starting date must<br>be before ending date</html>");
            lblReports.setSize(lblReports.getPreferredSize().width, lblReports.getPreferredSize().height);
        } else {
            btnReports.setEnabled(true);
            btnReports.setBackground(enabledBtn);
            // Change label style
            lblReports.setForeground(new Color(0, 163, 136));
            lblReports.setText("<html>Report shows total spending<br>between selected dates</html>");
            lblReports.setSize(lblReports.getPreferredSize().width, lblReports.getPreferredSize().height);
        }
    }
    
    void refresh() {
        try {
            if (con.isValid(4)) {
                // Only store image lists after loading images and lodges
                if (lodges.isEmpty() == false && firstImgLoad) {
                    lodgeImgStorage.clear();
                    for (int i = 0; i < lodges.size(); i++) {
                        Lodging imgLodge = new Hotel();
                        lodgeImgStorage.add(imgLodge);
                        // Skip in case a lodge has no images
                        lodgeImgStorage.get(i).imgsLoaded = lodges.get(i).imgsLoaded;
                        if (lodges.get(i).lodgeImages.isEmpty() == false) {
                            lodgeImgStorage.get(i).lodgeImages = lodges.get(i).lodgeImages;
                        }
                    }
                }
                lodges.clear();
                lodgeIDs.clear();
                int indexToAdd = 0;
                // Query for the ID of all lodges for later use
                String allIDsQuery = "SELECT Lodge_ID FROM Lodgings";
                PreparedStatement idsPS = con.prepareStatement(allIDsQuery);
                ResultSet idsRS = idsPS.executeQuery();
                while (idsRS.next()) {
                    Lodging emptyLodge = new Hotel();
                    lodges.add(emptyLodge);
                    lodgeIDs.add(idsRS.getInt(1));
                }
                // Prepare a query for Hotel values
                String hotelQuery = "SELECT l.Lodge_ID, Lodge_Name, Lodge_Address, Lodge_Description, Lodge_PhoneNumber, NumOfBedrooms, MaxOccupants, BasePPN,"
                    + " Vacancies, ParkingFee, ValetParking, HasPool, HasWorkoutRoom, HasMiniKitchen, HasFreeBreakfast"
                    + " FROM Lodgings l JOIN Hotels h"
                    + " ON l.Lodge_ID = h.Lodge_ID"
                    + " WHERE Lodge_Type = 'Hotel'";
                PreparedStatement htlPS = con.prepareStatement(hotelQuery);
                ResultSet htlRS = htlPS.executeQuery();
                while (htlRS.next()) {
                    int indexID = htlRS.getInt(1);
                    String readName = htlRS.getString(2);
                    String readAddr = htlRS.getString(3);
                    String readDesc = htlRS.getString(4);
                    String readPhone = htlRS.getString(5);
                    int readNumBeds = Integer.parseInt(htlRS.getString(6));
                    int readMaxOcc = Integer.parseInt(htlRS.getString(7));
                    double readPPN = htlRS.getDouble(8);
                    // Hotel-specific variables
                    int readVacs = Integer.parseInt(htlRS.getString(9));
                    double readPark = Double.parseDouble(htlRS.getString(10));
                    double readValet = Double.parseDouble(htlRS.getString(11));
                    boolean readPool = Boolean.parseBoolean(htlRS.getString(12));
                    boolean readWorkout = Boolean.parseBoolean(htlRS.getString(13));
                    boolean readMKitch = Boolean.parseBoolean(htlRS.getString(14));
                    boolean readBrkfst = Boolean.parseBoolean(htlRS.getString(15));
                    // Use values to create a Hotel object
                    Lodging readHotel = new Hotel(readName, readAddr, readDesc, readPhone,
                            readNumBeds, readMaxOcc, readPPN, readVacs, readPark, readValet,
                            readPool, readWorkout, readMKitch, readBrkfst);
                    for (int i = 0; i < lodgeIDs.size(); i++) {
                        if (indexID == lodgeIDs.get(i)) {
                            indexToAdd = i;
                        }
                    }
                    // Fill list by replacing empty lodges in the correct order
                    lodges.set(indexToAdd, readHotel);
                }
                // Prepare another query for House values
                String houseQuery = "SELECT l.Lodge_ID, Lodge_Name, Lodge_Address, Lodge_Description, Lodge_PhoneNumber, NumOfBedrooms, MaxOccupants, BasePPN,"
                    + " House_Date, HasGarage, HasSecuritySystem, PetsAllowed"
                    + " FROM Lodgings l JOIN Houses h"
                    + " ON l.Lodge_ID = h.Lodge_ID"
                    + " WHERE Lodge_Type = 'House'";
                PreparedStatement husPS = con.prepareStatement(houseQuery);
                ResultSet husRS = husPS.executeQuery();
                while (husRS.next()) {
                    int indexID = husRS.getInt(1);
                    String readName = husRS.getString(2);
                    String readAddr = husRS.getString(3);
                    String readDesc = husRS.getString(4);
                    String readPhone = husRS.getString(5);
                    int readNumBeds = Integer.parseInt(husRS.getString(6));
                    int readMaxOcc = Integer.parseInt(husRS.getString(7));
                    double readPPN = husRS.getDouble(8);
                    // Hotel-specific variables
                    String readDate = husRS.getString(9);
                    boolean readGarage = Boolean.parseBoolean(husRS.getString(10));
                    boolean readSecure = Boolean.parseBoolean(husRS.getString(11));
                    boolean readPets = Boolean.parseBoolean(husRS.getString(12));
                    // Use values to create a House object
                    Lodging readHouse = new House(readName, readAddr, readDesc,
                            readPhone, readNumBeds, readMaxOcc, readPPN,
                            readDate, readGarage, readSecure, readPets);
                    for (int i = 0; i < lodgeIDs.size(); i++) {
                        if (indexID == lodgeIDs.get(i)) {
                            indexToAdd = i;
                        }
                    }
                    // Fill list by replacing empty lodges in the correct order
                    lodges.set(indexToAdd, readHouse);
                }
                // Only one lodge gets added prior to refreshing.
                //  Add one empty lodge to match if needed
                if (lodges.size() > lodgeImgStorage.size()) {
                    Lodging emptyLodge = new Hotel();
                    lodgeImgStorage.add(emptyLodge);
                }
                // Only refill lodge images after images have been loaded in once
                if (firstImgLoad) {
                    for (int i = 0; i < lodges.size(); i++) {
                        lodges.get(i).imgsLoaded = lodgeImgStorage.get(i).imgsLoaded;
                        // Skip in case a lodge has no images
                        if (lodgeImgStorage.get(i).lodgeImages.isEmpty() == false) {
                            lodges.get(i).lodgeImages = lodgeImgStorage.get(i).lodgeImages;
                        }
                    }
                }
                // Loop lodge list to fill lodgeNames array and JList
                for (int i = 0; i < lodges.size(); i++) {
                    lodgeNames.add(lodges.get(i).name);
                }
                lstLodges.setListData(lodgeNames.toArray());
                lodgeNames.clear();
            } else {
                lblEmpCon.setVisible(true);
                lblAddEdit.setVisible(false);
            }
        } catch (Exception ex) {
            System.out.println("Error: " + ex.toString());
            ex.printStackTrace();
            // In case of an error, load data from text files
            load();
            for (int i = 0; i < lodges.size(); i++) {
                lodgeNames.add(lodges.get(i).name);
            }
            lstLodges.setListData(lodgeNames.toArray());
            lodgeNames.clear();
        }
    }
    
    void enter()
    {
//        if (previous == managerView)
//        {
//            System.out.println("\n1. Add Lodge"
//            + "\n2. Edit Lodge"
//            + "\n3. Remove Lodge"
//            + "\n4. List Lodges"
//            + "\n5. Log out"
//            + "\n6. Manager View"
//            + "\n\nSelect from the menu:");
//        }
//        else
//        {
//            System.out.println("\n1. Add Lodge"
//            + "\n2. Edit Lodge"
//            + "\n3. Remove Lodge"
//            + "\n4. List Lodges"
//            + "\n5. Log Out"
//            + "\n\nSelect from the menu:");
//        }
    }
    
    // Any time the file is read, repopulate the array list
    void load()
    {
        try {
            // Create FileReader
            FileReader lodgeReader = new FileReader("lodgings.txt");
            BufferedReader lodgeBuff = new BufferedReader(lodgeReader);
            String currentLine;
            // In the text file, the first line before each lodging starts with House or Hotel.
            //  The if/else statement determines how each following line should be read based
            //  on the type of lodging specified from this first line.
            while ((currentLine = lodgeBuff.readLine()) != null) {
                String hotelOrHouse = currentLine;
                if (hotelOrHouse.equals("Hotel")) {
                    currentLine = lodgeBuff.readLine();
                    String readName = currentLine;
                    currentLine = lodgeBuff.readLine();
                    String readAddr = currentLine;
                    currentLine = lodgeBuff.readLine();
                    String readDesc = currentLine;
                    currentLine = lodgeBuff.readLine();
                    String readPhone = currentLine;
                    currentLine = lodgeBuff.readLine();
                    int readNumBeds = Integer.parseInt(currentLine);
                    currentLine = lodgeBuff.readLine();
                    int readMaxOcc = Integer.parseInt(currentLine);
                    currentLine = lodgeBuff.readLine();
                    double readPPN = Double.parseDouble(currentLine);
                    // Hotel-specific variables
                    currentLine = lodgeBuff.readLine();
                    int readVacs = Integer.parseInt(currentLine);
                    currentLine = lodgeBuff.readLine();
                    double readPark = Double.parseDouble(currentLine);
                    currentLine = lodgeBuff.readLine();
                    double readValet = Double.parseDouble(currentLine);
                    currentLine = lodgeBuff.readLine();
                    boolean readPool = Boolean.parseBoolean(currentLine);
                    currentLine = lodgeBuff.readLine();
                    boolean readWorkout = Boolean.parseBoolean(currentLine);
                    currentLine = lodgeBuff.readLine();
                    boolean readMKitch = Boolean.parseBoolean(currentLine);
                    currentLine = lodgeBuff.readLine();
                    boolean readBrkfst = Boolean.parseBoolean(currentLine);
                    // Use values to create a Hotel object
                    Lodging readHotel = new Hotel(readName, readAddr, readDesc, readPhone,
                            readNumBeds, readMaxOcc, readPPN, readVacs, readPark, readValet,
                            readPool, readWorkout, readMKitch, readBrkfst);
                    lodges.add(readHotel);
                } else if (hotelOrHouse.equals("House")) {
                    currentLine = lodgeBuff.readLine();
                    String readName = currentLine;
                    currentLine = lodgeBuff.readLine();
                    String readAddr = currentLine;
                    currentLine = lodgeBuff.readLine();
                    String readDesc = currentLine;
                    currentLine = lodgeBuff.readLine();
                    String readPhone = currentLine;
                    currentLine = lodgeBuff.readLine();
                    int readNumBeds = Integer.parseInt(currentLine);
                    currentLine = lodgeBuff.readLine();
                    int readMaxOcc = Integer.parseInt(currentLine);
                    currentLine = lodgeBuff.readLine();
                    double readPPN = Double.parseDouble(currentLine);
                    // House-specific variables
                    currentLine = lodgeBuff.readLine();
                    String readDate = currentLine;
                    currentLine = lodgeBuff.readLine();
                    boolean readGarage = Boolean.parseBoolean(currentLine);
                    currentLine = lodgeBuff.readLine();
                    boolean readSecure = Boolean.parseBoolean(currentLine);
                    currentLine = lodgeBuff.readLine();
                    boolean readPets = Boolean.parseBoolean(currentLine);
                    // Use values to create a House object
                    Lodging readHouse = new House(readName, readAddr, readDesc,
                            readPhone, readNumBeds, readMaxOcc, readPPN,
                            readDate, readGarage, readSecure, readPets);
                    lodges.add(readHouse);
                }
            }
        } catch (IOException ex) {
            System.out.println("Error loading file.");
        }
    }
    
    // Any time the file is saved, clear the array list
    void save()
    {
        try {
            // Create Writers
            FileWriter lodgeSave = new FileWriter("lodgings.txt");
            BufferedWriter buffSave = new BufferedWriter(lodgeSave);
            // Print each Lodgings' values to the file. Polymorphic methods guarantee
            //  the correct values are pulled for Hotel or House objects.
            for (int i = 0; i < lodges.size(); i++) {
                buffSave.append(lodges.get(i).returnType() + "\r\n");
                buffSave.append(lodges.get(i).name + "\r\n");
                buffSave.append(lodges.get(i).address + "\r\n");
                buffSave.append(lodges.get(i).description + "\r\n");
                buffSave.append(lodges.get(i).phoneNumber + "\r\n");
                buffSave.append(lodges.get(i).numberOfBedrooms + "\r\n");
                buffSave.append(lodges.get(i).maxOccupants + "\r\n");
                buffSave.append(lodges.get(i).basePricePerNight + "\r\n");
                buffSave.append(lodges.get(i).returnSubVars());
                // If it is NOT the final object on the list, move to the next line
                if (i < lodges.size() - 1) {
                    buffSave.append("\r\n");
                }
            }
            // Save file
            buffSave.close();
        } catch (IOException ex) {
            System.out.println("Error saving file.");
        }
        // Even when failing, clear the list so the next load is not inaccurate
        lodges.clear();
    }
    
    void update()
    {
//        while (true)
//        {
//            breakLoop = false;
//            Scanner s = new Scanner(System.in);
//            String input = s.nextLine();
//            
//            // Switch statement determines necessary actions to take
//            switch (input)
//            {
//                case "1":
//                    // Add a new lodging
//                    System.out.println("1. Add Hotel"
//                    + "\n2. Add House"
//                    + "\n\nSelect from the menu:");
//                    String input2 = s.nextLine();
//                    
//                    switch (input2)
//                    {
//                        // ADDING A NEW HOTEL
//                        case "1":
//                            // Input Strings: name, address, description, phoneNumber
//                            System.out.println("Enter Hotel name:");
//                            inputNam = s.nextLine();
//                            System.out.println("Enter Hotel address:");
//                            inputAddr = s.nextLine();
//                            System.out.println("Enter Hotel description:");
//                            inputDesc = s.nextLine();
//                            System.out.println("Enter Hotel phone number:");
//                            inputPhoneNum = s.nextLine();
//                            // Input ints: numberOfBedrooms, maxOccupants
//                            System.out.println("Enter number of bedrooms:");
//                            inputNumOfBeds = Integer.parseInt(s.nextLine());
//                            System.out.println("Enter max occupants:");
//                            inputMaxOcc = Integer.parseInt(s.nextLine());
//                            // Input double: basePricePerNight
//                            System.out.println("Enter the base price per night:");
//                            inputBasePPN = Double.parseDouble(s.nextLine());
//                            // Input int: vacancies
//                            System.out.println("Enter vacancies:");
//                            inputVacanc = Integer.parseInt(s.nextLine());
//                            // Input doubles: parkingFee, valetParking
//                            System.out.println("Enter the cost for parking:");
//                            inputParkFee = Double.parseDouble(s.nextLine());
//                            System.out.println("Enter the cost for valet parking:");
//                            inputVPark = Double.parseDouble(s.nextLine());
//                            // Input boolean: hasAPool
//                            while (!breakLoop)
//                            {
//                                System.out.println("Does the Hotel have a pool?"
//                                + "\n1. Yes"
//                                + "\n2. No"
//                                + "\n\nSelect from the menu:");
//                                String choice = s.nextLine();
//                                switch (choice)
//                                {
//                                    case "1":
//                                        inputHasPool = true;
//                                        breakLoop = true;
//                                        break;
//                                    case "2":
//                                        inputHasPool = false;
//                                        breakLoop = true;
//                                        break;
//                                    default:
//                                        System.out.println("\n*** Invalid input.");
//                                        break;
//                                }
//                            }
//                            breakLoop = false;
//                            // Input boolean: hasWorkoutRoom
//                            while (!breakLoop)
//                            {
//                                System.out.println("Does the Hotel have a workout room?"
//                                + "\n1. Yes"
//                                + "\n2. No"
//                                + "\n\nSelect from the menu:");
//                                String choice = s.nextLine();
//                                switch (choice)
//                                {
//                                    case "1":
//                                        inputHasWrktRm = true;
//                                        breakLoop = true;
//                                        break;
//                                    case "2":
//                                        inputHasWrktRm = false;
//                                        breakLoop = true;
//                                        break;
//                                    default:
//                                        System.out.println("\n*** Invalid input.");
//                                        break;
//                                }
//                            }
//                            breakLoop = false;
//                            // Input boolean: hasMiniKitchen
//                            while (!breakLoop)
//                            {
//                                System.out.println("Does the Hotel have mini kitchens?"
//                                + "\n1. Yes"
//                                + "\n2. No"
//                                + "\n\nSelect from the menu:");
//                                String choice = s.nextLine();
//                                switch (choice)
//                                {
//                                    case "1":
//                                        inputHasMKitch = true;
//                                        breakLoop = true;
//                                        break;
//                                    case "2":
//                                        inputHasMKitch = false;
//                                        breakLoop = true;
//                                        break;
//                                    default:
//                                        System.out.println("\n*** Invalid input.");
//                                        break;
//                                }
//                            }
//                            breakLoop = false;
//                            // Input boolean: hasFreeBreakfast
//                            while (!breakLoop)
//                            {
//                                System.out.println("Does the Hotel offer free breakfast?"
//                                + "\n1. Yes"
//                                + "\n2. No"
//                                + "\n\nSelect from the menu:");
//                                String choice = s.nextLine();
//                                switch (choice)
//                                {
//                                    case "1":
//                                        inputHasFrBrkfst = true;
//                                        breakLoop = true;
//                                        break;
//                                    case "2":
//                                        inputHasFrBrkfst = false;
//                                        breakLoop = true;
//                                        break;
//                                    default:
//                                        System.out.println("\n*** Invalid input.");
//                                        break;
//                                }
//                            }
//                            breakLoop = false;
//                            
//                            // Create a new hotel with all the inputs and add it to the list
//                            load();
//                            Lodging newHotel;
//                            newHotel = new Hotel(inputNam, inputAddr, inputDesc, inputPhoneNum,
//                                    inputNumOfBeds, inputMaxOcc, inputBasePPN, inputVacanc,
//                                    inputParkFee, inputVPark, inputHasPool, inputHasWrktRm,
//                                    inputHasMKitch, inputHasFrBrkfst);
//                            lodges.add(newHotel);
//                            save();
//                            System.out.println("New Hotel added to list.");
//                            break;
//                        // ADDING A NEW HOUSE
//                        case "2":
//                            // Input Strings: name, address, description, phoneNumber
//                            System.out.println("Enter House name:");
//                            inputNam = s.nextLine();
//                            System.out.println("Enter House address:");
//                            inputAddr = s.nextLine();
//                            System.out.println("Enter House description:");
//                            inputDesc = s.nextLine();
//                            System.out.println("Enter House phone number:");
//                            inputPhoneNum = s.nextLine();
//                            // Input ints: numberOfBedrooms, maxOccupants
//                            System.out.println("Enter number of bedrooms:");
//                            inputNumOfBeds = Integer.parseInt(s.nextLine());
//                            System.out.println("Enter max occupants:");
//                            inputMaxOcc = Integer.parseInt(s.nextLine());
//                            // Input double: basePricePerNight
//                            System.out.println("Enter the base price per night:");
//                            inputBasePPN = Double.parseDouble(s.nextLine());
//                            // Input String: date
//                            System.out.println("Enter date House first opened (MM/DD/YYYY):");
//                            inputDat = s.nextLine();
//                            // Input boolean: hasAGarage
//                            while (!breakLoop)
//                            {
//                                System.out.println("Does the House have a garage?"
//                                + "\n1. Yes"
//                                + "\n2. No"
//                                + "\n\nSelect from the menu:");
//                                String choice = s.nextLine();
//                                switch (choice)
//                                {
//                                    case "1":
//                                        inputHasGrg = true;
//                                        breakLoop = true;
//                                        break;
//                                    case "2":
//                                        inputHasGrg = false;
//                                        breakLoop = true;
//                                        break;
//                                    default:
//                                        System.out.println("\n*** Invalid input.");
//                                        break;
//                                }
//                            }
//                            breakLoop = false;
//                            // Input boolean: hasSecuritySystem
//                            while (!breakLoop)
//                            {
//                                System.out.println("Does the House have a security system?"
//                                + "\n1. Yes"
//                                + "\n2. No"
//                                + "\n\nSelect from the menu:");
//                                String choice = s.nextLine();
//                                switch (choice)
//                                {
//                                    case "1":
//                                        inputHasSecSys = true;
//                                        breakLoop = true;
//                                        break;
//                                    case "2":
//                                        inputHasSecSys = false;
//                                        breakLoop = true;
//                                        break;
//                                    default:
//                                        System.out.println("\n*** Invalid input.");
//                                        break;
//                                }
//                            }
//                            breakLoop = false;
//                            // Input boolean: petsAllowed
//                            while (!breakLoop)
//                            {
//                                System.out.println("Are pets allowed?"
//                                + "\n1. Yes"
//                                + "\n2. No"
//                                + "\n\nSelect from the menu:");
//                                String choice = s.nextLine();
//                                switch (choice)
//                                {
//                                    case "1":
//                                        inputPetsAlwd = true;
//                                        breakLoop = true;
//                                        break;
//                                    case "2":
//                                        inputPetsAlwd = false;
//                                        breakLoop = true;
//                                        break;
//                                    default:
//                                        System.out.println("\n*** Invalid input.");
//                                        break;
//                                }
//                            }
//                            breakLoop = false;
//                            
//                            // Create a new house with all the inputs and add it to the list
//                            load();
//                            Lodging newHouse;
//                            newHouse = new House(inputNam, inputAddr, inputDesc, inputPhoneNum,
//                                    inputNumOfBeds, inputMaxOcc, inputBasePPN, inputDat,
//                                    inputHasGrg, inputHasSecSys, inputPetsAlwd);
//                            lodges.add(newHouse);
//                            save();
//                            System.out.println("New House added to list.");
//                            break;
//                        default:
//                            System.out.println("\n*** Invalid input. Addition canceled.");
//                            break;
//                    }
//                    return;
//                case "2":
//                    // Edit Lodge. Loop to print each lodging to the console
//                    load();
//                    for (int i = 0; i < lodges.size(); ++i)
//                    {
//                        System.out.println((i + 1) + ". " + lodges.get(i).name);
//                    }
//                    System.out.println("\nSelect which lodge to edit:");
//                    int edit = Integer.parseInt(s.nextLine());
//                    edit -= 1;
//                    
//                    // Check if input is in range
//                    if ((edit < lodges.size()) && edit >= 0)
//                    {
//                        // Only the name and base price per night can be changed.
//                        System.out.println("\nEditing options:"
//                                + "\n1. Name"
//                                + "\n2. Base Price Per Night"
//                                + "\n\nSelect information to edit:");
//                        String editChoice = s.nextLine();
//                        
//                        // switch statement to change information
//                        switch (editChoice)
//                        {
//                            case "1":
//                                System.out.println("Enter new name for " + lodges.get(edit).name + ":");
//                                inputNam = s.nextLine();
//                                lodges.get(edit).name = inputNam;
//                                System.out.println("Changed lodge name to " + lodges.get(edit).name + ".");
//                                save();
//                                break;
//                            case "2":
//                                System.out.println("Enter new base price per night for " + lodges.get(edit).name + ":");
//                                inputBasePPN = Double.parseDouble(s.nextLine());
//                                lodges.get(edit).basePricePerNight = inputBasePPN;
//                                System.out.println("Succesfully changed lodge pricing to $" + String.format("%.2f", lodges.get(edit).basePricePerNight));
//                                save();
//                                break;
//                            default:
//                                System.out.println("\n*** Invalid input. Edit canceled");
//                                // No changes. Clear without saving
//                                lodges.clear();
//                                break;
//                        }
//                        
//                    }
//                    else
//                    {
//                        System.out.println("\n*** Invalid input. Edit canceled");
//                        // No changes. Clear without saving
//                        lodges.clear();
//                    }
//                    return;
//                case "3":
//                    // Removing Lodges. Loop to print each lodging to the console
//                    load();
//                    for (int i = 0; i < lodges.size(); ++i)
//                    {
//                        System.out.println((i + 1) + ". " + lodges.get(i).name);
//                    }
//                    System.out.println("\nSelect which lodge to remove:");
//                    int remove = Integer.parseInt(s.nextLine());
//                    
//                    if ((remove <= lodges.size()) && remove > 0)
//                    {
//                        System.out.println(lodges.get(remove - 1).name
//                                    + " has been removed.");
//                        lodges.remove(remove - 1);
//                        save();
//                    }
//                    else
//                    {
//                        System.out.println("\n*** Invalid input. Removal canceled");
//                        // No changes. Clear without saving
//                        lodges.clear();
//                    }
//                    return;
//                case "4":
//                    // Listing lodges
//                    load();
//                    System.out.println("List of lodges:");
//                    for (int i = 0; i < lodges.size(); ++i)
//                    {
//                        System.out.println((i + 1) + ". " + lodges.get(i).name);
//                    }
//                    // No changes. Clear without saving
//                    lodges.clear();
//                    return;
//                case "5":
//                    // Log out
//                    previous = current;
//                    current = login;
//                    System.out.println("Logged out.");
//                    return;
//                case "6":
//                    // Manager View (Only works if the employee is a manager)
//                    if (previous == managerView)
//                    {
//                        previous = current;
//                        current = managerView;
//                    }
//                    else
//                    {
//                        System.out.println("*** Invalid input.");
//                    }
//                    return;
//                default:
//                    System.out.println("*** Invalid input.");
//                    System.out.println("Select from the menu:");
//            }
//        }
    }
}
