package danielriveram6;

import java.awt.*;
import javax.swing.*;

public class JButtonTravel extends JButton {
    // Constructor creates a button with text and proper color scheme
    JButtonTravel(String text, boolean makeOrange) {
        setText(text);
        setFont(new Font("Calibri", Font.BOLD, 32));
        
        if (!makeOrange) {
            setBackground(new Color(190, 235, 159));
            setForeground(new Color(0, 163, 136));
            setBorder(BorderFactory.createLineBorder(new Color(0, 163, 136), 2, true));
        } else {
            setBackground(new Color(255, 255, 157));
            setForeground(new Color(255, 97, 56));
            setBorder(BorderFactory.createLineBorder(new Color(255, 97, 56), 2, true));
        }
    }
    // Constructor creates a button with text, size, font, and proper color scheme
    JButtonTravel(String text, int width, int height, boolean makeOrange) {
        setText(text);
        setFont(new Font("Calibri", Font.BOLD, 32));
        setSize(width, height);
        
        if (!makeOrange) {
            setBackground(new Color(190, 235, 159));
            setForeground(new Color(0, 163, 136));
            setBorder(BorderFactory.createLineBorder(new Color(0, 163, 136), 2, true));
        } else {
            setBackground(new Color(255, 255, 157));
            setForeground(new Color(255, 97, 56));
            setBorder(BorderFactory.createLineBorder(new Color(255, 97, 56), 2, true));
        }
    }
}
