package danielriveram6;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

// JLabel extension makes images in JPanelImages clickable
public class JLabelImage extends JLabel {
    int selection;
    int passIndex;
    
    public JLabelImage(Icon image, int select, int index) {
        selection = select;
        passIndex = index;
        setIcon(image);
        
        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JFrameImages photoFrame = new JFrameImages(selection, passIndex);
                photoFrame.setVisible(true);
            }
        });
    }
}
