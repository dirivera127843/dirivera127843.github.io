package danielriveram6;

import java.awt.*;
import javax.swing.*;

// JPasswordField extension giving the proper color and font
public class JPasswordFieldLogin extends JPasswordField {
    public JPasswordFieldLogin(int columns) {
        setBackground(new Color(225, 255, 204));
        setForeground(new Color(0, 163, 136));
        setBorder(BorderFactory.createLineBorder(new Color(121, 189, 143), 2, false));
        setFont(new Font("Calibri", Font.PLAIN, 24));
        setColumns(columns);
    }
}
