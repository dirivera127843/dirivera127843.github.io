package danielriveram6;

import java.awt.*;
import javax.swing.*;

// JList extension for lodges in Employee View and Customer View
public class JListLodges extends JList {
    public JListLodges() {
        setBackground(new Color(113, 154, 193));
        setForeground(new Color(0, 77, 116));
        setBorder(BorderFactory.createLineBorder(new Color(0, 109, 163), 2, false));
        setFont(new Font("Calibri", Font.PLAIN, 24));
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setLayoutOrientation(JList.VERTICAL);
    }
}
