package danielriveram6;

import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.*;

// JTextField extension giving the proper color and font
public class JTextFieldTravel extends JTextField {
    public JTextFieldTravel(int columns) {
        setBackground(new Color(225, 255, 204));
        setForeground(new Color(0, 163, 136));
        setBorder(BorderFactory.createLineBorder(new Color(121, 189, 143), 2, false));
        setFont(new Font("Calibri", Font.PLAIN, 24));
        setColumns(columns);
        
        // This FocusListener is for the input fields in Add Hotel and Add House
        addFocusListener(new FocusListener() {
           public void focusGained(FocusEvent e) {} 
           public void focusLost(FocusEvent e) {
               setEditable(true);
           }
        });
    }
}
