package danielriveram6;

// State class determines which menu to pull up
import java.awt.*;
import javax.swing.*;
import java.sql.*;

public abstract class State {
    static State login, customerView, employeeView, managerView,
            current, previous, exit;
    
    // Check and method to determine customer login or guest login between classes
    static int didLogin = 0;
    void checkLogin() {}
    
    // Method for loading and reloading database data
    void refresh() {}
    
    // Boolean flag for loading images for the first time
    static boolean firstImgLoad = false;
    
    // Only one frame for all states
    static JFrame tbtFrame = new JFrame("Tranquil Buzz Travels");
    static CardLayout cardLayout = new CardLayout();
    static JPanel cardPanel = new JPanel(cardLayout);
    JPanel mainPanel = new JPanel();
    
    // Label checking the connection
    static JLabelGen lblConnect = new JLabelGen("Database: connected");
    // Method for displaying the connection label between classes
    void connectLabel() {}
    
    // Connection used throughout the code
    static Connection con = null;
    static String mySQLURL = "jdbc:mysql://13.58.236.216:3306/driverafa24";
    static String sqlConUser = "driverafa24";
    static String sqlConPass = "cpt_Tstc1";
    
    void enter() {}
    void update() {}
    void load() {}
    void save() {}
}
