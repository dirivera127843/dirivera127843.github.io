package danielriveram6;

public class House extends Lodging {
    // Variable declarations
    String date;
    boolean hasAGarage, hasSecuritySystem, petsAllowed;
    
    // Default constructor
    public House()
    {
        date = "";
        hasAGarage = false;
        hasSecuritySystem = false;
        petsAllowed = false;
    }
    // Constructor with definitions
    public House(String nam, String addr, String desc, String phoneNum,
            int numOfBeds, int maxOcc, double basePPN, String dat,
            boolean hasGrg, boolean hasSecSys, boolean petsAlwd)
    {
        super(nam, addr, desc, phoneNum, numOfBeds, maxOcc, basePPN);
        this.date = dat;
        this.hasAGarage = hasGrg;
        this.hasSecuritySystem = hasSecSys;
        this.petsAllowed = petsAlwd;
    }
    
    // New .toString() override
    public String toString()
    {
        String returnString = super.toString();
        returnString += "\nDate opened for lodging: " + this.date
                    + "\nHas a garage: " + this.hasAGarage
                    + "\nHas security system: " + this.hasSecuritySystem
                    + "\nPets allowed: " + this.petsAllowed;
        return returnString;
    }
    
    // Custom method adds proper values to a JLabel
    public String toJLabelString() {
        String returnString = super.toJLabelString();
        returnString += "<br/>Date opened for lodging: " + this.date
                    + "<br/>Has a garage: " + this.hasAGarage
                    + "<br/>Has security system: " + this.hasSecuritySystem
                    + "<br/>Pets allowed: " + this.petsAllowed
                    + "</html>";
        return returnString;
    }
    
    public String returnType() {
        return "House";
    }
    
    public String returnSubVars() {
        return date + "\r\n"
                + hasAGarage + "\r\n"
                + hasSecuritySystem + "\r\n"
                + petsAllowed;
    }
}
