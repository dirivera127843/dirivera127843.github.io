package danielriveram6;

public class Order {
    // Variable declarations
    String lodgeName;
    double basePricePerNight, total;
    int numberOfNights;
    
    // Default constructor
    public Order()
    {
        lodgeName = "";
        basePricePerNight = 0.0;
        numberOfNights = 0;
        total = 0.0;
    }
    // Constructor with definitions
    public Order(String lodNam, double basePPN, int numOfNights, double ttl)
    {
        this.lodgeName = lodNam;
        this.basePricePerNight = basePPN;
        this.numberOfNights = numOfNights;
        this.total = ttl;
    }
    
    // New .toString() override
    public String toString()
    {
        return "Lodge name: " + this.lodgeName
                + "\nBase price per night: $" + String.format("%.2f", this.basePricePerNight)
                + "\nNights staying: " + this.numberOfNights
                + "\nTotal: $" + String.format("%.2f", this.total);
    }
}
