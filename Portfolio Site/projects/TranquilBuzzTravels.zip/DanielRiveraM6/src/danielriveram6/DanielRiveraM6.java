package danielriveram6;

// MODULE #6

// Author: Daniel Rivera
// Date: 12/6/2024

// Color palette link:
//https://colordesigner.io/color-palette-builder?mode=lch#FF6138-FFFF9D-BEEB9F-79BD8F-00A388-006DA3-719AC1

public class DanielRiveraM6 {
    public static void main(String[] args) {
        // Run thread that repairs and checks the connection
        ConnectRepair conRep = new ConnectRepair();
        Thread repThread = new Thread(conRep, "conRep");
        repThread.start();
        // Set up State Machine
        State.managerView = new ManagerView();
        State.employeeView = new EmployeeView();
        State.customerView = new CustomerView();
        State.login = new Login();
        
        
        //State.current = State.login;
        
        //while (State.current != State.exit)
        //{
        //    State.current.enter();
        //    State.current.update();
        //}
    }
}
