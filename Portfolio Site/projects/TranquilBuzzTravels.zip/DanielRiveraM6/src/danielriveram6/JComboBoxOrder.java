package danielriveram6;

import java.awt.*;
import javax.swing.*;

// JComboBox extension giving the proper color and font
public class JComboBoxOrder extends JComboBox {
    public JComboBoxOrder() {
        setBackground(new Color(225, 255, 204));
        setForeground(new Color(0, 163, 136));
        setBorder(BorderFactory.createLineBorder(new Color(121, 189, 143), 2, false));
        setFont(new Font("Calibri", Font.PLAIN, 24));
    }
}
