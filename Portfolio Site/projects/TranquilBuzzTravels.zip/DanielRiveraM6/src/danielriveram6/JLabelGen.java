package danielriveram6;

import java.awt.*;
import javax.swing.*;

// JLabel extension for all generic text
public class JLabelGen extends JLabel {
    // Constructor for text only
    public JLabelGen(String text) {
        setForeground(new Color(0, 163, 136));
        setFont(new Font("Calibri", Font.PLAIN, 24));
        setText(text);
        setSize(getPreferredSize().width, getPreferredSize().height);
    }
    // Constructor for text and font size
    public JLabelGen(String text, int fontSize) {
        setForeground(new Color(0, 163, 136));
        setFont(new Font("Calibri", Font.PLAIN, fontSize));
        setText(text);
        setSize(getPreferredSize().width, getPreferredSize().height);
    }
    // Constructor for text, size, and color
    public JLabelGen(String text, int fontSize, boolean redColor) {
        setFont(new Font("Calibri", Font.PLAIN, fontSize));
        setText(text);
        setSize(getPreferredSize().width, getPreferredSize().height);
        if (redColor) {
            setForeground(Color.red);
        } else {
            setForeground(new Color(0, 163, 136));
        }
    }
}
