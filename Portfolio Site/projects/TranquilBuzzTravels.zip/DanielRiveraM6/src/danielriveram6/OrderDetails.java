package danielriveram6;

public class OrderDetails {
    // Variable declarations
    int idNumber;
    String date;
    double basePricePerNight, parkingFee, valetParking,
            balanceOwed, totalSpending;
    
    // Default constructor
    public OrderDetails()
    {
        idNumber = 0;
        date = "";
        basePricePerNight = 0.0;
        parkingFee = 0.0;
        valetParking = 0.0;
        balanceOwed = 0.0;
        totalSpending = 0.0;
    }
    // Constructor with definitions
    public OrderDetails(int idNum, String dat, double basePPN, double parkFee,
            double vPark, double balOwed, double ttlSpend)
    {
        this.idNumber = idNum;
        this.date = dat;
        this.basePricePerNight = basePPN;
        this.parkingFee = parkFee;
        this.valetParking = vPark;
        this.balanceOwed = balOwed;
        this.totalSpending = ttlSpend;
    }
    
    // New .toString() override
    public String toString()
    {
        return "ID number: " + this.idNumber
                + "\nDate: " + this.date
                + "\nBase price per night: $" + String.format("%.2f", this.basePricePerNight)
                + "\nParking fee: $" + String.format("%.2f", this.parkingFee)
                + "\nValet parking fee: $" + String.format("%.2f", this.valetParking)
                + "\nBalance owed: $" + String.format("%.2f", this.balanceOwed)
                + "\nTotal spending: $" + String.format("%.2f", this.totalSpending);
    }
}
