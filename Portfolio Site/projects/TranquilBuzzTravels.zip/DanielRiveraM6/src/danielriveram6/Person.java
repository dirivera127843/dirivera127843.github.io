package danielriveram6;

public abstract class Person {
    // Variable declarations
    String name, phoneNumber, loginName, password, address;
    int idNumber;
    
    // Default constructor
    public Person()
    {
        name = "";
        phoneNumber = "";
        loginName = "";
        password = "";
        address = "";
        idNumber = 0;
    }
    // Constructor with definitions
    public Person(String nam, String phoneNum, String logNam, String pWord,
            String addr, int idNum)
    {
        this.name = nam;
        this.phoneNumber = phoneNum;
        this.loginName = logNam;
        this.password = pWord;
        this.address = addr;
        this.idNumber = idNum;
    }
    
    // New .toString() override
    public String toString()
    {
        return "Name: " + this.name
                + "\nPhone number: " + this.phoneNumber
                + "\nLogin name: " + this.loginName
                + "\nPassword: " + this.password
                + "\nLiving Address: " + this.address
                + "\nID number: " + this.idNumber;
    }
}
