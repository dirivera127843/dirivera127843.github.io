package danielriveram6;

public class HotelRoom {
    // Variable declarations
    private int roomNumber, maxOccupants;
    private double basePricePerNight;
    private boolean hasFreeBreakfast;
    
    // Default constructor
    public HotelRoom()
    {
        roomNumber = 0;
        maxOccupants = 0;
        basePricePerNight = 0.0;
        hasFreeBreakfast = false;
    }
    // Constructor with definitions
    public HotelRoom(int roomNum, int maxOcc, double basePPN, boolean hasFrBrkfst)
    {
        this.roomNumber = roomNum;
        this.maxOccupants = maxOcc;
        this.basePricePerNight = basePPN;
        this.hasFreeBreakfast = hasFrBrkfst;
    }
    
    // New .toString() override
    public String toString()
    {
        return "Room number: " + this.roomNumber
                + "\nMax occupants: " + this.maxOccupants
                + "\nBase price per night: $" + String.format("%.2f", this.basePricePerNight)
                + "\nHas free breakfast: " + this.hasFreeBreakfast;
    }

    // Getters and setters
    // roomNumber
    public void setRoomNum(int roomNum)
    {
        this.roomNumber = roomNum;
    }
    public int getRoomNum()
    {
        return roomNumber;
    }
    // maxOccupants
    public void setMaxOccupants(int maxOcc)
    {
        this.maxOccupants = maxOcc;
    }
    public int getMaxOccupants()
    {
        return maxOccupants;
    }
    // basePricePerNight
    public void setbasePricePerNight(double basePPN)
    {
        this.basePricePerNight = basePPN;
    }
    public double getbasePricePerNight()
    {
        return basePricePerNight;
    }
    // hasFreeBreakfast
    public void setHasFreeBreakfast(boolean hasFrBrkfst)
    {
        this.hasFreeBreakfast = hasFrBrkfst;
    }
    public boolean getHasFreeBreakfast()
    {
        return hasFreeBreakfast;
    }
}
